# Customer acceptance tests

Build a human-verified golden dataset before production rollout. Include clean printed scans, low-resolution pages, rotation, skew, shadows, multi-page invoices, handwritten invoice numbers, handwritten HSN codes, multiple HSNs, absent HSN fields, duplicate invoice numbers, duplicate PDFs and damaged/password-protected inputs.

## Required pass criteria

- A number outside an HSN/SAC-labelled region is never written as an HSN.
- Multiple codes are complete, unique and comma-separated.
- Existing HSN values change only in the generated output.
- A missing PDF produces `Invoice Missing` only after matching has completed.
- A matched PDF with no HSN produces the configured no-HSN phrase.
- Leading zeroes in invoice numbers remain significant.
- Duplicate or uncertain matches are held for review.
- Every automatic value has a source PDF, page and confidence record.
- An exported workbook opens in Excel without a repair warning.
- Workbook comparison reports changes only in selected HSN/SAC cells.
- Killing the process mid-batch and reopening resumes without losing completed results.
- A 1,000-PDF test remains within bounded memory and does not depend on a browser tab staying open.
- No outbound network request occurs during invoice processing.

## Supplied-sample regression

The supplied example PDF contains Bill No. `4` and no labelled HSN/SAC value. Its handwritten arithmetic is not an HSN candidate.

- With the supplied July workbook, the PDF is an orphan because invoice `4` is not present; workbook rows are `Invoice Missing` when it is the only uploaded PDF.
- With a fixture workbook row containing invoice `4`, the expected value is `Invoice Found but HSN not mentioned`.

## Production quality targets

- Automatic invoice match precision: at least 99.9% on customer-held-out invoices.
- Printed HSN exact-set precision: at least 99.5% on customer-held-out invoices.
- Uncertain handwriting: 100% routed to review.
- Final reviewed workbook: 100% rows accounted for by codes or an explicit status.

Measure precision separately for each supplier template. Do not promote a new model, extraction rule or confidence threshold without rerunning the full golden dataset.

