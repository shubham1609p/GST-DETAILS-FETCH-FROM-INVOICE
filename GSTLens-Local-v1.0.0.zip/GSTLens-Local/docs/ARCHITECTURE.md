# Architecture and safety controls

## Processing flow

```text
Excel workbook ──> mapping confirmation ──> invoice rows / exact candidate set
                                                     │
ZIP or PDFs ──> safe extraction ──> page rendering ──> local PP-OCRv6
                                                     │ uncertain / empty
                                                     └─> local PP-OCRv5 handwriting pass
                                                     │
                              labelled invoice/HSN geometry extraction
                                                     │
                         exact unique match + confidence validation
                                  │                       │
                             auto-accept               review queue
                                  └───────────┬───────────┘
                                              │
                            output workbook + audit CSV + dashboard
```

The workbook invoice list is the source of truth. PDF OCR cannot create new workbook rows.

## Matching rules

1. Read invoice cells as displayed strings and preserve leading zeroes.
2. Normalise Unicode spaces, case and repeated whitespace.
3. Keep punctuation significant for the primary key.
4. Extract PDF candidates only near labels such as Invoice No., Bill No. or Tax Invoice No.
5. Auto-match only one exact candidate to one workbook invoice number.
6. Duplicate workbook keys, duplicate PDFs, conflicting candidates and punctuation/fuzzy alternatives require review.
7. Supplier GSTIN, date and total can support a review suggestion but cannot override a conflicting exact invoice number silently.

## HSN/SAC rules

1. Locate an HSN/SAC, HSN, SAC, Tariff Code or Commodity Code label.
2. If it is a table header, determine its horizontal column band from neighbouring headers.
3. Collect code candidates below that header until subtotal/tax/total.
4. If it is a key/value field, collect only the adjacent value.
5. Accept normalised 4-, 6- or 8-digit candidates (and optionally 2-digit headings when enabled by a future customer policy).
6. Correct letter/digit OCR confusion only inside an established code region.
7. De-duplicate while retaining first-document order.
8. Hold low-confidence or conflicting values for review.

The handwriting engine is a confirmation/fallback path. A code seen only by that pass is proposed to the reviewer; it is not silently written. When the independent passes agree and all context checks pass, confidence-only warnings can be cleared.

## Batch recovery

Every document and result is stored in SQLite independently. On application startup, any batch left in `processing` is changed to `paused`. Resuming skips documents already completed with the same file hash and OCR/preprocessing version.

## Workbook safety

- The upload is copied into a per-batch private directory.
- `.xlsm` is loaded with VBA preservation enabled.
- Only the chosen HSN/SAC cells are patched in the output copy.
- Cell values beginning with Excel formula characters are never accepted from OCR or review input.
- The export is reopened and validated before becoming downloadable.
- The original upload remains unchanged.

## Security boundaries

- Localhost-only HTTP (`127.0.0.1`).
- HTTP-only, SameSite=Strict session cookies.
- Argon2id password hashing with a PBKDF2 compatibility fallback.
- Random installation secret and hashed session tokens.
- Safe filenames and bounded streaming uploads.
- ZIP path traversal, links, encrypted entries, excess file counts and decompression bombs blocked.
- No invoice or credential telemetry.
