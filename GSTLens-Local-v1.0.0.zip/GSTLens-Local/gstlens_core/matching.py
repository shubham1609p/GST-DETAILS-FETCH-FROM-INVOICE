"""Collision-safe invoice-number normalization and matching."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from statistics import median
from typing import Generic, Hashable, Iterable, Sequence, TypeVar

from .models import BoundingBox, OCRPage, OCRToken


ReferenceId = TypeVar("ReferenceId", bound=Hashable)

_DASH_TRANSLATION = str.maketrans(
    {
        "‐": "-",
        "‑": "-",
        "‒": "-",
        "–": "-",
        "—": "-",
        "−": "-",
        "－": "-",
        "／": "/",
        "⁄": "/",
        "∕": "/",
    }
)
_SPACE_RE = re.compile(r"\s+")
_SPACE_AROUND_PUNCTUATION_RE = re.compile(r"\s*([/\\-])\s*")


def coerce_invoice_number(value: object) -> str:
    """Convert common Excel scalar values without inventing leading zeroes."""

    if value is None:
        return ""
    if isinstance(value, bool):
        return str(value).upper()
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    if isinstance(value, Decimal) and value == value.to_integral_value():
        return str(int(value))
    return str(value)


def normalize_invoice_number(value: object) -> str:
    """Normalize harmless OCR/Excel differences while preserving identity.

    Punctuation and leading zeroes are intentionally retained.  For example,
    ``AB-123``, ``AB/123`` and ``AB123`` are three different invoice numbers.
    """

    text = unicodedata.normalize("NFKC", coerce_invoice_number(value))
    text = text.translate(_DASH_TRANSLATION).strip().upper()
    text = _SPACE_RE.sub(" ", text)
    return _SPACE_AROUND_PUNCTUATION_RE.sub(r"\1", text)


def _compact_whitespace_key(normalized: str) -> str:
    return normalized.replace(" ", "")


class InvoiceMatchStatus(str, Enum):
    MATCHED = "matched"
    NOT_FOUND = "not_found"
    AMBIGUOUS = "ambiguous"
    INVALID = "invalid"


class InvoiceMatchMethod(str, Enum):
    EXACT_NORMALIZED = "exact_normalized"
    UNIQUE_WHITESPACE_FALLBACK = "unique_whitespace_fallback"


@dataclass(frozen=True, slots=True)
class InvoiceReference(Generic[ReferenceId]):
    reference_id: ReferenceId
    invoice_number: object


@dataclass(frozen=True, slots=True)
class InvoiceMatch(Generic[ReferenceId]):
    query: object
    normalized_query: str
    status: InvoiceMatchStatus
    reference_ids: tuple[ReferenceId, ...] = ()
    method: InvoiceMatchMethod | None = None

    @property
    def reference_id(self) -> ReferenceId | None:
        return self.reference_ids[0] if len(self.reference_ids) == 1 else None


@dataclass(frozen=True, slots=True)
class InvoiceOCRCandidate(Generic[ReferenceId]):
    observed_value: str
    confidence: float
    page_number: int
    box: BoundingBox
    context: str
    match: InvoiceMatch[ReferenceId]


@dataclass(frozen=True, slots=True)
class InvoiceDocumentMatch(Generic[ReferenceId]):
    status: InvoiceMatchStatus
    reference_ids: tuple[ReferenceId, ...]
    observed_invoice_number: str | None
    confidence: float
    requires_review: bool
    review_reasons: tuple[str, ...]
    candidates: tuple[InvoiceOCRCandidate[ReferenceId], ...]

    @property
    def reference_id(self) -> ReferenceId | None:
        return self.reference_ids[0] if len(self.reference_ids) == 1 else None


@dataclass(frozen=True, slots=True)
class _OCRLine:
    tokens: tuple[OCRToken, ...]
    box: BoundingBox


@dataclass(frozen=True, slots=True)
class _InvoiceLabel:
    line: _OCRLine
    start_index: int
    end_index: int
    box: BoundingBox
    confidence: float
    embedded_value: str | None = None


_INVOICE_LABEL_KEYS = frozenset(
    {
        "INVOICENO",
        "INVOICENUMBER",
        "INVNO",
        "INVNUMBER",
        "BILLNO",
        "BILLNUMBER",
        "DOCUMENTNO",
        "DOCUMENTNUMBER",
        "NOTENO",
        "NOTENUMBER",
        "CREDITNOTENO",
        "CREDITNOTENUMBER",
        "DEBITNOTENO",
        "DEBITNOTENUMBER",
        "TAXINVOICENO",
        "TAXINVOICENUMBER",
    }
)
_EMBEDDED_INVOICE_LABEL_RE = re.compile(
    r"^\s*(?:(?:TAX\s+)?INVOICE|INV|BILL|DOCUMENT|CREDIT\s+NOTE|DEBIT\s+NOTE|NOTE)"
    r"\s*(?:NUMBER|NO\.?|#)?\s*(?::|#|-)?\s*(.*?)\s*$",
    re.IGNORECASE,
)


def _label_letters(text: str) -> str:
    return re.sub(
        r"[^A-Z]",
        "",
        unicodedata.normalize("NFKC", text).upper(),
    )


def _split_embedded_invoice_label(text: str) -> tuple[bool, str | None]:
    match = _EMBEDDED_INVOICE_LABEL_RE.fullmatch(
        unicodedata.normalize("NFKC", text)
    )
    if not match:
        return False, None
    tail = match.group(1).strip().strip(":# ")
    if tail and any(character.isdigit() for character in tail):
        return True, tail
    return _label_letters(text) in _INVOICE_LABEL_KEYS, None


def _group_ocr_lines(tokens: Sequence[OCRToken]) -> tuple[_OCRLine, ...]:
    nonempty = [token for token in tokens if token.text.strip()]
    if not nonempty:
        return ()
    typical_height = median(max(token.box.height, 1.0) for token in nonempty)
    tolerance = max(3.0, typical_height * 0.65)
    groups: list[list[OCRToken]] = []
    centers: list[float] = []
    for token in sorted(nonempty, key=lambda item: (item.box.center_y, item.box.x0)):
        choices = [
            (abs(token.box.center_y - center), index)
            for index, center in enumerate(centers)
            if abs(token.box.center_y - center) <= tolerance
        ]
        if not choices:
            groups.append([token])
            centers.append(token.box.center_y)
            continue
        _, chosen = min(choices)
        groups[chosen].append(token)
        centers[chosen] = sum(item.box.center_y for item in groups[chosen]) / len(
            groups[chosen]
        )
    lines = [
        _OCRLine(
            tuple(sorted(group, key=lambda item: item.box.x0)),
            BoundingBox.enclosing(item.box for item in group),
        )
        for group in groups
    ]
    return tuple(sorted(lines, key=lambda line: (line.box.y0, line.box.x0)))


def _find_invoice_labels(lines: Sequence[_OCRLine]) -> tuple[_InvoiceLabel, ...]:
    labels: list[_InvoiceLabel] = []
    for line in lines:
        possibilities: list[_InvoiceLabel] = []
        for start, token in enumerate(line.tokens):
            recognized, embedded = _split_embedded_invoice_label(token.text)
            if recognized:
                possibilities.append(
                    _InvoiceLabel(
                        line,
                        start,
                        start + 1,
                        token.box,
                        token.confidence,
                        embedded,
                    )
                )
            for end in range(start + 1, min(len(line.tokens), start + 4) + 1):
                members = line.tokens[start:end]
                if len(members) > 1 and any(
                    re.search(r"\d", member.text) for member in members
                ):
                    break
                combined = " ".join(member.text for member in members)
                if _label_letters(combined) not in _INVOICE_LABEL_KEYS:
                    continue
                possibilities.append(
                    _InvoiceLabel(
                        line,
                        start,
                        end,
                        BoundingBox.enclosing(member.box for member in members),
                        sum(member.confidence for member in members) / len(members),
                    )
                )

        occupied: set[int] = set()
        for label in sorted(
            possibilities,
            key=lambda item: (item.end_index - item.start_index, item.box.width),
            reverse=True,
        ):
            indices = set(range(label.start_index, label.end_index))
            if indices & occupied:
                continue
            labels.append(label)
            occupied.update(indices)
    return tuple(labels)


def _clean_observed_invoice(value: str) -> str:
    return unicodedata.normalize("NFKC", value).strip().strip(":# ")


class InvoiceMatcher(Generic[ReferenceId]):
    """Index invoice references and return a match only when it is unique."""

    def __init__(self, references: Iterable[InvoiceReference[ReferenceId]]) -> None:
        exact: dict[str, list[ReferenceId]] = {}
        compact: dict[str, list[ReferenceId]] = {}
        for reference in references:
            normalized = normalize_invoice_number(reference.invoice_number)
            if not normalized:
                continue
            exact.setdefault(normalized, []).append(reference.reference_id)
            compact.setdefault(_compact_whitespace_key(normalized), []).append(
                reference.reference_id
            )
        self._exact = {key: tuple(values) for key, values in exact.items()}
        self._compact = {key: tuple(values) for key, values in compact.items()}

    def match(self, invoice_number: object) -> InvoiceMatch[ReferenceId]:
        normalized = normalize_invoice_number(invoice_number)
        if not normalized:
            return InvoiceMatch(
                invoice_number,
                normalized,
                InvoiceMatchStatus.INVALID,
            )

        exact = self._exact.get(normalized, ())
        if len(exact) == 1:
            return InvoiceMatch(
                invoice_number,
                normalized,
                InvoiceMatchStatus.MATCHED,
                exact,
                InvoiceMatchMethod.EXACT_NORMALIZED,
            )
        if len(exact) > 1:
            return InvoiceMatch(
                invoice_number,
                normalized,
                InvoiceMatchStatus.AMBIGUOUS,
                exact,
            )

        compact = self._compact.get(_compact_whitespace_key(normalized), ())
        if len(compact) == 1:
            return InvoiceMatch(
                invoice_number,
                normalized,
                InvoiceMatchStatus.MATCHED,
                compact,
                InvoiceMatchMethod.UNIQUE_WHITESPACE_FALLBACK,
            )
        if len(compact) > 1:
            return InvoiceMatch(
                invoice_number,
                normalized,
                InvoiceMatchStatus.AMBIGUOUS,
                compact,
            )
        return InvoiceMatch(
            invoice_number,
            normalized,
            InvoiceMatchStatus.NOT_FOUND,
        )

    def _ocr_candidate(
        self,
        value: str,
        *,
        confidence: float,
        page_number: int,
        box: BoundingBox,
        context: str,
    ) -> InvoiceOCRCandidate[ReferenceId] | None:
        cleaned = _clean_observed_invoice(value)
        if not cleaned or not any(character.isdigit() for character in cleaned):
            return None
        return InvoiceOCRCandidate(
            observed_value=cleaned,
            confidence=confidence,
            page_number=page_number,
            box=box,
            context=context,
            match=self.match(cleaned),
        )

    def match_pages(
        self,
        pages: Iterable[OCRPage],
        *,
        low_confidence_threshold: float = 0.78,
    ) -> InvoiceDocumentMatch[ReferenceId]:
        """Find an explicitly labelled invoice number and match known rows.

        Candidate strings are assembled only beside/below labels such as
        ``Invoice No`` or ``Bill Number``.  Each candidate then passes through
        the same collision-safe matcher as direct strings; there is no fuzzy
        edit-distance match that could silently select a similar invoice.
        """

        if not 0.0 <= low_confidence_threshold <= 1.0:
            raise ValueError("low_confidence_threshold must be between 0 and 1")

        candidates: list[InvoiceOCRCandidate[ReferenceId]] = []
        for page in sorted(tuple(pages), key=lambda item: item.page_number):
            lines = _group_ocr_lines(page.tokens)
            for label in _find_invoice_labels(lines):
                label_candidates: list[InvoiceOCRCandidate[ReferenceId]] = []
                if label.embedded_value:
                    candidate = self._ocr_candidate(
                        label.embedded_value,
                        confidence=label.confidence,
                        page_number=page.page_number,
                        box=label.box,
                        context="embedded-label",
                    )
                    if candidate:
                        label_candidates.append(candidate)

                right_tokens = [
                    token
                    for index, token in enumerate(label.line.tokens)
                    if index >= label.end_index and token.box.x0 >= label.box.x1
                ][:6]
                for length in range(1, len(right_tokens) + 1):
                    members = right_tokens[:length]
                    spaced_value = " ".join(token.text for token in members)
                    compact_value = "".join(token.text for token in members)
                    for value in dict.fromkeys((spaced_value, compact_value)):
                        candidate = self._ocr_candidate(
                            value,
                            confidence=min(
                                label.confidence,
                                sum(token.confidence for token in members) / len(members),
                            ),
                            page_number=page.page_number,
                            box=BoundingBox.enclosing(token.box for token in members),
                            context="right-of-label",
                        )
                        if candidate:
                            label_candidates.append(candidate)

                vertical_limit = label.box.y1 + max(
                    page.height * 0.055, label.box.height * 4.0
                )
                for next_line in lines:
                    if next_line.box.center_y <= label.box.y1:
                        continue
                    if next_line.box.y0 > vertical_limit:
                        break
                    nearby = [
                        token
                        for token in next_line.tokens
                        if token.box.x1 >= label.box.x0 - page.width * 0.03
                        and token.box.x0 <= label.box.x1 + page.width * 0.24
                    ][:6]
                    line_had_match = False
                    for length in range(1, len(nearby) + 1):
                        members = nearby[:length]
                        spaced_value = " ".join(token.text for token in members)
                        compact_value = "".join(token.text for token in members)
                        for value in dict.fromkeys((spaced_value, compact_value)):
                            candidate = self._ocr_candidate(
                                value,
                                confidence=min(
                                    label.confidence,
                                    sum(token.confidence for token in members) / len(members),
                                ),
                                page_number=page.page_number,
                                box=BoundingBox.enclosing(token.box for token in members),
                                context="below-label",
                            )
                            if candidate:
                                label_candidates.append(candidate)
                                line_had_match = line_had_match or (
                                    candidate.match.status
                                    in {
                                        InvoiceMatchStatus.MATCHED,
                                        InvoiceMatchStatus.AMBIGUOUS,
                                    }
                                )
                    if line_had_match:
                        break

                # Keep all successful alternatives.  If none match, preserve
                # only the shortest observed value as useful orphan evidence.
                successful = [
                    item
                    for item in label_candidates
                    if item.match.status
                    in {InvoiceMatchStatus.MATCHED, InvoiceMatchStatus.AMBIGUOUS}
                ]
                if successful:
                    candidates.extend(successful)
                elif label_candidates:
                    candidates.append(
                        min(label_candidates, key=lambda item: len(item.observed_value))
                    )

        deduplicated: dict[tuple[object, ...], InvoiceOCRCandidate[ReferenceId]] = {}
        for candidate in candidates:
            key = (
                candidate.page_number,
                candidate.observed_value,
                candidate.match.status,
                candidate.match.reference_ids,
            )
            previous = deduplicated.get(key)
            if previous is None or candidate.confidence > previous.confidence:
                deduplicated[key] = candidate
        ordered = tuple(
            sorted(
                deduplicated.values(),
                key=lambda item: (-item.confidence, item.page_number, item.box.y0),
            )
        )

        matched_reference_ids = tuple(
            dict.fromkeys(
                reference_id
                for candidate in ordered
                if candidate.match.status is InvoiceMatchStatus.MATCHED
                for reference_id in candidate.match.reference_ids
            )
        )
        ambiguous_ids = tuple(
            dict.fromkeys(
                reference_id
                for candidate in ordered
                if candidate.match.status is InvoiceMatchStatus.AMBIGUOUS
                for reference_id in candidate.match.reference_ids
            )
        )
        if len(matched_reference_ids) > 1 or ambiguous_ids:
            references = tuple(dict.fromkeys((*matched_reference_ids, *ambiguous_ids)))
            best = ordered[0] if ordered else None
            return InvoiceDocumentMatch(
                status=InvoiceMatchStatus.AMBIGUOUS,
                reference_ids=references,
                observed_invoice_number=best.observed_value if best else None,
                confidence=best.confidence if best else 0.0,
                requires_review=True,
                review_reasons=("OCR invoice number matches more than one Excel row",),
                candidates=ordered,
            )
        if len(matched_reference_ids) == 1:
            matching = [
                candidate
                for candidate in ordered
                if candidate.match.reference_id == matched_reference_ids[0]
            ]
            best = max(
                matching,
                key=lambda item: (
                    item.confidence,
                    item.match.method is InvoiceMatchMethod.EXACT_NORMALIZED,
                ),
            )
            reasons: list[str] = []
            if best.confidence < low_confidence_threshold:
                reasons.append("Invoice number has low OCR confidence")
            if best.match.method is InvoiceMatchMethod.UNIQUE_WHITESPACE_FALLBACK:
                reasons.append("Invoice number matched only after removing spaces")
            return InvoiceDocumentMatch(
                status=InvoiceMatchStatus.MATCHED,
                reference_ids=matched_reference_ids,
                observed_invoice_number=best.observed_value,
                confidence=best.confidence,
                requires_review=bool(reasons),
                review_reasons=tuple(reasons),
                candidates=ordered,
            )

        best = ordered[0] if ordered else None
        return InvoiceDocumentMatch(
            status=InvoiceMatchStatus.NOT_FOUND,
            reference_ids=(),
            observed_invoice_number=best.observed_value if best else None,
            confidence=best.confidence if best else 0.0,
            requires_review=False,
            review_reasons=(),
            candidates=ordered,
        )
