"""Workbook header discovery and atomic, formatting-preserving updates."""

from __future__ import annotations

import os
import re
import tempfile
import unicodedata
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Iterable

from openpyxl import load_workbook
from openpyxl.cell.cell import Cell

from .matching import (
    InvoiceMatcher,
    InvoiceMatchStatus,
    InvoiceReference,
    normalize_invoice_number,
)


_SUPPORTED_SUFFIXES = frozenset({".xlsx", ".xlsm", ".xltx", ".xltm"})
_MACRO_SUFFIXES = frozenset({".xlsm", ".xltm"})
_INVOICE_HEADER_KEYS = frozenset(
    {
        "INVOICE",
        "INVOICENUMBER",
        "INVOICENO",
        "INVOICENUM",
        "INV",
        "INVNUMBER",
        "INVNO",
        "BILL",
        "BILLNUMBER",
        "BILLNO",
        "DOCUMENTNUMBER",
        "DOCUMENTNO",
        "NOTENUMBER",
        "NOTENO",
        "CREDITNOTENUMBER",
        "CREDITNOTENO",
        "DEBITNOTENUMBER",
        "DEBITNOTENO",
    }
)
_HSN_HEADER_KEYS = frozenset(
    {
        "HSN",
        "SAC",
        "HSNSAC",
        "HSNSCA",
        "HSNCODE",
        "SACCODE",
        "HSNSACCODE",
        "HSNSCACODE",
        "HSNSACNO",
    }
)


@dataclass(frozen=True, slots=True)
class WorkbookMapping:
    sheet_name: str
    header_row: int
    invoice_column: int
    hsn_column: int

    def __post_init__(self) -> None:
        if not self.sheet_name:
            raise ValueError("sheet_name is required")
        if min(self.header_row, self.invoice_column, self.hsn_column) < 1:
            raise ValueError("Workbook rows and columns are one-based")
        if self.invoice_column == self.hsn_column:
            raise ValueError("Invoice and HSN/SAC columns must be different")


@dataclass(frozen=True, slots=True)
class WorkbookInvoiceRow:
    row_number: int
    invoice_number: str
    normalized_invoice_number: str


@dataclass(frozen=True, slots=True)
class WorkbookCellUpdate:
    invoice_number: object
    value: str


class WorkbookUpdateStatus(str, Enum):
    UPDATED = "updated"
    NOT_FOUND = "not_found"
    AMBIGUOUS = "ambiguous"
    INVALID = "invalid"
    CONFLICTING_UPDATE = "conflicting_update"
    SKIPPED_EXISTING = "skipped_existing"


@dataclass(frozen=True, slots=True)
class WorkbookUpdateOutcome:
    update: WorkbookCellUpdate
    status: WorkbookUpdateStatus
    row_number: int | None = None
    previous_value: object | None = None


@dataclass(frozen=True, slots=True)
class WorkbookUpdateReport:
    output_path: Path
    outcomes: tuple[WorkbookUpdateOutcome, ...]

    @property
    def updated_count(self) -> int:
        return sum(item.status is WorkbookUpdateStatus.UPDATED for item in self.outcomes)


def _validate_workbook_path(path: Path) -> None:
    if path.suffix.lower() not in _SUPPORTED_SUFFIXES:
        raise ValueError(
            f"Unsupported workbook type {path.suffix!r}; use .xlsx, .xlsm, .xltx or .xltm"
        )


def _header_key(value: object) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).upper()
    return re.sub(r"[^A-Z0-9]", "", text)


def _keep_vba(path: Path) -> bool:
    return path.suffix.lower() in _MACRO_SUFFIXES


def detect_workbook_mappings(
    workbook_path: str | os.PathLike[str],
    *,
    max_header_rows: int = 50,
) -> tuple[WorkbookMapping, ...]:
    """Find invoice/HSN header pairs without assuming column letters.

    If a row has multiple invoice-number headers, the closest header to the
    left of each HSN/SAC header is chosen.  This handles amendment sheets with
    separate "Original" and "Revised" invoice sections.
    """

    if max_header_rows < 1:
        raise ValueError("max_header_rows must be positive")
    path = Path(workbook_path)
    _validate_workbook_path(path)
    workbook = load_workbook(
        path,
        read_only=True,
        data_only=False,
        keep_vba=_keep_vba(path),
        keep_links=True,
    )
    mappings: list[WorkbookMapping] = []
    try:
        for sheet in workbook.worksheets:
            last_header_row = min(max_header_rows, sheet.max_row)
            for row_number, cells in enumerate(
                sheet.iter_rows(min_row=1, max_row=last_header_row),
                start=1,
            ):
                invoice_columns = [
                    cell.column
                    for cell in cells
                    if _header_key(cell.value) in _INVOICE_HEADER_KEYS
                ]
                hsn_columns = [
                    cell.column
                    for cell in cells
                    if _header_key(cell.value) in _HSN_HEADER_KEYS
                ]
                for hsn_column in hsn_columns:
                    left_candidates = [
                        column for column in invoice_columns if column < hsn_column
                    ]
                    candidates = left_candidates or invoice_columns
                    if not candidates:
                        continue
                    distances = {
                        column: abs(hsn_column - column) for column in candidates
                    }
                    shortest = min(distances.values())
                    closest = [
                        column for column, distance in distances.items() if distance == shortest
                    ]
                    if len(closest) != 1:
                        continue
                    mappings.append(
                        WorkbookMapping(
                            sheet_name=sheet.title,
                            header_row=row_number,
                            invoice_column=closest[0],
                            hsn_column=hsn_column,
                        )
                    )
    finally:
        workbook.close()
    return tuple(dict.fromkeys(mappings))


def _displayed_invoice_number(cell: Cell) -> str:
    value = cell.value
    if value is None:
        return ""
    if isinstance(value, str):
        if value.startswith("="):
            return ""
        return value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if isinstance(value, float) and not value.is_integer():
            return str(value)
        integer = int(value)
        # Honor a simple Excel zero mask such as 000042.
        number_format = str(cell.number_format or "").split(";", 1)[0]
        if re.fullmatch(r"0+", number_format):
            return str(integer).zfill(len(number_format))
        return str(integer)
    return str(value)


def _rows_from_sheet(sheet: object, mapping: WorkbookMapping) -> tuple[WorkbookInvoiceRow, ...]:
    rows: list[WorkbookInvoiceRow] = []
    for row_number in range(mapping.header_row + 1, sheet.max_row + 1):
        cell = sheet.cell(row=row_number, column=mapping.invoice_column)
        invoice_number = _displayed_invoice_number(cell)
        normalized = normalize_invoice_number(invoice_number)
        if not normalized:
            continue
        rows.append(WorkbookInvoiceRow(row_number, invoice_number, normalized))
    return tuple(rows)


def read_invoice_rows(
    workbook_path: str | os.PathLike[str],
    mapping: WorkbookMapping,
) -> tuple[WorkbookInvoiceRow, ...]:
    """Read invoice identifiers below a confirmed mapping's header row."""

    path = Path(workbook_path)
    _validate_workbook_path(path)
    workbook = load_workbook(
        path,
        read_only=True,
        data_only=False,
        keep_vba=_keep_vba(path),
        keep_links=True,
    )
    try:
        if mapping.sheet_name not in workbook.sheetnames:
            raise KeyError(f"Sheet {mapping.sheet_name!r} does not exist")
        return _rows_from_sheet(workbook[mapping.sheet_name], mapping)
    finally:
        workbook.close()


def _atomic_save(workbook: object, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=".gstlens-",
        suffix=output_path.suffix,
        dir=output_path.parent,
    )
    os.close(descriptor)
    temporary_path = Path(temporary_name)
    try:
        workbook.save(temporary_path)
        os.replace(temporary_path, output_path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def update_workbook_by_invoice(
    source_path: str | os.PathLike[str],
    output_path: str | os.PathLike[str],
    mapping: WorkbookMapping,
    updates: Iterable[WorkbookCellUpdate],
    *,
    overwrite: bool = True,
) -> WorkbookUpdateReport:
    """Write values to uniquely matched invoice rows and save an atomic copy.

    Only the destination cell's ``value`` is changed, so its existing style,
    dimensions, merged ranges and the workbook's other sheets remain intact.
    Macro-enabled inputs are loaded with ``keep_vba=True`` and must retain a
    macro-enabled output suffix.
    """

    source = Path(source_path)
    output = Path(output_path)
    _validate_workbook_path(source)
    _validate_workbook_path(output)
    if source.resolve() == output.resolve():
        raise ValueError("Output must be a new file; the uploaded workbook is never overwritten")
    if _keep_vba(source) != _keep_vba(output):
        raise ValueError("Macro-enabled workbook outputs must keep a macro-enabled suffix")

    materialized_updates = tuple(updates)
    workbook = load_workbook(
        source,
        read_only=False,
        data_only=False,
        keep_vba=_keep_vba(source),
        keep_links=True,
    )
    try:
        if mapping.sheet_name not in workbook.sheetnames:
            raise KeyError(f"Sheet {mapping.sheet_name!r} does not exist")
        sheet = workbook[mapping.sheet_name]
        rows = _rows_from_sheet(sheet, mapping)
        matcher = InvoiceMatcher(
            InvoiceReference(row.row_number, row.invoice_number) for row in rows
        )

        preliminary: list[WorkbookUpdateOutcome | None] = [None] * len(
            materialized_updates
        )
        matched_by_row: dict[int, list[int]] = {}
        for index, update in enumerate(materialized_updates):
            match = matcher.match(update.invoice_number)
            if match.status is InvoiceMatchStatus.MATCHED:
                assert match.reference_id is not None
                matched_by_row.setdefault(match.reference_id, []).append(index)
            elif match.status is InvoiceMatchStatus.AMBIGUOUS:
                preliminary[index] = WorkbookUpdateOutcome(
                    update, WorkbookUpdateStatus.AMBIGUOUS
                )
            elif match.status is InvoiceMatchStatus.INVALID:
                preliminary[index] = WorkbookUpdateOutcome(
                    update, WorkbookUpdateStatus.INVALID
                )
            else:
                preliminary[index] = WorkbookUpdateOutcome(
                    update, WorkbookUpdateStatus.NOT_FOUND
                )

        for row_number, indices in matched_by_row.items():
            values = {materialized_updates[index].value for index in indices}
            target = sheet.cell(row=row_number, column=mapping.hsn_column)
            previous_value = target.value
            if len(values) > 1:
                for index in indices:
                    preliminary[index] = WorkbookUpdateOutcome(
                        materialized_updates[index],
                        WorkbookUpdateStatus.CONFLICTING_UPDATE,
                        row_number,
                        previous_value,
                    )
                continue
            if not overwrite and previous_value not in (None, ""):
                for index in indices:
                    preliminary[index] = WorkbookUpdateOutcome(
                        materialized_updates[index],
                        WorkbookUpdateStatus.SKIPPED_EXISTING,
                        row_number,
                        previous_value,
                    )
                continue

            value = values.pop()
            target.value = value
            for index in indices:
                preliminary[index] = WorkbookUpdateOutcome(
                    materialized_updates[index],
                    WorkbookUpdateStatus.UPDATED,
                    row_number,
                    previous_value,
                )

        outcomes = tuple(item for item in preliminary if item is not None)
        if len(outcomes) != len(materialized_updates):
            raise RuntimeError("Internal error while preparing workbook updates")
        _atomic_save(workbook, output)
        return WorkbookUpdateReport(output, outcomes)
    finally:
        workbook.close()
