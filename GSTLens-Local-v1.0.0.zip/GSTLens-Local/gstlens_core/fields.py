"""Convenience facade for extracting deterministic document fields."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, Hashable, Iterable, TypeVar

from .hsn import HsnExtraction, extract_hsn_sac
from .matching import InvoiceDocumentMatch, InvoiceMatcher
from .models import OCRPage


ReferenceId = TypeVar("ReferenceId", bound=Hashable)


@dataclass(frozen=True, slots=True)
class DocumentFields(Generic[ReferenceId]):
    invoice: InvoiceDocumentMatch[ReferenceId]
    hsn_sac: HsnExtraction


def extract_document_fields(
    pages: Iterable[OCRPage],
    invoice_matcher: InvoiceMatcher[ReferenceId],
    *,
    invoice_low_confidence_threshold: float = 0.78,
    hsn_low_confidence_threshold: float = 0.78,
) -> DocumentFields[ReferenceId]:
    """Extract invoice identity and context-validated HSN/SAC candidates."""

    materialized = tuple(pages)
    return DocumentFields(
        invoice=invoice_matcher.match_pages(
            materialized,
            low_confidence_threshold=invoice_low_confidence_threshold,
        ),
        hsn_sac=extract_hsn_sac(
            materialized,
            low_confidence_threshold=hsn_low_confidence_threshold,
        ),
    )

