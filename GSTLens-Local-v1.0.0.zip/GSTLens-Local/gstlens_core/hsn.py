"""Deterministic HSN/SAC extraction from positioned OCR tokens.

This module intentionally refuses to scrape every four-, six- or eight-digit
number on a page.  A number is considered only when it is attached to an
explicit HSN/SAC label or lies beneath an HSN/SAC table header.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from statistics import median
from typing import Iterable, Sequence

from .models import BoundingBox, OCRPage, OCRToken


_VALID_CODE_LENGTHS = frozenset({4, 6, 8})
_LABEL_LETTER_KEYS = frozenset(
    {
        "HSN",
        "SAC",
        "HSNCODE",
        "SACCODE",
        "HSNSAC",
        "HSNSACCODE",
        "HSNSCA",
        "HSNSCACODE",
        "HSNORSAC",
        "HSNORSACCODE",
    }
)
_TABLE_HEADER_WORDS = frozenset(
    {
        "DESCRIPTION",
        "PARTICULAR",
        "PARTICULARS",
        "ITEM",
        "ITEMS",
        "PRODUCT",
        "PRODUCTS",
        "SERVICE",
        "SERVICES",
        "QTY",
        "QUANTITY",
        "RATE",
        "AMOUNT",
        "VALUE",
        "UNIT",
        "UOM",
    }
)
_STOP_LINE_PHRASES = (
    "GRANDTOTAL",
    "SUBTOTAL",
    "TOTALTAX",
    "TAXABLEVALUE",
    "CGST",
    "SGST",
    "IGST",
    "ROUNDOFF",
    "BANKDETAIL",
    "DECLARATION",
)
_ALLOWED_CODE_TEXT_RE = re.compile(r"^[0-9\s,;]+$")


@dataclass(frozen=True, slots=True)
class HsnCandidate:
    code: str
    confidence: float
    page_number: int
    box: BoundingBox
    context: str
    source_text: str


@dataclass(frozen=True, slots=True)
class HsnExtraction:
    codes: tuple[str, ...]
    candidates: tuple[HsnCandidate, ...]
    label_found: bool
    requires_review: bool
    review_reasons: tuple[str, ...] = ()

    @property
    def joined_codes(self) -> str:
        return ", ".join(self.codes)


@dataclass(frozen=True, slots=True)
class _Line:
    tokens: tuple[OCRToken, ...]
    box: BoundingBox


@dataclass(frozen=True, slots=True)
class _Label:
    line: _Line
    start_index: int
    end_index: int
    box: BoundingBox
    confidence: float

    @property
    def tokens(self) -> tuple[OCRToken, ...]:
        return self.line.tokens[self.start_index : self.end_index]


def _letters(text: str) -> str:
    normalized = unicodedata.normalize("NFKC", text).upper()
    return re.sub(r"[^A-Z]", "", normalized)


def _is_label_text(text: str) -> bool:
    return _letters(text) in _LABEL_LETTER_KEYS


def _codes_from_text(text: str) -> tuple[str, ...]:
    """Parse a code cell, rejecting dates, amounts and mixed alphanumerics."""

    normalized = unicodedata.normalize("NFKC", text).strip()
    if not normalized or not _ALLOWED_CODE_TEXT_RE.fullmatch(normalized):
        return ()
    parts = re.split(r"[,;]", normalized)
    codes: list[str] = []
    for part in parts:
        code = re.sub(r"\s+", "", part)
        if len(code) not in _VALID_CODE_LENGTHS or not code.isdigit():
            return ()
        codes.append(code)
    return tuple(codes)


def _codes_embedded_in_label(text: str) -> tuple[str, ...]:
    normalized = unicodedata.normalize("NFKC", text).upper()
    match = re.search(
        r"(?:HSN(?:\s*[/&]|\s+OR\s+)?\s*(?:SAC|SCA)|HSN|SAC)(?:\s*CODE)?\s*[:#-]?\s*"
        r"([0-9][0-9\s,;]*)$",
        normalized,
    )
    return _codes_from_text(match.group(1)) if match else ()


def _group_lines(tokens: Sequence[OCRToken]) -> tuple[_Line, ...]:
    nonempty = [token for token in tokens if token.text.strip()]
    if not nonempty:
        return ()
    typical_height = median(max(token.box.height, 1.0) for token in nonempty)
    y_tolerance = max(3.0, typical_height * 0.65)
    grouped: list[list[OCRToken]] = []
    centers: list[float] = []
    for token in sorted(nonempty, key=lambda item: (item.box.center_y, item.box.x0)):
        best_index: int | None = None
        best_distance = float("inf")
        for index, center in enumerate(centers):
            distance = abs(token.box.center_y - center)
            if distance <= y_tolerance and distance < best_distance:
                best_index = index
                best_distance = distance
        if best_index is None:
            grouped.append([token])
            centers.append(token.box.center_y)
        else:
            grouped[best_index].append(token)
            centers[best_index] = sum(
                item.box.center_y for item in grouped[best_index]
            ) / len(grouped[best_index])

    lines: list[_Line] = []
    for members in grouped:
        ordered = tuple(sorted(members, key=lambda item: item.box.x0))
        lines.append(_Line(ordered, BoundingBox.enclosing(item.box for item in ordered)))
    return tuple(sorted(lines, key=lambda line: (line.box.y0, line.box.x0)))


def _find_labels(lines: Sequence[_Line]) -> tuple[_Label, ...]:
    found: list[_Label] = []
    for line in lines:
        possibilities: list[_Label] = []
        for start in range(len(line.tokens)):
            for end in range(start + 1, min(len(line.tokens), start + 4) + 1):
                members = line.tokens[start:end]
                # A numeric token next to "HSN" is the value, not part of the label.
                if len(members) > 1 and any(re.search(r"\d", item.text) for item in members):
                    break
                combined = " ".join(item.text for item in members)
                if not _is_label_text(combined):
                    continue
                possibilities.append(
                    _Label(
                        line=line,
                        start_index=start,
                        end_index=end,
                        box=BoundingBox.enclosing(item.box for item in members),
                        confidence=sum(item.confidence for item in members) / len(members),
                    )
                )

        # Prefer the longest label ("HSN / SAC Code") over overlapping fragments.
        occupied: set[int] = set()
        for label in sorted(
            possibilities,
            key=lambda item: (item.end_index - item.start_index, item.box.width),
            reverse=True,
        ):
            indices = set(range(label.start_index, label.end_index))
            if indices & occupied:
                continue
            found.append(label)
            occupied.update(indices)
    return tuple(found)


def _candidate_objects(
    token: OCRToken,
    *,
    page_number: int,
    label_confidence: float,
    context: str,
    embedded_codes: tuple[str, ...] | None = None,
) -> tuple[HsnCandidate, ...]:
    codes = embedded_codes if embedded_codes is not None else _codes_from_text(token.text)
    confidence = min(token.confidence, label_confidence)
    return tuple(
        HsnCandidate(
            code=code,
            confidence=confidence,
            page_number=page_number,
            box=token.box,
            context=context,
            source_text=token.text,
        )
        for code in codes
    )


def _line_has_table_context(line: _Line, label: _Label) -> bool:
    for index, token in enumerate(line.tokens):
        if label.start_index <= index < label.end_index:
            continue
        words = re.findall(r"[A-Z]+", unicodedata.normalize("NFKC", token.text).upper())
        if any(word in _TABLE_HEADER_WORDS for word in words):
            return True
    return False


def _column_bounds(page: OCRPage, label: _Label) -> tuple[float, float]:
    other_centers = [
        token.box.center_x
        for index, token in enumerate(label.line.tokens)
        if not label.start_index <= index < label.end_index and _letters(token.text)
    ]
    center = label.box.center_x
    left_neighbors = [value for value in other_centers if value < center]
    right_neighbors = [value for value in other_centers if value > center]
    default_margin = max(page.width * 0.055, label.box.width * 0.8, 20.0)
    left = (
        (max(left_neighbors) + center) / 2.0
        if left_neighbors
        else max(0.0, center - default_margin)
    )
    right = (
        (min(right_neighbors) + center) / 2.0
        if right_neighbors
        else min(page.width, center + default_margin)
    )
    return left, right


def _is_stop_line(line: _Line) -> bool:
    text = unicodedata.normalize(
        "NFKC", " ".join(token.text for token in line.tokens)
    ).upper()
    words = re.findall(r"[A-Z]+", text)
    if "TOTAL" in words:
        return True
    key = re.sub(
        r"[^A-Z]",
        "",
        text,
    )
    return any(phrase in key for phrase in _STOP_LINE_PHRASES)


def _extract_for_label(
    page: OCRPage,
    lines: Sequence[_Line],
    label: _Label,
) -> list[HsnCandidate]:
    candidates: list[HsnCandidate] = []

    # Some OCR engines return "HSN/SAC: 998311" as a single token.
    for token in label.tokens:
        embedded = _codes_embedded_in_label(token.text)
        if embedded:
            candidates.extend(
                _candidate_objects(
                    token,
                    page_number=page.page_number,
                    label_confidence=label.confidence,
                    context="inline-label",
                    embedded_codes=embedded,
                )
            )

    # A conventional form field: "HSN/SAC: 998311, 995411".
    right_limit = min(
        page.width,
        label.box.x1 + max(page.width * 0.28, label.box.width * 5.0, 80.0),
    )
    for index, token in enumerate(label.line.tokens):
        if index < label.end_index or token.box.x0 < label.box.x1:
            continue
        if token.box.center_x > right_limit:
            break
        parsed = _candidate_objects(
            token,
            page_number=page.page_number,
            label_confidence=label.confidence,
            context="inline-right",
        )
        if parsed:
            candidates.extend(parsed)
            continue
        # Do not leap over another field name and accidentally treat its value
        # (for example a four-digit invoice number) as an HSN/SAC code.
        if not re.fullmatch(r"\s*[:#,/;&-]+\s*", token.text):
            break

    following_lines = [line for line in lines if line.box.center_y > label.box.y1]
    if _line_has_table_context(label.line, label):
        left, right = _column_bounds(page, label)
        bottom_limit = min(page.height, label.box.y1 + page.height * 0.68)
        for line in following_lines:
            if line.box.y0 > bottom_limit:
                break
            if _is_stop_line(line):
                break
            for token in line.tokens:
                if left <= token.box.center_x <= right:
                    candidates.extend(
                        _candidate_objects(
                            token,
                            page_number=page.page_number,
                            label_confidence=label.confidence,
                            context="table-column",
                        )
                    )
    else:
        # A stacked form field may put the value immediately below its label.
        vertical_limit = label.box.y1 + max(page.height * 0.05, label.box.height * 4.0)
        left = label.box.center_x - max(page.width * 0.06, label.box.width)
        right = label.box.center_x + max(page.width * 0.06, label.box.width)
        for line in following_lines:
            if line.box.y0 > vertical_limit:
                break
            line_candidates: list[HsnCandidate] = []
            nearby_tokens = [
                token for token in line.tokens if left <= token.box.center_x <= right
            ]
            for token in nearby_tokens:
                parsed = _candidate_objects(
                    token,
                    page_number=page.page_number,
                    label_confidence=label.confidence,
                    context="immediately-below-label",
                )
                if parsed:
                    line_candidates.extend(parsed)
                    continue
                if not re.fullmatch(r"\s*[:#,/;&-]+\s*", token.text):
                    break
            if line_candidates:
                candidates.extend(line_candidates)
                break
    return candidates


def extract_hsn_sac(
    pages: Iterable[OCRPage],
    *,
    low_confidence_threshold: float = 0.78,
) -> HsnExtraction:
    """Extract HSN/SAC codes with geometry-aware context safeguards."""

    if not 0.0 <= low_confidence_threshold <= 1.0:
        raise ValueError("low_confidence_threshold must be between 0 and 1")

    all_candidates: list[HsnCandidate] = []
    label_found = False
    for page in sorted(tuple(pages), key=lambda item: item.page_number):
        lines = _group_lines(page.tokens)
        labels = _find_labels(lines)
        label_found = label_found or bool(labels)
        for label in labels:
            all_candidates.extend(_extract_for_label(page, lines, label))

    # The same token can be reached by inline and table logic.  Deduplicate its
    # evidence without collapsing legitimate repeated item rows.
    unique_candidates: dict[tuple[object, ...], HsnCandidate] = {}
    for candidate in all_candidates:
        key = (
            candidate.page_number,
            candidate.code,
            round(candidate.box.x0, 2),
            round(candidate.box.y0, 2),
            round(candidate.box.x1, 2),
            round(candidate.box.y1, 2),
        )
        previous = unique_candidates.get(key)
        if previous is None or candidate.confidence > previous.confidence:
            unique_candidates[key] = candidate
    ordered = tuple(
        sorted(
            unique_candidates.values(),
            key=lambda item: (item.page_number, item.box.y0, item.box.x0),
        )
    )

    reasons: list[str] = []
    if any(item.confidence < low_confidence_threshold for item in ordered):
        reasons.append("One or more HSN/SAC codes have low OCR confidence")

    for index, first in enumerate(ordered):
        for second in ordered[index + 1 :]:
            if first.page_number != second.page_number:
                continue
            if first.code == second.code or first.source_text == second.source_text:
                continue
            if first.box.intersection_over_union(second.box) >= 0.55:
                reasons.append("Conflicting HSN/SAC readings overlap on the invoice")
                break
        if len(reasons) > 1:
            break

    codes = tuple(dict.fromkeys(item.code for item in ordered))
    return HsnExtraction(
        codes=codes,
        candidates=ordered,
        label_found=label_found,
        requires_review=bool(reasons),
        review_reasons=tuple(dict.fromkeys(reasons)),
    )
