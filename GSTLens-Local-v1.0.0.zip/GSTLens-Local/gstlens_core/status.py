"""Canonical reconciliation statuses and cell-value decisions."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Protocol, Sequence


class ReconciliationStatus(str, Enum):
    MATCHED = "Matched"
    INVOICE_MISSING = "Invoice Missing"
    HSN_MISSING = "Invoice Found but HSN not mentioned"
    REVIEW_REQUIRED = "Requires Review"


INVOICE_MISSING = ReconciliationStatus.INVOICE_MISSING.value
HSN_MISSING = ReconciliationStatus.HSN_MISSING.value
REVIEW_REQUIRED = ReconciliationStatus.REVIEW_REQUIRED.value


class ExtractionLike(Protocol):
    codes: Sequence[str]
    requires_review: bool
    review_reasons: Sequence[str]


@dataclass(frozen=True, slots=True)
class ReconciliationDecision:
    status: ReconciliationStatus
    cell_value: str
    proposed_codes: tuple[str, ...] = ()
    review_reasons: tuple[str, ...] = ()

    @property
    def can_write_automatically(self) -> bool:
        return self.status is not ReconciliationStatus.REVIEW_REQUIRED


def decide_reconciliation(
    *,
    invoice_found: bool,
    extraction: ExtractionLike | None = None,
    invoice_match_ambiguous: bool = False,
) -> ReconciliationDecision:
    """Convert matching/extraction state into the exact Excel cell value.

    Low-confidence or ambiguous results are never silently written as HSN/SAC
    codes.  The UI can display ``proposed_codes`` to a reviewer and write the
    approved value afterward.
    """

    if invoice_match_ambiguous:
        return ReconciliationDecision(
            ReconciliationStatus.REVIEW_REQUIRED,
            REVIEW_REQUIRED,
            review_reasons=("Invoice number matches more than one row",),
        )
    if not invoice_found:
        return ReconciliationDecision(
            ReconciliationStatus.INVOICE_MISSING,
            INVOICE_MISSING,
        )
    if extraction is None:
        return ReconciliationDecision(
            ReconciliationStatus.HSN_MISSING,
            HSN_MISSING,
        )

    codes = tuple(dict.fromkeys(extraction.codes))
    reasons = tuple(extraction.review_reasons)
    if extraction.requires_review:
        return ReconciliationDecision(
            ReconciliationStatus.REVIEW_REQUIRED,
            REVIEW_REQUIRED,
            proposed_codes=codes,
            review_reasons=reasons or ("OCR result requires review",),
        )
    if not codes:
        return ReconciliationDecision(
            ReconciliationStatus.HSN_MISSING,
            HSN_MISSING,
        )
    return ReconciliationDecision(
        ReconciliationStatus.MATCHED,
        ", ".join(codes),
        proposed_codes=codes,
    )

