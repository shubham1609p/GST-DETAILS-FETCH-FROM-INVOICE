"""Small, dependency-free data types shared by OCR adapters and extractors.

The OCR engine is deliberately outside of :mod:`gstlens_core`.  Any local OCR
adapter can feed these structures, which keeps the reconciliation logic
deterministic and easy to test.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Iterable


@dataclass(frozen=True, slots=True)
class BoundingBox:
    """An axis-aligned box in image pixel coordinates."""

    x0: float
    y0: float
    x1: float
    y1: float

    def __post_init__(self) -> None:
        values = (self.x0, self.y0, self.x1, self.y1)
        if not all(isfinite(value) for value in values):
            raise ValueError("Bounding-box coordinates must be finite")
        if self.x1 < self.x0 or self.y1 < self.y0:
            raise ValueError("Bounding-box maximums must not precede minimums")

    @property
    def width(self) -> float:
        return self.x1 - self.x0

    @property
    def height(self) -> float:
        return self.y1 - self.y0

    @property
    def center_x(self) -> float:
        return (self.x0 + self.x1) / 2.0

    @property
    def center_y(self) -> float:
        return (self.y0 + self.y1) / 2.0

    @property
    def area(self) -> float:
        return self.width * self.height

    def intersection_over_union(self, other: "BoundingBox") -> float:
        left = max(self.x0, other.x0)
        top = max(self.y0, other.y0)
        right = min(self.x1, other.x1)
        bottom = min(self.y1, other.y1)
        intersection = max(0.0, right - left) * max(0.0, bottom - top)
        union = self.area + other.area - intersection
        return intersection / union if union else 0.0

    @classmethod
    def enclosing(cls, boxes: Iterable["BoundingBox"]) -> "BoundingBox":
        materialized = tuple(boxes)
        if not materialized:
            raise ValueError("At least one box is required")
        return cls(
            min(box.x0 for box in materialized),
            min(box.y0 for box in materialized),
            max(box.x1 for box in materialized),
            max(box.y1 for box in materialized),
        )


@dataclass(frozen=True, slots=True)
class OCRToken:
    """One recognized text region.

    ``confidence`` must be normalized to the inclusive range ``0..1`` by the
    OCR adapter.
    """

    text: str
    confidence: float
    box: BoundingBox

    def __post_init__(self) -> None:
        if not isfinite(self.confidence) or not 0.0 <= self.confidence <= 1.0:
            raise ValueError("OCR confidence must be between 0 and 1")
        if not isinstance(self.text, str):
            raise TypeError("OCR token text must be a string")


@dataclass(frozen=True, slots=True)
class OCRPage:
    """OCR tokens and geometry for one rendered invoice page."""

    page_number: int
    width: float
    height: float
    tokens: tuple[OCRToken, ...]

    def __post_init__(self) -> None:
        if self.page_number < 1:
            raise ValueError("Page numbers are one-based")
        if not isfinite(self.width) or not isfinite(self.height):
            raise ValueError("Page dimensions must be finite")
        if self.width <= 0 or self.height <= 0:
            raise ValueError("Page dimensions must be positive")
        if not isinstance(self.tokens, tuple):
            object.__setattr__(self, "tokens", tuple(self.tokens))

