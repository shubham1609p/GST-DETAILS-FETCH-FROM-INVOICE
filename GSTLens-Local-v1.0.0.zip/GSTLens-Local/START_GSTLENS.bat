@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo GSTLens Local is not installed yet.
  echo Run INSTALL_WINDOWS.bat first.
  pause
  exit /b 1
)
title GSTLens Local
".venv\Scripts\python.exe" -m gstlens_app.main
if errorlevel 1 (
  echo.
  echo GSTLens stopped with an error. The message above explains what to fix.
  pause
)

