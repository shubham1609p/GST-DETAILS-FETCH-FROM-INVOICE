# Third-party notices

GSTLens Local is designed to use these open-source components. The exact installed versions are recorded by the customer's Python environment.

- PaddleOCR and PP-OCR model family — Apache License 2.0 — <https://github.com/PaddlePaddle/PaddleOCR>
- PaddlePaddle — Apache License 2.0 — <https://github.com/PaddlePaddle/Paddle>
- pypdfium2 — Apache-2.0/BSD-3-Clause bindings; bundled PDFium has its own BSD-style notices — <https://github.com/pypdfium2-team/pypdfium2>
- OpenCV — Apache License 2.0 — <https://github.com/opencv/opencv>
- FastAPI — MIT License — <https://github.com/fastapi/fastapi>
- openpyxl — MIT License — <https://foss.heptapod.net/openpyxl/openpyxl>
- Pillow — HPND License — <https://github.com/python-pillow/Pillow>
- Argon2 CFFI — MIT License — <https://github.com/hynek/argon2-cffi>

Customer distributions must retain the license and notice files required by the installed components and locally bundled OCR models.

