$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

Write-Host ""
Write-Host "GSTLens Local installer" -ForegroundColor Cyan
Write-Host "OCR runs on this computer. No API key or cloud account is required."
Write-Host ""

$Python = $null
foreach ($Version in @("3.11", "3.12")) {
    try {
        & py "-$Version" -c "import sys; assert sys.maxsize > 2**32" 2>$null
        if ($LASTEXITCODE -eq 0) {
            $Python = @("py", "-$Version")
            break
        }
    } catch { }
}

if ($null -eq $Python) {
    throw "Install 64-bit Python 3.11 or 3.12 from python.org, tick 'Add Python to PATH', then run this installer again."
}

$PythonExe = $Python[0]
$PythonVersionArg = $Python[1]

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Creating the private GSTLens Python environment..."
    & $PythonExe $PythonVersionArg -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw "Could not create the Python environment." }
}

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
Write-Host "Installing application and OCR engine. This may take several minutes..."
& $VenvPython -m pip install --upgrade pip wheel
if ($LASTEXITCODE -ne 0) { throw "Could not update pip." }
& $VenvPython -m pip install -r requirements-ocr.txt
if ($LASTEXITCODE -ne 0) { throw "Could not install the OCR packages. Check the internet connection and free disk space." }

Write-Host "Downloading the open-source printed and handwriting OCR models for offline use..."
& $VenvPython -m gstlens_app.model_manager download
if ($LASTEXITCODE -ne 0) { throw "Could not download the local OCR models." }

Write-Host ""
Write-Host "Configure the administrator and shared operator access." -ForegroundColor Yellow
& $VenvPython -m gstlens_app.setup_cli
if ($LASTEXITCODE -ne 0) { throw "First-time login setup did not complete." }

Write-Host ""
Write-Host "Running installation checks..."
& $VenvPython -m gstlens_app.diagnostics
if ($LASTEXITCODE -ne 0) { throw "Installation checks failed." }

Write-Host ""
Write-Host "Installation complete." -ForegroundColor Green
