@echo off
setlocal
cd /d "%~dp0"
title GSTLens Local - Installation
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install_windows.ps1"
if errorlevel 1 (
  echo.
  echo Installation did not complete. Read the message above, then run this file again.
  pause
  exit /b 1
)
echo.
echo GSTLens Local is installed. Double-click START_GSTLENS.bat whenever you want to use it.
pause

