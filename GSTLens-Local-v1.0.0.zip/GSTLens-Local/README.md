# GSTLens Local

GSTLens Local is a private, Windows-ready invoice reconciliation application. It reads supplier invoice PDFs on the user's computer, extracts invoice numbers and HSN/SAC codes, matches them to an uploaded Excel workbook, and produces a copy of that workbook with the HSN/SAC column updated.

It does **not** send invoices to an OCR API. PaddleOCR runs locally and the original workbook is never modified.

## Exact output rules

| Condition | Value written to the selected HSN/SAC column |
|---|---|
| Invoice PDF matched and codes found | Every unique code in document order, separated by `, ` |
| No matching invoice PDF | `Invoice Missing` |
| Invoice PDF matched but no HSN/SAC is present | `Invoice Found but HSN not mentioned` |
| OCR or matching is uncertain | Held in Review; never silently guessed |

Both status phrases can be changed in the mapping screen. Existing HSN/SAC cells are overwritten only in the generated output copy.

## Why this works better than Tesseract.js

- OCR runs in a Python worker instead of a browser tab.
- PP-OCRv6-medium is the primary printed/scanned OCR engine and returns bounding boxes and confidence scores.
- Uncertain or empty fields receive a second local pass with the English PP-OCRv5 handwriting model. Agreement can strengthen a result; fallback-only or disagreeing text is held for review.
- HSN/SAC values are accepted only underneath an HSN/SAC-style label or table header. A random phone number, amount, GSTIN or handwritten calculation is not treated as a code.
- Invoice numbers are matched exactly after conservative normalisation. Collisions and fuzzy possibilities go to Review.
- Every processed PDF is committed to SQLite, so a large batch can resume after a restart.

## Install on Windows

Requirements: Windows 10/11, 64-bit Python 3.11 or 3.12, 8 GB RAM minimum (16 GB recommended), and roughly 3 GB free disk space during setup.

1. Extract the GSTLens Local ZIP to a normal folder.
2. Install 64-bit Python from `python.org` if it is not already present; select **Add Python to PATH**.
3. Double-click `INSTALL_WINDOWS.bat`.
4. Enter the administrator and shared operator access details when prompted. Passwords are stored only as salted hashes.
5. Double-click `START_GSTLENS.bat`.

The installer downloads the open-source printed and handwriting OCR weights once. After installation, invoice processing is offline and requires no API key, subscription, or cloud account. For an air-gapped computer, install once on a connected staging computer and copy the complete GSTLens data/model directory with the application.

## Normal workflow

1. Sign in with name, email and the configured access password.
2. Upload one `.xlsx`/`.xlsm` workbook and either a ZIP of PDFs or multiple PDFs.
3. Confirm the detected worksheet, header row, invoice-number column and HSN/SAC column. Column G is selected automatically when its header is detected, but it is never assumed blindly.
4. Start processing. Large jobs can be paused, resumed or retried.
5. Review low-confidence handwriting, duplicate invoice numbers, conflicting PDFs and possible matches using the displayed page evidence.
6. Download the updated workbook and the audit CSV.

The Dashboard shows matched invoices, missing PDFs, invoices without HSN, items requiring review, orphan PDFs, duplicates and completion percentage. Insights are evidence-based operational observations, not legal or tax advice.

## Accuracy policy

No general OCR model can promise zero error on every arbitrary handwritten invoice. GSTLens therefore optimises for **precision**, not silent automation:

- strong context and geometry checks before accepting a code;
- independent printed/handwriting OCR agreement on difficult fields;
- exact invoice-number matching;
- confidence thresholds;
- visible evidence and a fast review queue for uncertainty;
- an audit record of every manual correction.

The safe production target is 100% rows accounted for after review, not a dishonest promise that every handwritten digit will always be automatic.

## Supported input

- `.xlsx` and `.xlsm` workbooks;
- PDF invoices directly or inside a ZIP, including nested folders;
- native-text PDFs and scanned image PDFs;
- multi-page invoices;
- 4-, 6- and 8-digit HSN/SAC values;
- multiple HSN/SAC values per invoice.

Encrypted ZIPs, password-protected PDFs, unsafe archive paths, non-PDF archive contents and decompression bombs are rejected or logged safely.

## Local data

On Windows, data is stored under `%LOCALAPPDATA%\GSTLens` by default:

- `gstlens.sqlite3` — users, batch progress, review decisions and audit history;
- `models` — local OCR weights;
- `batches` — private uploaded files and generated outputs;
- `evidence` — page previews/crops used by Review.

Set `GSTLENS_DATA_DIR` before starting to use another protected location. Back up this directory if the audit history must be retained.

## Configuration

Optional environment variables:

| Variable | Default | Purpose |
|---|---:|---|
| `GSTLENS_DATA_DIR` | Windows local application data | Private runtime storage |
| `GSTLENS_MODEL_DIR` | `<data>/models` | Pre-downloaded OCR models |
| `GSTLENS_DEVICE` | `cpu` | `cpu` or a supported Paddle device such as `gpu:0` |
| `GSTLENS_PORT` | `8765` | Local browser port |
| `GSTLENS_RENDER_DPI` | `300` | Scan rendering resolution |
| `GSTLENS_AUTO_ACCEPT_CONFIDENCE` | `0.88` | Minimum automatic confidence |

The browser server binds to `127.0.0.1` only. It is not exposed to the LAN or internet.

## Developer checks

```powershell
.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.venv\Scripts\python.exe -m pytest -q
.venv\Scripts\python.exe -m gstlens_app.diagnostics
```

The OCR adapter is lazy-loaded, so extraction/matching/workbook tests run without loading a model into memory.

## Model and library licensing

GSTLens uses the Apache-2.0 PaddleOCR project and PP-OCRv6 model family. PDF pages are rendered with `pypdfium2`/PDFium. See `THIRD_PARTY_NOTICES.md` and retain those notices in customer distributions.

Official model documentation:

- <https://www.paddleocr.ai/latest/en/version3.x/pipeline_usage/OCR.html>
- <https://www.paddleocr.ai/latest/en/version3.x/algorithm/PP-OCRv6/PP-OCRv6.html>
