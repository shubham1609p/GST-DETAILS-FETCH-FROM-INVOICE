(function () {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const state = {
    session: null,
    dashboard: null,
    batches: [],
    activeBatchId: null,
    uploadBatch: null,
    workbookFile: null,
    zipFile: null,
    pdfFiles: [],
    results: [],
    resultById: new Map(),
    resultPage: 1,
    resultPages: 1,
    resultSummary: {},
    selectedResultId: null,
    pollingTimer: null,
    searchTimer: null,
    activityIds: new Set(),
    currentView: "dashboard",
    confirmResolver: null,
  };

  const viewMeta = {
    dashboard: ["Overview", "Your reconciliation workspace"],
    upload: ["New reconciliation", "Upload and map your documents"],
    processing: ["Processing", "Local OCR and invoice matching"],
    review: ["Review queue", "Verify uncertain or exceptional results"],
    insights: ["GST insights", "Patterns found in your uploaded invoices"],
    batches: ["Batch history", "Reopen, audit or download past work"],
    admin: ["Login activity", "Local workspace access log"],
  };

  const statusLabels = {
    queued: "Queued",
    processing: "Processing",
    paused: "Paused",
    completed: "Completed",
    cancelled: "Cancelled",
    error: "Error",
    matched: "Matched",
    needs_review: "Needs review",
    invoice_missing: "Invoice missing",
    hsn_missing: "HSN missing",
    approved: "Approved",
  };

  function icon(name) {
    return `<svg aria-hidden="true"><use href="#i-${name}"></use></svg>`;
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function safeId(value) {
    return escapeHtml(String(value ?? "").replace(/[^a-zA-Z0-9_-]/g, ""));
  }

  function number(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function formatNumber(value) {
    return new Intl.NumberFormat("en-IN").format(number(value));
  }

  function formatPercent(value, digits = 0) {
    let numeric = number(value);
    if (numeric > 0 && numeric <= 1) numeric *= 100;
    return `${numeric.toFixed(digits)}%`;
  }

  function confidenceValue(value) {
    let numeric = number(value);
    if (numeric > 0 && numeric <= 1) numeric *= 100;
    return Math.max(0, Math.min(100, numeric));
  }

  function formatBytes(bytes) {
    const size = number(bytes);
    if (!size) return "0 bytes";
    const units = ["bytes", "KB", "MB", "GB"];
    const index = Math.min(Math.floor(Math.log(size) / Math.log(1024)), units.length - 1);
    const value = size / Math.pow(1024, index);
    return `${value.toFixed(index ? 1 : 0)} ${units[index]}`;
  }

  function columnToNumber(value) {
    if (/^\d+$/.test(String(value))) return Number(value);
    const letters = String(value || "").trim().toUpperCase();
    if (!/^[A-Z]{1,3}$/.test(letters)) return 0;
    return letters.split("").reduce((total, letter) => total * 26 + letter.charCodeAt(0) - 64, 0);
  }

  function formatDate(value, includeTime = true) {
    if (!value) return "—";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return escapeHtml(value);
    return new Intl.DateTimeFormat("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      ...(includeTime ? { hour: "2-digit", minute: "2-digit" } : {}),
    }).format(date);
  }

  function relativeDate(value) {
    if (!value) return "—";
    const date = new Date(value);
    const delta = Date.now() - date.getTime();
    if (!Number.isFinite(delta)) return formatDate(value);
    const minutes = Math.floor(delta / 60000);
    if (minutes < 1) return "just now";
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hr ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} day${days === 1 ? "" : "s"} ago`;
    return formatDate(value, false);
  }

  function initials(name, email) {
    const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
    if (parts.length > 1) return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return String(email || "U").slice(0, 1).toUpperCase();
  }

  function statusMarkup(status) {
    const key = status || "queued";
    return `<span class="status status--${escapeHtml(key)}">${escapeHtml(statusLabels[key] || String(key).replaceAll("_", " "))}</span>`;
  }

  async function api(path, options = {}) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), options.timeout || 30000);
    const config = {
      method: options.method || "GET",
      credentials: "same-origin",
      signal: controller.signal,
      headers: { Accept: "application/json", ...(options.headers || {}) },
    };

    if (options.body instanceof FormData) {
      config.body = options.body;
    } else if (options.body !== undefined) {
      config.headers["Content-Type"] = "application/json";
      config.body = JSON.stringify(options.body);
    }

    try {
      const response = await fetch(path, config);
      const contentType = response.headers.get("content-type") || "";
      const payload = contentType.includes("application/json")
        ? await response.json()
        : await response.text();

      if (!response.ok) {
        const message = payload?.detail || payload?.message || payload || `Request failed (${response.status})`;
        const error = new Error(String(message));
        error.status = response.status;
        error.payload = payload;
        throw error;
      }
      return payload;
    } catch (error) {
      if (error.name === "AbortError") throw new Error("The local service took too long to respond. Please try again.");
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  function setButtonBusy(button, busy, busyLabel) {
    if (!button) return;
    if (busy) {
      button.dataset.originalHtml = button.innerHTML;
      button.disabled = true;
      button.innerHTML = `<span class="spinner" style="width:16px;height:16px"></span><span>${escapeHtml(busyLabel || "Working…")}</span>`;
    } else {
      if (button.dataset.originalHtml) button.innerHTML = button.dataset.originalHtml;
      delete button.dataset.originalHtml;
      button.disabled = false;
    }
  }

  function showToast(title, message = "", kind = "success", duration = 4800) {
    const region = $("#toast-region");
    const toast = document.createElement("div");
    toast.className = `toast toast--${kind}`;
    const iconName = kind === "danger" ? "alert" : kind === "warning" ? "info" : "check";
    toast.innerHTML = `${icon(iconName)}<span><b>${escapeHtml(title)}</b>${message ? `<small>${escapeHtml(message)}</small>` : ""}</span><button type="button" aria-label="Dismiss notification">${icon("x")}</button>`;
    toast.querySelector("button").addEventListener("click", () => toast.remove());
    region.appendChild(toast);
    if (duration) window.setTimeout(() => toast.remove(), duration);
  }

  function showInlineError(element, message) {
    element.textContent = message;
    element.hidden = !message;
  }

  function confirmAction(title, message, confirmText = "Confirm") {
    const dialog = $("#confirm-dialog");
    $("#dialog-title").textContent = title;
    $("#dialog-message").textContent = message;
    $("#dialog-confirm").textContent = confirmText;
    dialog.showModal();
    return new Promise((resolve) => {
      state.confirmResolver = resolve;
    });
  }

  function handleDialogClose(event) {
    const confirmed = event.target.returnValue === "confirm";
    if (state.confirmResolver) state.confirmResolver(confirmed);
    state.confirmResolver = null;
  }

  function goToView(name) {
    if (!viewMeta[name]) return;
    if (name === "admin" && state.session?.user?.role !== "admin") return;
    state.currentView = name;
    $$(".view").forEach((view) => view.classList.toggle("is-active", view.id === `view-${name}`));
    $$(".nav-item[data-view]").forEach((button) => button.classList.toggle("is-active", button.dataset.view === name));
    $("#page-title").textContent = viewMeta[name][0];
    $("#page-kicker").textContent = viewMeta[name][1];
    closeSidebar();
    window.scrollTo({ top: 0, behavior: "smooth" });
    $("#main-content").focus({ preventScroll: true });

    if (name === "review") loadResults();
    if (name === "insights") loadInsights();
    if (name === "batches") renderBatches();
    if (name === "admin") loadLoginActivity();
    if (name === "processing" && state.activeBatchId) loadActiveBatch();
  }

  function openSidebar() {
    $("#sidebar").classList.add("is-open");
    $("#sidebar-scrim").hidden = false;
    document.body.classList.add("is-locked");
  }

  function closeSidebar() {
    $("#sidebar").classList.remove("is-open");
    $("#sidebar-scrim").hidden = true;
    if (!$("#evidence-drawer").classList.contains("is-open")) document.body.classList.remove("is-locked");
  }

  function setEngineState(status, label) {
    const chip = $("#engine-chip");
    chip.classList.remove("is-busy", "is-error");
    if (status === "busy") chip.classList.add("is-busy");
    if (status === "error") chip.classList.add("is-error");
    chip.lastChild.textContent = label || (status === "error" ? "OCR unavailable" : status === "busy" ? "OCR working" : "OCR ready");
  }

  async function initialize() {
    bindEvents();
    try {
      const session = await api("/api/auth/me", { timeout: 8000 });
      if (session?.authenticated || session?.user || session?.email) {
        state.session = session;
        await enterApp();
      }
    } catch (error) {
      if (error.status !== 401) {
        showInlineError($("#login-error"), "The GSTLens local service is not responding. Start GSTLens Local, then refresh this page.");
      }
    }
  }

  async function enterApp() {
    const user = state.session?.user || state.session || {};
    $("#login-screen").hidden = true;
    $("#app-shell").hidden = false;
    $("#sidebar-user-name").textContent = user.name || user.display_name || "GSTLens user";
    $("#sidebar-user-email").textContent = user.email || "Local workspace";
    $("#sidebar-avatar").textContent = initials(user.name || user.display_name, user.email);
    $("#admin-nav").hidden = user.role !== "admin";
    goToView("dashboard");
    await Promise.allSettled([loadDashboard(), loadBatches(), checkHealth()]);
  }

  async function handleLogin(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const role = data.get("role") || "user";
    const name = String(data.get("name") || "").trim();
    const email = String(data.get("email") || "").trim();
    const password = String(data.get("password") || "");
    let valid = true;

    $$(".field-error", form).forEach((node) => (node.textContent = ""));
    if (role !== "admin" && !name) {
      $("[data-error-for='name']").textContent = "Enter your name.";
      valid = false;
    }
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      $("[data-error-for='email']").textContent = "Enter a valid email address.";
      valid = false;
    }
    if (!password) {
      $("[data-error-for='password']").textContent = "Enter your password.";
      valid = false;
    }
    if (!valid) return;

    const button = $("#login-submit");
    showInlineError($("#login-error"), "");
    setButtonBusy(button, true, "Signing in…");
    try {
      const session = await api("/api/auth/login", { method: "POST", body: { display_name: name, email, password } });
      state.session = session;
      form.reset();
      await enterApp();
    } catch (error) {
      showInlineError($("#login-error"), error.message || "Sign-in failed. Check your details and try again.");
    } finally {
      setButtonBusy(button, false);
    }
  }

  async function logout() {
    try {
      await api("/api/auth/logout", { method: "POST" });
    } catch (_) {
      // Local sign-out should still clear the UI when the service restarts mid-session.
    }
    stopPolling();
    closeEvidence();
    state.session = null;
    state.batches = [];
    state.activeBatchId = null;
    $("#app-shell").hidden = true;
    $("#login-screen").hidden = false;
    showInlineError($("#login-error"), "");
    $("#login-email").focus();
  }

  function updateRoleFields() {
    const admin = $("input[name='role']:checked").value === "admin";
    const nameField = $("#login-name").closest("label");
    nameField.hidden = admin;
    $("#login-name").required = !admin;
    if (admin) $("#login-name").value = "";
  }

  async function checkHealth() {
    try {
      const health = await api("/api/health", { timeout: 6000 });
      if (health?.ocr_ready === false || health?.status === "degraded") setEngineState("error", "OCR setup needed");
      else setEngineState("ready", health?.engine_label || "OCR ready");
    } catch (_) {
      setEngineState("error", "Service unavailable");
    }
  }

  async function loadDashboard() {
    try {
      state.dashboard = await api("/api/dashboard");
      renderDashboard();
    } catch (error) {
      state.dashboard = { summary: {} };
      renderDashboard();
      showToast("Dashboard could not refresh", error.message, "warning");
    }
  }

  function renderDashboard() {
    const payload = state.dashboard || {};
    const summary = payload.summary || payload.totals || payload;
    const cards = [
      ["file", "Invoices processed", summary.invoices_processed ?? summary.total_invoices ?? summary.total_rows ?? summary.total_docs, "teal", summary.invoices_change],
      ["check", "Matched automatically", summary.matched ?? summary.auto_matched, "green", summary.match_rate ? `${formatPercent(summary.match_rate)} match rate` : ""],
      ["review", "Awaiting review", summary.needs_review ?? summary.review_count ?? summary.review, "amber", ""],
      ["history", "Saved batches", summary.completed_batches ?? summary.batches_completed ?? summary.batches, "blue", ""],
    ];
    $("#dashboard-kpis").innerHTML = cards.map(([iconName, label, value, color, note]) => `
      <article class="kpi-card kpi-card--${color}">
        <span>${icon(iconName)}</span><small>${escapeHtml(label)}</small><strong>${formatNumber(value)}</strong>${note ? `<em>${escapeHtml(note)}</em>` : ""}
      </article>`).join("");

    const recent = payload.recent_batches || state.batches.slice(0, 4);
    const container = $("#recent-batches");
    if (!recent.length) {
      container.innerHTML = `<div class="empty-state empty-state--small" style="min-height:180px"><span class="empty-icon">${icon("upload")}</span><h3>Start your first batch</h3><p>Your recent work will appear here.</p><button class="button button--primary" data-go="upload">Upload files</button></div>`;
    } else {
      container.innerHTML = recent.slice(0, 4).map((batch) => {
        const id = batch.id ?? batch.batch_id;
        return `<div class="batch-list-item"><span class="batch-list-icon">${icon("file")}</span><span><b>${escapeHtml(batch.name || batch.label || batch.workbook_name || batch.workbook_original_name || "Reconciliation batch")}</b><small>${formatNumber(batch.invoice_count ?? batch.total ?? batch.total_rows ?? batch.total_docs)} invoices · ${escapeHtml(batch.created_by || "Local user")}</small></span><em>${relativeDate(batch.updated_at || batch.completed_at || batch.started_at || batch.created_at)}</em><button class="row-action" data-open-batch="${safeId(id)}" aria-label="Open batch">${icon("arrow")}</button></div>`;
      }).join("");
    }

    if (payload.tip) {
      $("#dashboard-tip-title").textContent = payload.tip.title || "A safer export starts with review";
      $("#dashboard-tip-text").textContent = payload.tip.text || payload.tip.message || "Low-confidence results wait for a human check.";
    }
    updateNavigationBadges(summary);
  }

  function updateNavigationBadges(summary = {}) {
    const reviewCount = number(summary.needs_review ?? summary.review_count ?? summary.review ?? state.resultSummary.needs_review);
    const processingCount = state.batches.filter((batch) => ["processing", "queued"].includes(batch.status)).length;
    const reviewBadge = $("#nav-review-badge");
    const processingBadge = $("#nav-processing-badge");
    reviewBadge.textContent = formatNumber(reviewCount);
    reviewBadge.hidden = reviewCount === 0;
    processingBadge.textContent = formatNumber(processingCount);
    processingBadge.hidden = processingCount === 0;
  }

  function configureDropZone(zone, input, acceptFiles) {
    ["dragenter", "dragover"].forEach((name) => zone.addEventListener(name, (event) => {
      event.preventDefault();
      zone.classList.add("is-dragover");
    }));
    ["dragleave", "drop"].forEach((name) => zone.addEventListener(name, (event) => {
      event.preventDefault();
      zone.classList.remove("is-dragover");
    }));
    zone.addEventListener("drop", (event) => acceptFiles(Array.from(event.dataTransfer.files || [])));
    input?.addEventListener("change", () => acceptFiles(Array.from(input.files || [])));
  }

  function acceptWorkbook(files) {
    const file = files[0];
    if (!file) return;
    if (!/\.(xlsx|xlsm)$/i.test(file.name)) {
      showInlineError($("#upload-error"), "Choose an .xlsx or .xlsm workbook. Older .xls files must be saved as .xlsx first.");
      return;
    }
    state.workbookFile = file;
    showInlineError($("#upload-error"), "");
    renderSelectedFiles();
  }

  function acceptInvoices(files) {
    if (!files.length) return;
    const zip = files.find((file) => /\.zip$/i.test(file.name));
    const pdfs = files.filter((file) => /\.pdf$/i.test(file.name) || file.type === "application/pdf");
    if (zip && pdfs.length) {
      showInlineError($("#upload-error"), "Choose either one ZIP or PDF files—not both in the same batch.");
      return;
    }
    if (zip) {
      state.zipFile = zip;
      state.pdfFiles = [];
    } else if (pdfs.length) {
      state.pdfFiles = pdfs;
      state.zipFile = null;
    } else {
      showInlineError($("#upload-error"), "Invoice collection must be a .zip file or one or more PDF files.");
      return;
    }
    showInlineError($("#upload-error"), "");
    renderSelectedFiles();
  }

  function renderSelectedFiles() {
    const workbookZone = $("#workbook-drop");
    const workbookSelected = $(".selected-file", workbookZone);
    workbookZone.classList.toggle("has-file", Boolean(state.workbookFile));
    workbookSelected.hidden = !state.workbookFile;
    if (state.workbookFile) {
      $("b", workbookSelected).textContent = state.workbookFile.name;
      $("small", workbookSelected).textContent = formatBytes(state.workbookFile.size);
    }

    const invoiceZone = $("#invoice-drop");
    const invoiceSelected = $(".selected-file", invoiceZone);
    const hasInvoices = Boolean(state.zipFile || state.pdfFiles.length);
    invoiceZone.classList.toggle("has-file", hasInvoices);
    invoiceSelected.hidden = !hasInvoices;
    if (hasInvoices) {
      $("b", invoiceSelected).textContent = state.zipFile ? state.zipFile.name : `${state.pdfFiles.length} PDF invoice${state.pdfFiles.length === 1 ? "" : "s"}`;
      const bytes = state.zipFile?.size || state.pdfFiles.reduce((sum, file) => sum + file.size, 0);
      $("small", invoiceSelected).textContent = state.zipFile ? formatBytes(bytes) : `${formatBytes(bytes)} total`;
    }

    const ready = Boolean(state.workbookFile && hasInvoices);
    $("#prepare-button").disabled = !ready;
    const totalBytes = number(state.workbookFile?.size) + number(state.zipFile?.size) + state.pdfFiles.reduce((sum, file) => sum + file.size, 0);
    $("#upload-size-summary").textContent = ready
      ? `${state.pdfFiles.length || "ZIP"} invoice source · ${formatBytes(totalBytes)} · processed locally`
      : "Choose both file types to continue.";
  }

  function resetUpload() {
    state.workbookFile = null;
    state.zipFile = null;
    state.pdfFiles = [];
    state.uploadBatch = null;
    $("#workbook-input").value = "";
    $("#zip-input").value = "";
    $("#pdf-input").value = "";
    $("#mapping-panel").hidden = true;
    $("#start-button").hidden = true;
    $("#prepare-button").hidden = false;
    $$(".workflow-stepper span").forEach((step) => step.classList.remove("is-done", "is-current"));
    $(".workflow-stepper [data-step='1']").classList.add("is-current");
    renderSelectedFiles();
  }

  async function prepareBatch(event) {
    event.preventDefault();
    if (!state.workbookFile || (!state.zipFile && !state.pdfFiles.length)) return;
    const button = $("#prepare-button");
    const form = new FormData();
    form.append("workbook", state.workbookFile);
    if (state.zipFile) form.append("invoices", state.zipFile);
    state.pdfFiles.forEach((file) => form.append("invoices", file));
    form.append("label", state.workbookFile.name.replace(/\.(xlsx|xlsm)$/i, ""));
    form.append("missing_label", $("#missing-label").value);
    form.append("hsn_missing_label", $("#hsn-missing-label").value);
    showInlineError($("#upload-error"), "");
    setButtonBusy(button, true, "Inspecting workbook…");
    setEngineState("busy", "Inspecting files");
    try {
      const payload = await api("/api/batches", { method: "POST", body: form, timeout: 120000 });
      state.uploadBatch = payload.batch || payload;
      state.activeBatchId = state.uploadBatch.id ?? state.uploadBatch.batch_id;
      renderMapping(state.uploadBatch);
      $("#mapping-panel").hidden = false;
      $("#mapping-panel").scrollIntoView({ behavior: "smooth", block: "start" });
      $("#prepare-button").hidden = true;
      $("#start-button").hidden = false;
      $(".workflow-stepper [data-step='1']").classList.remove("is-current");
      $(".workflow-stepper [data-step='1']").classList.add("is-done");
      $(".workflow-stepper [data-step='2']").classList.add("is-current");
      showToast("Workbook inspected", "Confirm the detected invoice and HSN/SAC columns.");
    } catch (error) {
      showInlineError($("#upload-error"), error.message);
    } finally {
      setButtonBusy(button, false);
      setEngineState("ready");
    }
  }

  function normalizeColumns(mapping) {
    const columns = mapping.columns || mapping.headers || [];
    return columns.map((column, index) => {
      if (typeof column === "string") return { key: column, label: column };
      return { key: column.key || column.letter || column.value || String(index + 1), label: column.label || column.header || column.name || column.letter || `Column ${index + 1}` };
    });
  }

  function renderMapping(batch) {
    const mapping = batch.mapping || batch.workbook?.mapping || batch;
    const sheets = batch.workbook?.sheets || mapping.sheets || [];
    const sheetNames = sheets.map((sheet) => typeof sheet === "string" ? sheet : sheet.name);
    const selectedSheet = mapping.sheet || mapping.sheet_name || sheetNames[0] || "Sheet1";
    const columns = normalizeColumns(mapping);

    $("#mapping-sheet").innerHTML = (sheetNames.length ? sheetNames : [selectedSheet]).map((name) => `<option value="${escapeHtml(name)}"${name === selectedSheet ? " selected" : ""}>${escapeHtml(name)}</option>`).join("");
    const columnOptions = columns.map((column) => `<option value="${escapeHtml(column.key)}">${escapeHtml(column.key)} — ${escapeHtml(column.label)}</option>`).join("");
    $("#mapping-invoice-column").innerHTML = columnOptions;
    $("#mapping-hsn-column").innerHTML = columnOptions;
    $("#mapping-invoice-column").value = mapping.invoice_column || mapping.invoice_col || columns[0]?.key || "";
    $("#mapping-hsn-column").value = mapping.hsn_column || mapping.hsn_col || columns[1]?.key || "";
    $("#mapping-header-row").value = mapping.header_row || 1;
    const confidence = confidenceValue(mapping.confidence || mapping.detection_confidence || 95);
    $("#mapping-confidence").textContent = confidence >= 85 ? "Detected with high confidence" : "Please verify";
    $("#mapping-confidence").className = `confidence-chip ${confidence >= 85 ? "confidence-chip--good" : "confidence-chip--medium"}`;
    renderMappingPreview(mapping.preview || batch.workbook?.preview || [], columns);
  }

  function renderMappingPreview(rows, columns) {
    const invoiceColumn = $("#mapping-invoice-column").value;
    const hsnColumn = $("#mapping-hsn-column").value;
    $("#mapping-preview-head").innerHTML = `<tr>${columns.map((column) => `<th class="${column.key === invoiceColumn ? "is-invoice" : column.key === hsnColumn ? "is-hsn" : ""}" title="${escapeHtml(column.label)}">${escapeHtml(column.key)} · ${escapeHtml(column.label)}</th>`).join("")}</tr>`;
    $("#mapping-preview-body").innerHTML = rows.slice(0, 7).map((row) => `<tr>${columns.map((column, index) => {
      const value = Array.isArray(row) ? row[index] : row[column.key] ?? row[column.label];
      return `<td class="${column.key === invoiceColumn ? "is-invoice" : column.key === hsnColumn ? "is-hsn" : ""}">${escapeHtml(value ?? "")}</td>`;
    }).join("")}</tr>`).join("");
  }

  async function refreshMappingPreview() {
    if (!state.activeBatchId) return;
    const params = new URLSearchParams({
      sheet: $("#mapping-sheet").value,
      header_row: $("#mapping-header-row").value,
    });
    try {
      const payload = await api(`/api/batches/${encodeURIComponent(state.activeBatchId)}/mapping-preview?${params}`);
      state.uploadBatch.mapping = { ...(state.uploadBatch.mapping || {}), ...payload };
      renderMapping(state.uploadBatch);
    } catch (error) {
      showToast("Could not refresh preview", error.message, "warning");
    }
  }

  async function startProcessing() {
    if (!state.activeBatchId) return;
    const invoiceColumn = $("#mapping-invoice-column").value;
    const hsnColumn = $("#mapping-hsn-column").value;
    if (!invoiceColumn || !hsnColumn || invoiceColumn === hsnColumn) {
      showInlineError($("#upload-error"), "Choose two different columns for invoice number and HSN/SAC output.");
      return;
    }
    const button = $("#start-button");
    setButtonBusy(button, true, "Starting local OCR…");
    setEngineState("busy", "Starting OCR");
    try {
      await api(`/api/batches/${encodeURIComponent(state.activeBatchId)}/mapping`, {
        method: "PATCH",
        body: {
          sheet_name: $("#mapping-sheet").value,
          header_row: number($("#mapping-header-row").value),
          invoice_col: columnToNumber(invoiceColumn),
          hsn_col: columnToNumber(hsnColumn),
          missing_phrase: $("#missing-label").value,
          found_no_hsn_phrase: $("#hsn-missing-label").value,
        },
      });
      await api(`/api/batches/${encodeURIComponent(state.activeBatchId)}/action`, { method: "POST", body: { action: "start" } });
      $(".workflow-stepper [data-step='2']").classList.remove("is-current");
      $(".workflow-stepper [data-step='2']").classList.add("is-done");
      $(".workflow-stepper [data-step='3']").classList.add("is-current");
      showToast("Processing started", "You can leave the progress page and return later.");
      goToView("processing");
      startPolling();
      loadBatches();
    } catch (error) {
      showInlineError($("#upload-error"), error.message);
      setEngineState("error", "Could not start OCR");
    } finally {
      setButtonBusy(button, false);
    }
  }

  function startPolling() {
    stopPolling();
    loadActiveBatch();
    state.pollingTimer = window.setInterval(loadActiveBatch, 2500);
  }

  function stopPolling() {
    if (state.pollingTimer) window.clearInterval(state.pollingTimer);
    state.pollingTimer = null;
  }

  async function loadActiveBatch() {
    if (!state.activeBatchId) return;
    try {
      const payload = await api(`/api/batches/${encodeURIComponent(state.activeBatchId)}`);
      const batch = payload.batch || payload;
      renderProcessing(batch);
      if (["completed", "needs_review", "cancelled", "error"].includes(batch.status)) {
        stopPolling();
        setEngineState(batch.status === "error" ? "error" : "ready");
        await Promise.allSettled([loadBatches(), loadDashboard()]);
        if (["completed", "needs_review"].includes(batch.status) && !batch._completionShown) {
          batch._completionShown = true;
          showToast("Reconciliation complete", "Review uncertain results, then download the updated Excel.", "success", 7000);
        }
      } else if (batch.status === "paused") {
        setEngineState("ready", "OCR paused");
      } else {
        setEngineState("busy", "OCR working");
      }
    } catch (error) {
      setEngineState("error", "Progress unavailable");
      showToast("Could not refresh progress", error.message, "warning");
    }
  }

  function renderProcessing(batch) {
    $("#processing-empty").hidden = false;
    $("#processing-content").hidden = false;
    $("#processing-empty").hidden = true;
    const progress = batch.progress || {};
    const total = number(progress.total ?? batch.invoice_count ?? batch.total ?? batch.total_docs ?? batch.total_rows);
    const complete = number(progress.completed ?? progress.processed ?? batch.processed_count ?? batch.processed_docs);
    const percent = total ? Math.min(100, (complete / total) * 100) : number(progress.percent);
    const status = batch.status || "processing";
    const statusBadge = $("#process-status-badge");
    statusBadge.className = `status status--${status}`;
    statusBadge.textContent = statusLabels[status] || status;
    $("#process-started").textContent = batch.started_at ? `Started ${relativeDate(batch.started_at)}` : "Preparing";
    $("#process-batch-name").textContent = batch.name || batch.label || batch.workbook_name || batch.workbook_original_name || "Reconciliation batch";
    $("#process-detail").textContent = progress.stage_label || batch.message || (status === "paused" ? "Processing is paused. Completed invoices are safely saved." : "Reading invoices on this computer…");
    $("#process-complete-count").textContent = formatNumber(complete);
    $("#process-total-count").textContent = formatNumber(total);
    $("#process-percent").textContent = formatPercent(percent);
    $("#process-bar").style.width = `${percent}%`;
    $("#process-bar").parentElement.setAttribute("aria-valuenow", String(Math.round(percent)));
    $("#process-current-file").textContent = progress.current_file || (status === "completed" ? "All invoices processed" : "Preparing next invoice…");
    $("#process-eta").textContent = progress.eta_seconds ? `${Math.ceil(progress.eta_seconds / 60)} min estimated` : status === "completed" ? "Completed" : "Estimating time remaining";
    $("#process-matched").textContent = formatNumber(progress.matched ?? batch.matched_count);
    $("#process-review").textContent = formatNumber(progress.needs_review ?? batch.review_count);
    $("#process-missing").textContent = formatNumber(progress.missing ?? batch.missing_count);
    $("#process-pages").textContent = formatNumber(progress.pages_read ?? batch.pages_read);
    $("#pause-button").hidden = status !== "processing";
    $("#resume-button").hidden = status !== "paused";
    $("#cancel-button").hidden = !["processing", "paused", "queued"].includes(status);
    renderActivity(progress.activity || batch.activity || []);
    const load = Math.max(8, Math.min(95, number(progress.system_load || 42)));
    $("#system-load-bar").style.width = `${load}%`;
    $("#system-load-label").textContent = load > 78 ? "High" : load > 55 ? "Active" : "Balanced";
  }

  function renderActivity(items) {
    const list = $("#activity-feed");
    if (!items.length) {
      list.innerHTML = `<li class="activity-item"><b>Preparing local OCR engine</b><span>Models and document readers are warming up.</span></li>`;
      return;
    }
    list.innerHTML = items.slice(-12).reverse().map((item) => {
      const kind = item.kind || item.status || "";
      const className = ["matched", "success", "completed"].includes(kind) ? "activity-item--success" : ["review", "needs_review"].includes(kind) ? "activity-item--review" : "";
      return `<li class="activity-item ${className}"><b>${escapeHtml(item.title || item.file || item.message || "Invoice processed")}</b><span>${escapeHtml(item.detail || item.description || (item.created_at ? relativeDate(item.created_at) : ""))}</span></li>`;
    }).join("");
  }

  async function changeBatchState(action) {
    if (!state.activeBatchId) return;
    if (action === "cancel") {
      const confirmed = await confirmAction("Cancel this batch?", "Completed invoice results will remain saved, but unprocessed invoices will stop.", "Cancel batch");
      if (!confirmed) return;
    }
    try {
      await api(`/api/batches/${encodeURIComponent(state.activeBatchId)}/action`, { method: "POST", body: { action } });
      showToast(action === "pause" ? "Processing paused" : action === "resume" ? "Processing resumed" : "Batch cancelled");
      await loadActiveBatch();
      if (action === "resume") startPolling();
    } catch (error) {
      showToast(`Could not ${action} batch`, error.message, "danger");
    }
  }

  async function loadBatches() {
    try {
      const payload = await api("/api/batches");
      state.batches = payload.items || payload.batches || (Array.isArray(payload) ? payload : []);
      if (!state.activeBatchId) {
        const processing = state.batches.find((batch) => ["processing", "paused", "queued"].includes(batch.status));
        const latest = processing || state.batches[0];
        state.activeBatchId = latest?.id ?? latest?.batch_id ?? null;
        if (processing) startPolling();
      }
      renderBatches();
      populateBatchSelectors();
      updateNavigationBadges(state.dashboard?.summary || {});
    } catch (error) {
      showToast("Batch history could not refresh", error.message, "warning");
    }
  }

  function filteredBatches() {
    const query = String($("#batch-search")?.value || "").trim().toLowerCase();
    const status = $("#batch-status-filter")?.value || "all";
    return state.batches.filter((batch) => {
      const haystack = `${batch.name || ""} ${batch.label || ""} ${batch.workbook_name || ""} ${batch.workbook_original_name || ""} ${batch.created_by || ""}`.toLowerCase();
      return (!query || haystack.includes(query)) && (status === "all" || batch.status === status);
    });
  }

  function renderBatches() {
    const tbody = $("#batch-table-body");
    if (!tbody) return;
    const batches = filteredBatches();
    tbody.innerHTML = batches.map((batch) => {
      const id = batch.id ?? batch.batch_id;
      const total = number(batch.invoice_count ?? batch.total ?? batch.total_rows ?? batch.total_docs);
      const resolved = number(batch.resolved_count ?? batch.matched_count ?? batch.resolved);
      const resolvedRate = total ? (resolved / total) * 100 : number(batch.resolved_rate);
      const action = ["processing", "paused", "queued"].includes(batch.status) ? "processing" : "review";
      return `<tr>
        <td><div class="batch-name-cell"><span>${icon("file")}</span><span><strong>${escapeHtml(batch.name || batch.label || batch.workbook_name || batch.workbook_original_name || "Reconciliation batch")}</strong><small>${escapeHtml(batch.workbook_name || batch.workbook_original_name || `Batch ${id}`)}</small></span></div></td>
        <td>${escapeHtml(batch.created_by || "—")}</td><td>${formatNumber(total)}</td>
        <td class="resolved-cell"><span><span class="confidence-bar"><i style="width:${resolvedRate}%"></i></span><b>${formatPercent(resolvedRate)}</b></span></td>
        <td>${formatNumber(batch.review_count ?? batch.needs_review)}</td><td>${statusMarkup(batch.status)}</td>
        <td>${relativeDate(batch.updated_at || batch.completed_at || batch.started_at || batch.created_at)}</td>
        <td><div class="row-actions"><button class="row-action" data-open-batch="${safeId(id)}" data-target="${action}" aria-label="Open batch">${icon("eye")}</button>${batch.status === "completed" ? `<button class="row-action" data-download-batch="${safeId(id)}" aria-label="Download Excel">${icon("download")}</button>` : ""}</div></td>
      </tr>`;
    }).join("");
    $("#batch-empty").hidden = batches.length > 0;
    $("#batch-table-body").closest(".table-scroll").hidden = batches.length === 0;
  }

  function populateBatchSelectors() {
    const select = $("#insights-batch-select");
    if (!select) return;
    const eligible = state.batches.filter((batch) => ["completed", "needs_review"].includes(batch.status) || number(batch.processed_count) > 0);
    const current = select.value || String(state.activeBatchId || "");
    select.innerHTML = eligible.map((batch) => {
      const id = batch.id ?? batch.batch_id;
      return `<option value="${safeId(id)}"${String(id) === current ? " selected" : ""}>${escapeHtml(batch.name || batch.label || batch.workbook_name || batch.workbook_original_name || `Batch ${id}`)}</option>`;
    }).join("");
  }

  function openBatch(id, target) {
    state.activeBatchId = id;
    const batch = state.batches.find((item) => String(item.id ?? item.batch_id) === String(id));
    if (target) goToView(target);
    else goToView(["processing", "paused", "queued"].includes(batch?.status) ? "processing" : "review");
  }

  function reviewQuery() {
    const params = new URLSearchParams({ page: String(state.resultPage), page_size: "25" });
    const query = $("#review-search").value.trim();
    const status = $("#review-status-filter").value;
    const confidence = $("#review-confidence-filter").value;
    if (query) params.set("q", query);
    if (status !== "all") params.set("status", status);
    if (confidence !== "all") params.set("confidence", confidence);
    return params;
  }

  async function loadResults() {
    if (!state.activeBatchId) {
      const latest = state.batches.find((batch) => batch.status === "completed") || state.batches[0];
      state.activeBatchId = latest?.id ?? latest?.batch_id ?? null;
    }
    const tbody = $("#review-table-body");
    if (!state.activeBatchId) {
      state.results = [];
      renderResults();
      return;
    }
    $("#review-loading").hidden = false;
    tbody.closest(".table-scroll").hidden = true;
    $("#review-empty").hidden = true;
    try {
      const payload = await api(`/api/batches/${encodeURIComponent(state.activeBatchId)}/results?${reviewQuery()}`);
      state.results = payload.items || payload.results || (Array.isArray(payload) ? payload : []);
      state.resultSummary = payload.summary || {};
      state.resultPages = number(payload.pages || payload.total_pages) || 1;
      state.resultById = new Map(state.results.map((result) => [String(result.id ?? result.result_id), result]));
      renderResults();
    } catch (error) {
      showToast("Results could not load", error.message, "danger");
      state.results = [];
      renderResults();
    } finally {
      $("#review-loading").hidden = true;
    }
  }

  function normalizedCodes(value) {
    const source = Array.isArray(value) ? value : String(value || "").split(",");
    return [...new Set(source.map((item) => String(item).trim()).filter(Boolean))];
  }

  function renderResults() {
    const tbody = $("#review-table-body");
    tbody.innerHTML = state.results.map((result) => {
      const id = result.id ?? result.result_id;
      const confidence = confidenceValue(result.confidence ?? result.ocr_confidence);
      const confidenceClass = confidence < 70 ? "is-low" : confidence < 90 ? "is-medium" : "";
      const codes = normalizedCodes(result.hsn_codes ?? result.hsn_sac ?? result.hsn ?? result.output_value);
      const displayStatus = result.review_state === "accepted" || result.review_state === "approved" ? "approved" : result.status;
      const codeMarkup = codes.length ? `<span class="hsn-list">${codes.map((code) => `<span class="hsn-code">${escapeHtml(code)}</span>`).join("")}</span>` : `<span class="missing-text">${result.status === "invoice_missing" ? "Invoice not found" : "No HSN/SAC captured"}</span>`;
      return `<tr data-result-row="${safeId(id)}">
        <td><input class="row-check" type="checkbox" value="${safeId(id)}" aria-label="Select invoice ${escapeHtml(result.invoice_number || "")}"></td>
        <td><strong>${escapeHtml(result.invoice_number || result.excel_invoice_number || "—")}</strong><small>Row ${escapeHtml(result.excel_row || result.row_number || "—")}</small></td>
        <td><strong>${escapeHtml(result.supplier_name || result.supplier || "Unknown supplier")}</strong><small title="${escapeHtml(result.pdf_filename || "")}">${escapeHtml(result.pdf_filename || "No PDF matched")}</small></td>
        <td>${codeMarkup}</td>
        <td class="confidence-cell"><span><span class="confidence-bar ${confidenceClass}"><i style="width:${confidence}%"></i></span><b>${formatPercent(confidence)}</b></span></td>
        <td>${statusMarkup(displayStatus)}</td>
        <td><div class="row-actions"><button class="row-action" data-review-result="${safeId(id)}" aria-label="Review invoice ${escapeHtml(result.invoice_number || "")}">${icon("eye")}</button>${codes.length && !["approved", "edited", "resolved"].includes(result.review_state) ? `<button class="row-action" data-approve-result="${safeId(id)}" aria-label="Approve result">${icon("check")}</button>` : ""}</div></td>
      </tr>`;
    }).join("");

    const empty = state.results.length === 0;
    $("#review-empty").hidden = !empty;
    tbody.closest(".table-scroll").hidden = empty;
    const total = number(state.resultSummary.total ?? state.resultSummary.filtered_total ?? state.results.length);
    $("#review-count").textContent = `${formatNumber(total)} result${total === 1 ? "" : "s"}`;
    $("#review-page-label").textContent = `Page ${state.resultPage} of ${state.resultPages}`;
    $("#review-prev").disabled = state.resultPage <= 1;
    $("#review-next").disabled = state.resultPage >= state.resultPages;
    renderReviewKpis();
  }

  function renderReviewKpis() {
    const summary = state.resultSummary;
    const cards = [
      ["Total rows", summary.total ?? state.results.length, "in this batch"],
      ["Needs review", summary.needs_review, "check before export"],
      ["Invoice missing", summary.invoice_missing ?? summary.missing, "written to Excel"],
      ["Approved", summary.approved, "human verified"],
    ];
    $("#review-kpis").innerHTML = cards.map(([label, value, note]) => `<div class="mini-kpi"><small>${escapeHtml(label)}</small><strong>${formatNumber(value)}<em>${escapeHtml(note)}</em></strong></div>`).join("");
    updateNavigationBadges({ needs_review: summary.needs_review });
  }

  function openEvidence(id) {
    const result = state.resultById.get(String(id));
    if (!result) return;
    state.selectedResultId = id;
    const drawer = $("#evidence-drawer");
    drawer.classList.add("is-open");
    drawer.setAttribute("aria-hidden", "false");
    $("#drawer-scrim").hidden = false;
    document.body.classList.add("is-locked");
    $("#evidence-title").textContent = `Invoice ${result.invoice_number || result.excel_invoice_number || "review"}`;
    $("#evidence-page").textContent = result.page_number ? `Page ${result.page_number}` : "Invoice evidence";
    $("#evidence-caption").textContent = result.evidence_caption || result.reason || "The OCR region used for this result is shown above.";
    $("#editor-invoice").textContent = result.invoice_number || result.excel_invoice_number || "—";
    $("#editor-pdf-invoice").textContent = result.pdf_invoice_number || result.matched_invoice_number || "—";
    $("#editor-hsn").value = normalizedCodes(result.hsn_codes ?? result.hsn_sac ?? result.hsn ?? result.output_value).join(", ");
    $("#editor-status").value = result.status === "approved" ? "matched" : result.status || "needs_review";
    $("#editor-note").value = result.reviewer_note || result.review_note || result.note || "";
    const confidence = confidenceValue(result.confidence ?? result.ocr_confidence);
    $("#editor-confidence").textContent = formatPercent(confidence);
    $("#editor-confidence-bar").style.width = `${confidence}%`;
    $("#editor-confidence-bar").style.background = confidence < 70 ? "var(--red)" : confidence < 90 ? "var(--amber)" : "var(--green)";
    $("#editor-reason").textContent = result.reason || result.review_reason || (confidence < 70 ? "Low OCR confidence—compare the code with the invoice image." : "Invoice number and HSN/SAC context were detected.");
    $("#open-pdf").href = result.pdf_url || `/api/results/${encodeURIComponent(id)}/pdf`;
    loadEvidenceImage(result);
    window.setTimeout(() => $("#close-evidence").focus(), 220);
  }

  function loadEvidenceImage(result) {
    const image = $("#evidence-image");
    const loader = $("#evidence-image-loading");
    const error = $("#evidence-image-error");
    image.hidden = true;
    error.hidden = true;
    loader.hidden = false;
    image.onload = () => {
      loader.hidden = true;
      image.hidden = false;
    };
    image.onerror = () => {
      loader.hidden = true;
      error.hidden = false;
      image.hidden = true;
    };
    image.src = result.evidence_url || `/api/results/${encodeURIComponent(result.id ?? result.result_id)}/evidence`;
  }

  function closeEvidence() {
    $("#evidence-drawer").classList.remove("is-open");
    $("#evidence-drawer").setAttribute("aria-hidden", "true");
    $("#drawer-scrim").hidden = true;
    document.body.classList.remove("is-locked");
    state.selectedResultId = null;
  }

  function validateHsnInput() {
    const input = $("#editor-hsn");
    const status = $("#editor-status").value;
    const codes = normalizedCodes(input.value);
    let error = "";
    if (["matched", "needs_review"].includes(status) && !codes.length) error = "Enter at least one HSN/SAC code, or choose a missing status.";
    const invalid = codes.filter((code) => !/^\d{4}(?:\d{2})?(?:\d{2})?$/.test(code));
    if (invalid.length) error = `Check ${invalid.join(", ")}. Codes must contain 4, 6, or 8 digits.`;
    $("#editor-hsn-error").textContent = error;
    input.classList.toggle("is-invalid", Boolean(error));
    return error ? null : codes;
  }

  async function saveResult(approve = false) {
    if (!state.selectedResultId) return false;
    const codes = validateHsnInput();
    if (!codes) return false;
    const button = approve ? $("#approve-result") : $("#save-result");
    setButtonBusy(button, true, approve ? "Approving…" : "Saving…");
    showInlineError($("#editor-error"), "");
    try {
      const body = {
        hsn_codes: codes,
        status: $("#editor-status").value,
        reviewer_note: $("#editor-note").value.trim(),
      };
      const action = approve
        ? "accept"
        : body.status === "invoice_missing"
          ? "missing"
          : body.status === "hsn_missing"
            ? "no_hsn"
            : "edit";
      const updated = await api(`/api/results/${encodeURIComponent(state.selectedResultId)}/review`, {
        method: "POST",
        body: { action, value: codes.join(", ") || null, note: body.reviewer_note || null },
      });
      showToast(approve ? "Result approved" : "Correction saved", approve ? "Moving to the next item that needs review." : "The Excel output will use your correction.");
      const currentIndex = state.results.findIndex((result) => String(result.id ?? result.result_id) === String(state.selectedResultId));
      await loadResults();
      if (approve) {
        const next = state.results.slice(Math.max(0, currentIndex)).find((result) => result.status === "needs_review") || state.results.find((result) => result.status === "needs_review");
        if (next) openEvidence(next.id ?? next.result_id);
        else closeEvidence();
      } else if (updated) {
        const id = updated.id ?? updated.result_id ?? state.selectedResultId;
        if (state.resultById.has(String(id))) openEvidence(id);
      }
      return true;
    } catch (error) {
      showInlineError($("#editor-error"), error.message);
      return false;
    } finally {
      setButtonBusy(button, false);
    }
  }

  async function approveOne(id) {
    try {
      await api(`/api/results/${encodeURIComponent(id)}/review`, { method: "POST", body: { action: "accept" } });
      showToast("Result approved");
      await loadResults();
    } catch (error) {
      showToast("Could not approve result", error.message, "danger");
    }
  }

  async function approveVisible() {
    const checked = $$(".row-check:checked").map((input) => input.value);
    const ids = checked.length ? checked : state.results.filter((result) => result.status === "matched").map((result) => result.id ?? result.result_id);
    if (!ids.length) {
      showToast("Nothing selected", "Select rows, or filter to matched results first.", "warning");
      return;
    }
    const confirmed = await confirmAction("Approve these results?", `${ids.length} result${ids.length === 1 ? "" : "s"} will be marked as human-approved.`, "Approve results");
    if (!confirmed) return;
    try {
      await Promise.all(ids.map((id) => api(`/api/results/${encodeURIComponent(id)}/review`, { method: "POST", body: { action: "accept" } })));
      showToast("Results approved", `${ids.length} rows are ready for export.`);
      await loadResults();
    } catch (error) {
      showToast("Could not approve results", error.message, "danger");
    }
  }

  function downloadBatch(kind, id = state.activeBatchId) {
    if (!id) {
      showToast("No batch selected", "Open a completed batch first.", "warning");
      return;
    }
    const path = kind === "audit" ? "audit.csv" : "output.xlsx";
    window.location.assign(`/api/batches/${encodeURIComponent(id)}/download/${path}`);
  }

  async function loadInsights() {
    const select = $("#insights-batch-select");
    const id = select.value || state.activeBatchId;
    if (!id) {
      renderInsights({});
      return;
    }
    try {
      const payload = await api(`/api/batches/${encodeURIComponent(id)}/insights`);
      renderInsights(payload);
    } catch (error) {
      renderInsights({});
      showToast("Insights could not load", error.message, "warning");
    }
  }

  function renderInsights(payload) {
    const selectedId = $("#insights-batch-select").value || state.activeBatchId;
    const selectedBatch = state.batches.find((batch) => String(batch.id ?? batch.batch_id) === String(selectedId)) || {};
    const summary = payload.summary || {
      total: selectedBatch.total_rows,
      rows: selectedBatch.total_rows,
      resolved: selectedBatch.matched_count,
      matched: selectedBatch.matched_count,
      needs_review: selectedBatch.review_count,
      missing: number(selectedBatch.missing_count) + number(selectedBatch.no_hsn_count),
      review_rate: selectedBatch.total_rows ? number(selectedBatch.review_count) / number(selectedBatch.total_rows) : 0,
      unique_codes: payload.top_codes?.length,
    };
    const cards = [
      ["check", "Resolved rows", summary.resolved ?? summary.matched, "green"],
      ["review", "Review rate", summary.review_rate ? formatPercent(summary.review_rate) : "0%", "amber", true],
      ["scan", "Unique HSN/SAC", summary.unique_codes, "teal"],
      ["file", "Suppliers found", summary.suppliers, "blue"],
    ];
    $("#insight-kpis").innerHTML = cards.map(([iconName, label, value, color, formatted]) => `<article class="kpi-card kpi-card--${color}"><span>${icon(iconName)}</span><small>${escapeHtml(label)}</small><strong>${formatted ? escapeHtml(value) : formatNumber(value)}</strong></article>`).join("");

    const total = number(summary.total || summary.rows);
    const matched = number(summary.resolved ?? summary.matched);
    const resolvedRate = total ? (matched / total) * 100 : number(summary.resolved_rate);
    $("#coverage-donut").style.setProperty("--value", resolvedRate.toFixed(1));
    $("#coverage-donut b").textContent = formatPercent(resolvedRate);
    const coverage = payload.coverage || [
      { label: "Resolved", value: matched, color: "var(--green)" },
      { label: "Needs review", value: summary.needs_review, color: "var(--amber)" },
      { label: "Missing", value: summary.missing, color: "var(--red)" },
    ];
    $("#coverage-legend").innerHTML = coverage.map((item) => `<li><i style="background:${escapeHtml(item.color || "var(--teal)")}"></i><span>${escapeHtml(item.label)}</span><strong>${formatNumber(item.value)}</strong></li>`).join("");

    const codes = payload.top_codes || payload.hsn_distribution || [];
    const maxCode = Math.max(1, ...codes.map((item) => number(item.count ?? item.value ?? item.invoice_count)));
    $("#hsn-bars").innerHTML = codes.length ? codes.slice(0, 7).map((item) => {
      const value = number(item.count ?? item.value ?? item.invoice_count);
      const code = item.code || item.label || item.code_set;
      return `<div class="bar-row"><b title="${escapeHtml(code)}">${escapeHtml(code)}</b><span><i style="width:${(value / maxCode) * 100}%"></i></span><em>${formatNumber(value)}</em></div>`;
    }).join("") : `<div class="empty-state empty-state--small"><p>No extracted codes are available for this batch yet.</p></div>`;

    const suppliers = payload.supplier_watchlist || payload.suppliers_needing_attention || [];
    $("#supplier-watch-list").innerHTML = suppliers.length ? suppliers.slice(0, 5).map((item) => `<div class="supplier-item"><span class="supplier-initial">${escapeHtml(initials(item.name))}</span><span><b>${escapeHtml(item.name || "Unknown supplier")}</b><small>${escapeHtml(item.issue || "Document quality issue")}</small></span><em>${formatNumber(item.count)} invoice${number(item.count) === 1 ? "" : "s"}</em></div>`).join("") : `<div class="empty-state empty-state--small"><span class="empty-icon">${icon("check")}</span><h3>No supplier watch items</h3><p>No recurring document-quality issue was detected.</p></div>`;

    const suggestions = payload.suggestions || (payload.cards?.length
      ? payload.cards.filter((card) => card.detail).map((card) => ({ title: card.title, text: card.detail, icon: card.severity === "danger" ? "alert" : card.severity === "warning" ? "review" : "spark" }))
      : [
          { title: "Verify low-confidence handwriting", text: "Review uncertain codes before sharing the workbook.", icon: "review" },
          { title: "Keep invoice numbers visible", text: "Full-page scans with sharp invoice headers improve matching.", icon: "scan" },
        ]);
    $("#suggestion-list").innerHTML = suggestions.map((item) => `<div class="suggestion-item"><span>${icon(item.icon || "spark")}</span><div><b>${escapeHtml(item.title)}</b><p>${escapeHtml(item.text || item.description || "")}</p></div></div>`).join("");
  }

  async function loadLoginActivity() {
    if (state.session?.user?.role !== "admin") return;
    const days = $("#login-period").value;
    const query = $("#login-search").value.trim();
    const params = new URLSearchParams();
    if (days !== "all") params.set("days", days);
    if (query) params.set("q", query);
    try {
      const payload = await api(`/api/admin/logins?${params}`);
      renderLoginActivity(payload);
    } catch (error) {
      showToast("Login activity could not load", error.message, "danger");
      renderLoginActivity({ items: [] });
    }
  }

  function renderLoginActivity(payload) {
    const items = payload.items || payload.logins || (Array.isArray(payload) ? payload : []);
    $("#login-table-body").innerHTML = items.map((entry) => `<tr>
      <td><div class="user-cell"><span class="avatar">${escapeHtml(initials(entry.name, entry.email))}</span><span><strong>${escapeHtml(entry.name || "Administrator")}</strong><small>${entry.last_seen ? `Last seen ${relativeDate(entry.last_seen)}` : "Local user"}</small></span></div></td>
      <td>${escapeHtml(entry.email || "—")}</td><td>${escapeHtml(entry.role || "User")}</td><td>${formatDate(entry.created_at || entry.login_at || entry.date)}</td><td>${statusMarkup(entry.success === false ? "error" : "approved").replace("Approved", entry.success === false ? "Failed" : "Successful")}</td>
    </tr>`).join("");
    $("#login-log-empty").hidden = items.length > 0;
    $("#login-table-body").closest(".table-scroll").hidden = items.length === 0;
    const summary = payload.summary || {};
    const cards = [
      ["Sign-ins", summary.sign_ins ?? items.length, "selected period"],
      ["Unique users", summary.unique_users ?? new Set(items.map((item) => item.email)).size, "local accounts"],
      ["Last sign-in", summary.last_login ? relativeDate(summary.last_login) : items[0] ? relativeDate(items[0].created_at || items[0].login_at) : "—", ""],
      ["Failed attempts", summary.failed_attempts ?? items.filter((item) => item.success === false).length, "security check"],
    ];
    $("#admin-kpis").innerHTML = cards.map(([label, value, note]) => `<div class="mini-kpi"><small>${escapeHtml(label)}</small><strong>${typeof value === "number" ? formatNumber(value) : escapeHtml(value)}${note ? `<em>${escapeHtml(note)}</em>` : ""}</strong></div>`).join("");
  }

  function bindEvents() {
    $("#login-form").addEventListener("submit", handleLogin);
    $$("input[name='role']").forEach((input) => input.addEventListener("change", updateRoleFields));
    $("#toggle-password").addEventListener("click", () => {
      const input = $("#login-password");
      input.type = input.type === "password" ? "text" : "password";
      $("#toggle-password").setAttribute("aria-label", input.type === "password" ? "Show password" : "Hide password");
    });
    $("#logout-button").addEventListener("click", logout);
    $("#open-sidebar").addEventListener("click", openSidebar);
    $("#close-sidebar").addEventListener("click", closeSidebar);
    $("#sidebar-scrim").addEventListener("click", closeSidebar);
    $("#confirm-dialog").addEventListener("close", handleDialogClose);

    document.addEventListener("click", (event) => {
      const go = event.target.closest("[data-go]");
      if (go) goToView(go.dataset.go);
      const nav = event.target.closest("[data-view]");
      if (nav) goToView(nav.dataset.view);
      const open = event.target.closest("[data-open-batch]");
      if (open) openBatch(open.dataset.openBatch, open.dataset.target);
      const download = event.target.closest("[data-download-batch]");
      if (download) downloadBatch("excel", download.dataset.downloadBatch);
      const review = event.target.closest("[data-review-result]");
      if (review) openEvidence(review.dataset.reviewResult);
      const approve = event.target.closest("[data-approve-result]");
      if (approve) approveOne(approve.dataset.approveResult);
    });

    configureDropZone($("#workbook-drop"), $("#workbook-input"), acceptWorkbook);
    configureDropZone($("#invoice-drop"), null, acceptInvoices);
    $("#zip-input").addEventListener("change", () => acceptInvoices(Array.from($("#zip-input").files || [])));
    $("#pdf-input").addEventListener("change", () => acceptInvoices(Array.from($("#pdf-input").files || [])));
    $("#choose-zip").addEventListener("click", (event) => { event.stopPropagation(); $("#zip-input").click(); });
    $("#choose-pdfs").addEventListener("click", (event) => { event.stopPropagation(); $("#pdf-input").click(); });
    $("#invoice-drop").addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); $("#zip-input").click(); } });
    $(".selected-file button", $("#workbook-drop")).addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); state.workbookFile = null; $("#workbook-input").value = ""; renderSelectedFiles(); });
    $(".selected-file button", $("#invoice-drop")).addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); state.zipFile = null; state.pdfFiles = []; $("#zip-input").value = ""; $("#pdf-input").value = ""; renderSelectedFiles(); });
    $("#upload-form").addEventListener("submit", prepareBatch);
    $("#start-button").addEventListener("click", startProcessing);
    $("#mapping-sheet").addEventListener("change", refreshMappingPreview);
    $("#mapping-header-row").addEventListener("change", refreshMappingPreview);
    [$("#mapping-invoice-column"), $("#mapping-hsn-column")].forEach((select) => select.addEventListener("change", () => {
      const mapping = state.uploadBatch?.mapping || state.uploadBatch || {};
      renderMappingPreview(mapping.preview || state.uploadBatch?.workbook?.preview || [], normalizeColumns(mapping));
    }));

    $("#pause-button").addEventListener("click", () => changeBatchState("pause"));
    $("#resume-button").addEventListener("click", () => changeBatchState("resume"));
    $("#cancel-button").addEventListener("click", () => changeBatchState("cancel"));

    $("#review-search").addEventListener("input", () => {
      window.clearTimeout(state.searchTimer);
      state.searchTimer = window.setTimeout(() => { state.resultPage = 1; loadResults(); }, 350);
    });
    [$("#review-status-filter"), $("#review-confidence-filter")].forEach((select) => select.addEventListener("change", () => { state.resultPage = 1; loadResults(); }));
    $("#review-prev").addEventListener("click", () => { if (state.resultPage > 1) { state.resultPage -= 1; loadResults(); } });
    $("#review-next").addEventListener("click", () => { if (state.resultPage < state.resultPages) { state.resultPage += 1; loadResults(); } });
    $("#approve-visible").addEventListener("click", approveVisible);
    $("#download-excel").addEventListener("click", () => downloadBatch("excel"));
    $("#download-audit").addEventListener("click", () => downloadBatch("audit"));
    $("#close-evidence").addEventListener("click", closeEvidence);
    $("#drawer-scrim").addEventListener("click", closeEvidence);
    $("#result-editor").addEventListener("submit", (event) => { event.preventDefault(); saveResult(false); });
    $("#approve-result").addEventListener("click", () => saveResult(true));
    $("#editor-hsn").addEventListener("input", () => { $("#editor-hsn-error").textContent = ""; $("#editor-hsn").classList.remove("is-invalid"); });

    $("#insights-batch-select").addEventListener("change", loadInsights);
    [$("#batch-search"), $("#batch-status-filter")].forEach((control) => control.addEventListener(control.tagName === "INPUT" ? "input" : "change", renderBatches));
    $("#login-period").addEventListener("change", loadLoginActivity);
    $("#login-search").addEventListener("input", () => { window.clearTimeout(state.searchTimer); state.searchTimer = window.setTimeout(loadLoginActivity, 350); });
    $("#export-logins").addEventListener("click", () => window.location.assign("/api/admin/logins/export.csv"));

    document.addEventListener("keydown", (event) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k" && !$("#app-shell").hidden) {
        event.preventDefault();
        if (state.currentView !== "review") goToView("review");
        window.setTimeout(() => $("#review-search").focus(), 30);
      }
      if (event.key === "Escape" && $("#evidence-drawer").classList.contains("is-open")) closeEvidence();
    });

    window.addEventListener("dragover", (event) => event.preventDefault());
    window.addEventListener("drop", (event) => {
      if (!event.target.closest(".drop-zone")) event.preventDefault();
    });
  }

  initialize();
})();
