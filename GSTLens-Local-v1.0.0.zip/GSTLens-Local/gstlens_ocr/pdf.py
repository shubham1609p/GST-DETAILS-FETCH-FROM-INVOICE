"""PDF text extraction and page rendering backed by local pypdfium2."""

from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .errors import OptionalDependencyError, PDFReadError, UnsafeInputError
from .files import is_pdf_file
from .types import OCRToken, PageOCRResult, Polygon, RenderedPage


@dataclass(frozen=True, slots=True)
class PDFSafetyLimits:
    max_file_bytes: int = 250 * 1024 * 1024
    max_pages: int = 100
    max_pixels_per_page: int = 60_000_000
    max_text_chars_per_page: int = 250_000


def _load_pdfium() -> Any:
    try:
        import pypdfium2 as pdfium
    except ImportError as exc:
        raise OptionalDependencyError(
            "pypdfium2",
            "Run the GSTLens installer again or install pypdfium2 locally.",
        ) from exc
    return pdfium


def _load_numpy() -> Any:
    try:
        import numpy as np
    except ImportError as exc:
        raise OptionalDependencyError(
            "numpy", "Run the GSTLens installer again or install numpy locally."
        ) from exc
    return np


def _clean_pdf_text(text: str) -> str:
    return text.replace("\x00", "").replace("\r\n", "\n").replace("\r", "\n")


def has_meaningful_native_text(text: str, minimum_alphanumeric: int = 40) -> bool:
    """Reject PDFs whose text layer only contains a few scanner artefacts."""

    return sum(character.isalnum() for character in text) >= minimum_alphanumeric


def _box_to_polygon(
    box: tuple[float, float, float, float],
    *,
    scale: float,
    page_height_points: float,
) -> Polygon | None:
    left, bottom, right, top = box
    values = (left, bottom, right, top)
    if not all(math.isfinite(value) for value in values):
        return None
    x1, x2 = sorted((left * scale, right * scale))
    # PDF coordinates start at the bottom-left; OCR/image coordinates start top-left.
    y1, y2 = sorted(
        ((page_height_points - top) * scale, (page_height_points - bottom) * scale)
    )
    return ((x1, y1), (x2, y1), (x2, y2), (x1, y2))


class PDFDocumentReader:
    """Bounded, context-managed access to one invoice PDF."""

    def __init__(
        self,
        path: str | os.PathLike[str],
        *,
        limits: PDFSafetyLimits | None = None,
        password: str | None = None,
    ) -> None:
        self.path = Path(path)
        self.limits = limits or PDFSafetyLimits()
        self.password = password
        self._document: Any | None = None

    def __enter__(self) -> "PDFDocumentReader":
        self.open()
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def open(self) -> None:
        if self._document is not None:
            return
        if not self.path.is_file():
            raise PDFReadError(f"PDF does not exist: {self.path}")
        size = self.path.stat().st_size
        if size > self.limits.max_file_bytes:
            raise UnsafeInputError(
                f"PDF is too large ({size:,} bytes): {self.path.name}"
            )
        if not is_pdf_file(self.path):
            raise PDFReadError(f"File is not a valid PDF upload: {self.path.name}")

        pdfium = _load_pdfium()
        try:
            self._document = pdfium.PdfDocument(
                self.path, password=self.password, autoclose=False
            )
            page_count = len(self._document)
        except Exception as exc:
            self._document = None
            raise PDFReadError(
                f"Could not open PDF '{self.path.name}'. It may be damaged or "
                "password protected."
            ) from exc
        if page_count < 1:
            self.close()
            raise PDFReadError(f"PDF has no pages: {self.path.name}")
        if page_count > self.limits.max_pages:
            self.close()
            raise UnsafeInputError(
                f"PDF has {page_count:,} pages; the per-invoice limit is "
                f"{self.limits.max_pages:,}."
            )

    def close(self) -> None:
        if self._document is not None:
            try:
                self._document.close()
            finally:
                self._document = None

    @property
    def page_count(self) -> int:
        self.open()
        assert self._document is not None
        return len(self._document)

    def _check_page_index(self, page_index: int) -> None:
        if not 0 <= page_index < self.page_count:
            raise IndexError(
                f"Page {page_index} is outside PDF page range 0..{self.page_count - 1}."
            )

    def page_size(self, page_index: int) -> tuple[float, float]:
        self._check_page_index(page_index)
        assert self._document is not None
        page = self._document[page_index]
        try:
            width, height = page.get_size()
            return float(width), float(height)
        except Exception as exc:
            raise PDFReadError(
                f"Could not read page {page_index + 1} of '{self.path.name}'."
            ) from exc
        finally:
            page.close()

    def native_text(self, page_index: int) -> str:
        """Return the embedded PDF text layer, if one exists."""

        self._check_page_index(page_index)
        assert self._document is not None
        page = self._document[page_index]
        text_page = None
        try:
            text_page = page.get_textpage()
            count = int(text_page.count_chars())
            if count > self.limits.max_text_chars_per_page:
                raise UnsafeInputError(
                    f"PDF page {page_index + 1} has an unusually large text layer."
                )
            return _clean_pdf_text(text_page.get_text_range())
        except UnsafeInputError:
            raise
        except Exception as exc:
            raise PDFReadError(
                f"Could not extract text from page {page_index + 1} of "
                f"'{self.path.name}'."
            ) from exc
        finally:
            if text_page is not None:
                text_page.close()
            page.close()

    def native_page_result(self, page_index: int, *, dpi: int = 200) -> PageOCRResult:
        """Convert a PDF text layer into the same token format as local OCR."""

        if dpi < 72 or dpi > 600:
            raise ValueError("DPI must be between 72 and 600.")
        self._check_page_index(page_index)
        assert self._document is not None
        page = self._document[page_index]
        text_page = None
        scale = dpi / 72.0
        try:
            page_width, page_height = (float(value) for value in page.get_size())
            width = max(1, math.ceil(page_width * scale))
            height = max(1, math.ceil(page_height * scale))
            if width * height > self.limits.max_pixels_per_page:
                raise UnsafeInputError(
                    f"Page {page_index + 1} would exceed the pixel safety limit at "
                    f"{dpi} DPI."
                )

            text_page = page.get_textpage()
            count = int(text_page.count_chars())
            if count > self.limits.max_text_chars_per_page:
                raise UnsafeInputError(
                    f"PDF page {page_index + 1} has an unusually large text layer."
                )
            full_text = _clean_pdf_text(text_page.get_text_range())

            tokens: list[OCRToken] = []
            token_chars: list[str] = []
            token_boxes: list[tuple[float, float, float, float]] = []

            def flush_token() -> None:
                if not token_chars:
                    return
                polygon: Polygon | None = None
                if token_boxes:
                    left = min(box[0] for box in token_boxes)
                    bottom = min(box[1] for box in token_boxes)
                    right = max(box[2] for box in token_boxes)
                    top = max(box[3] for box in token_boxes)
                    polygon = _box_to_polygon(
                        (left, bottom, right, top),
                        scale=scale,
                        page_height_points=page_height,
                    )
                tokens.append(
                    OCRToken(
                        text="".join(token_chars),
                        confidence=1.0,
                        page_index=page_index,
                        polygon=polygon,
                        source="native_pdf",
                    )
                )
                token_chars.clear()
                token_boxes.clear()

            # PDFium's character list preserves reading order and provides char boxes.
            for char_index in range(count):
                character = _clean_pdf_text(text_page.get_text_range(char_index, 1))
                if not character or character.isspace():
                    flush_token()
                    continue
                token_chars.append(character)
                try:
                    box = tuple(float(value) for value in text_page.get_charbox(char_index))
                    if len(box) == 4 and all(math.isfinite(value) for value in box):
                        token_boxes.append(box)  # type: ignore[arg-type]
                except Exception:
                    # Text remains useful even when a particular glyph has no box.
                    pass
            flush_token()

            return PageOCRResult(
                page_index=page_index,
                width=width,
                height=height,
                tokens=tuple(tokens),
                text=full_text,
                mean_confidence=1.0 if tokens else 0.0,
                source="native_pdf",
                native_text=full_text,
            )
        except (UnsafeInputError, PDFReadError):
            raise
        except Exception as exc:
            raise PDFReadError(
                f"Could not read the text layer on page {page_index + 1} of "
                f"'{self.path.name}'."
            ) from exc
        finally:
            if text_page is not None:
                text_page.close()
            page.close()

    def render_page(self, page_index: int, *, dpi: int = 220) -> RenderedPage:
        """Render one bounded PDF page to an owned uint8 RGB NumPy array."""

        if dpi < 72 or dpi > 600:
            raise ValueError("DPI must be between 72 and 600.")
        self._check_page_index(page_index)
        assert self._document is not None
        np = _load_numpy()
        page = self._document[page_index]
        bitmap = None
        scale = dpi / 72.0
        try:
            width_points, height_points = (float(value) for value in page.get_size())
            estimated_width = max(1, math.ceil(width_points * scale))
            estimated_height = max(1, math.ceil(height_points * scale))
            if estimated_width * estimated_height > self.limits.max_pixels_per_page:
                raise UnsafeInputError(
                    f"Page {page_index + 1} would exceed the pixel safety limit at "
                    f"{dpi} DPI."
                )
            bitmap = page.render(
                scale=scale,
                rev_byteorder=True,
                fill_color=(255, 255, 255, 255),
                optimize_mode="print",
            )
            image = np.array(bitmap.to_numpy(), dtype=np.uint8, copy=True)
            if image.ndim == 2:
                image = np.repeat(image[:, :, None], 3, axis=2)
            elif image.ndim == 3 and image.shape[2] >= 3:
                image = image[:, :, :3]
            else:
                raise PDFReadError(
                    f"Unexpected rendered bitmap shape on page {page_index + 1}: "
                    f"{image.shape!r}"
                )
            image = np.ascontiguousarray(image)
            return RenderedPage(page_index=page_index, dpi=dpi, image=image)
        except (UnsafeInputError, PDFReadError):
            raise
        except Exception as exc:
            raise PDFReadError(
                f"Could not render page {page_index + 1} of '{self.path.name}'."
            ) from exc
        finally:
            if bitmap is not None:
                bitmap.close()
            page.close()


def extract_native_text(
    path: str | os.PathLike[str], *, limits: PDFSafetyLimits | None = None
) -> tuple[str, ...]:
    """Convenience helper that returns the text layer for every page."""

    with PDFDocumentReader(path, limits=limits) as document:
        return tuple(document.native_text(index) for index in range(document.page_count))


def invoice_numberish_text(text: str) -> str:
    """Collapse PDF line noise while retaining punctuation used in invoice numbers."""

    return re.sub(r"[ \t\f\v]+", " ", _clean_pdf_text(text)).strip()
