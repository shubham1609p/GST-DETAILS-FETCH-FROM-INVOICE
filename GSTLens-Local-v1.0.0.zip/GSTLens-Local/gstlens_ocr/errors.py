"""Domain errors raised by the local GSTLens OCR runtime."""

from __future__ import annotations


class OCRRuntimeError(RuntimeError):
    """Base class for errors the application can safely show to a user."""


class OptionalDependencyError(OCRRuntimeError):
    """A locally installed runtime dependency is unavailable."""

    def __init__(self, dependency: str, install_hint: str) -> None:
        self.dependency = dependency
        self.install_hint = install_hint
        super().__init__(
            f"The optional dependency '{dependency}' is not installed. {install_hint}"
        )


class UnsafeInputError(OCRRuntimeError):
    """An upload violates a size, path, archive, or format safety rule."""


class NoInvoicesFoundError(OCRRuntimeError):
    """An input did not contain any usable PDF invoices."""


class PDFReadError(OCRRuntimeError):
    """A PDF could not be opened or safely processed."""


class OCRModelError(OCRRuntimeError):
    """A required local OCR model is missing or invalid."""


class OCRPredictionError(OCRRuntimeError):
    """The local OCR engine failed while recognizing a page."""


class ProcessingCancelled(OCRRuntimeError):
    """The current local OCR batch was cancelled by its caller."""
