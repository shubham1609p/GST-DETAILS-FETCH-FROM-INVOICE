"""Safe invoice upload enumeration and ZIP extraction."""

from __future__ import annotations

import hashlib
import os
import re
import stat
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable, Iterator

from .errors import NoInvoicesFoundError, UnsafeInputError


_WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{number}" for number in range(1, 10)),
    *(f"LPT{number}" for number in range(1, 10)),
}
_WINDOWS_ILLEGAL = re.compile(r'[<>:"|?*\x00]')


@dataclass(frozen=True, slots=True)
class UploadSafetyLimits:
    """Conservative defaults suitable for batches of about 1,000 invoices."""

    max_archive_entries: int = 5_000
    max_archive_bytes: int = 5 * 1024 * 1024 * 1024
    max_pdf_count: int = 2_000
    max_member_bytes: int = 250 * 1024 * 1024
    max_total_uncompressed_bytes: int = 5 * 1024 * 1024 * 1024
    max_compression_ratio: float = 250.0
    max_direct_pdf_bytes: int = 250 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class InvoiceDocument:
    """A validated invoice PDF ready for processing."""

    path: Path
    display_name: str
    sha256: str
    archive_member: str | None = None


def sha256_file(path: str | os.PathLike[str], chunk_size: int = 1024 * 1024) -> str:
    """Hash a file without loading it into memory."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def is_pdf_file(path: str | os.PathLike[str]) -> bool:
    """Check both the extension and a PDF header near the start of the file."""

    candidate = Path(path)
    if candidate.suffix.casefold() != ".pdf" or not candidate.is_file():
        return False
    return _has_pdf_header(candidate)


def _has_pdf_header(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            return b"%PDF-" in handle.read(1024)
    except OSError:
        return False


def _safe_member_path(name: str) -> PurePosixPath:
    normalized = name.replace("\\", "/")
    if not normalized or normalized.startswith("/"):
        raise UnsafeInputError(f"Unsafe ZIP member path: {name!r}")
    if re.match(r"^[A-Za-z]:", normalized):
        raise UnsafeInputError(f"Windows drive path in ZIP member: {name!r}")

    member = PurePosixPath(normalized)
    if not member.parts or any(part in {"", ".", ".."} for part in member.parts):
        raise UnsafeInputError(f"ZIP path traversal is not allowed: {name!r}")

    for part in member.parts:
        if _WINDOWS_ILLEGAL.search(part) or part.rstrip(" .") != part:
            raise UnsafeInputError(f"ZIP member is not safe on Windows: {name!r}")
        stem = part.split(".", 1)[0].upper()
        if stem in _WINDOWS_RESERVED_NAMES:
            raise UnsafeInputError(f"Reserved Windows filename in ZIP: {name!r}")
    return member


def _is_symlink(info: zipfile.ZipInfo) -> bool:
    unix_mode = info.external_attr >> 16
    return stat.S_IFMT(unix_mode) == stat.S_IFLNK


def _validate_archive(
    archive: zipfile.ZipFile, limits: UploadSafetyLimits
) -> list[tuple[zipfile.ZipInfo, PurePosixPath]]:
    infos = archive.infolist()
    if len(infos) > limits.max_archive_entries:
        raise UnsafeInputError(
            f"ZIP has {len(infos):,} entries; the limit is "
            f"{limits.max_archive_entries:,}."
        )

    total_bytes = 0
    pdfs: list[tuple[zipfile.ZipInfo, PurePosixPath]] = []
    canonical_names: set[str] = set()
    for info in infos:
        member = _safe_member_path(info.filename)
        canonical = "/".join(part.casefold() for part in member.parts)
        if canonical in canonical_names:
            raise UnsafeInputError(
                f"ZIP contains duplicate or case-colliding paths: {info.filename!r}"
            )
        canonical_names.add(canonical)

        if info.flag_bits & 0x1:
            raise UnsafeInputError(
                f"Encrypted ZIP members are not supported: {info.filename!r}"
            )
        if _is_symlink(info):
            raise UnsafeInputError(f"ZIP symbolic links are not allowed: {info.filename!r}")
        if info.file_size < 0 or info.compress_size < 0:
            raise UnsafeInputError(f"Invalid ZIP member size: {info.filename!r}")
        if info.file_size > limits.max_member_bytes:
            raise UnsafeInputError(
                f"ZIP member is too large ({info.file_size:,} bytes): "
                f"{info.filename!r}"
            )

        total_bytes += info.file_size
        if total_bytes > limits.max_total_uncompressed_bytes:
            raise UnsafeInputError("ZIP expands beyond the configured batch size limit.")
        if info.file_size and not info.is_dir():
            if info.compress_size == 0:
                raise UnsafeInputError(
                    f"Suspicious zero-size compressed member: {info.filename!r}"
                )
            ratio = info.file_size / info.compress_size
            if ratio > limits.max_compression_ratio:
                raise UnsafeInputError(
                    f"Suspicious ZIP compression ratio ({ratio:.1f}:1): "
                    f"{info.filename!r}"
                )

        if not info.is_dir() and member.suffix.casefold() == ".pdf":
            pdfs.append((info, member))

    if len(pdfs) > limits.max_pdf_count:
        raise UnsafeInputError(
            f"ZIP has {len(pdfs):,} PDFs; the limit is {limits.max_pdf_count:,}."
        )
    if not pdfs:
        raise NoInvoicesFoundError("The ZIP does not contain any PDF invoices.")
    return pdfs


def safe_extract_invoice_pdfs(
    zip_path: str | os.PathLike[str],
    destination: str | os.PathLike[str],
    limits: UploadSafetyLimits | None = None,
) -> list[InvoiceDocument]:
    """Extract only validated PDFs from a ZIP without trusting member paths."""

    limits = limits or UploadSafetyLimits()
    archive_path = Path(zip_path)
    target_root = Path(destination)
    if not archive_path.is_file():
        raise UnsafeInputError(f"ZIP upload does not exist: {archive_path}")
    if archive_path.suffix.casefold() != ".zip":
        raise UnsafeInputError(f"Expected a .zip upload, got: {archive_path.name}")
    if archive_path.stat().st_size > limits.max_archive_bytes:
        raise UnsafeInputError(
            f"ZIP upload is too large ({archive_path.stat().st_size:,} bytes)."
        )

    target_root.mkdir(parents=True, exist_ok=True)
    root_resolved = target_root.resolve()
    documents: list[InvoiceDocument] = []
    try:
        archive = zipfile.ZipFile(archive_path, "r")
    except (OSError, zipfile.BadZipFile, zipfile.LargeZipFile) as exc:
        raise UnsafeInputError(f"The uploaded ZIP cannot be opened: {exc}") from exc

    with archive:
        pdf_members = _validate_archive(archive, limits)
        for info, member in pdf_members:
            target = target_root.joinpath(*member.parts)
            target_resolved = target.resolve()
            try:
                target_resolved.relative_to(root_resolved)
            except ValueError as exc:  # Defensive second check after lexical validation.
                raise UnsafeInputError(
                    f"ZIP member escapes the extraction folder: {info.filename!r}"
                ) from exc
            if target.exists():
                raise UnsafeInputError(
                    f"Refusing to overwrite an extracted upload: {member.as_posix()}"
                )

            target.parent.mkdir(parents=True, exist_ok=True)
            partial = target.with_name(f".{target.name}.part")
            written = 0
            try:
                with archive.open(info, "r") as source, partial.open("xb") as output:
                    while chunk := source.read(1024 * 1024):
                        written += len(chunk)
                        if written > limits.max_member_bytes or written > info.file_size:
                            raise UnsafeInputError(
                                f"ZIP member expanded beyond its declared safe size: "
                                f"{info.filename!r}"
                            )
                        output.write(chunk)
                if written != info.file_size:
                    raise UnsafeInputError(
                        f"ZIP member size mismatch: {info.filename!r}"
                    )
                if not _has_pdf_header(partial):
                    raise UnsafeInputError(
                        f"File has a .pdf name but is not a PDF: {info.filename!r}"
                    )
                partial.replace(target)
            except UnsafeInputError:
                partial.unlink(missing_ok=True)
                raise
            except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
                partial.unlink(missing_ok=True)
                raise UnsafeInputError(
                    f"Could not safely extract ZIP member {info.filename!r}: {exc}"
                ) from exc

            documents.append(
                InvoiceDocument(
                    path=target,
                    display_name=member.name,
                    archive_member=member.as_posix(),
                    sha256=sha256_file(target),
                )
            )
    return documents


def _validated_direct_pdf(path: Path, limits: UploadSafetyLimits) -> InvoiceDocument:
    if not path.is_file():
        raise UnsafeInputError(f"Invoice upload does not exist: {path}")
    size = path.stat().st_size
    if size > limits.max_direct_pdf_bytes:
        raise UnsafeInputError(
            f"PDF is too large ({size:,} bytes): {path.name}"
        )
    if not is_pdf_file(path):
        raise UnsafeInputError(f"Upload is not a valid PDF: {path.name}")
    return InvoiceDocument(
        path=path,
        display_name=path.name,
        sha256=sha256_file(path),
    )


def enumerate_invoice_documents(
    inputs: Iterable[str | os.PathLike[str]],
    extraction_root: str | os.PathLike[str],
    limits: UploadSafetyLimits | None = None,
    *,
    deduplicate_by_hash: bool = False,
) -> list[InvoiceDocument]:
    """Validate direct PDFs and safely expand ZIPs into a caller-owned work folder."""

    limits = limits or UploadSafetyLimits()
    root = Path(extraction_root)
    root.mkdir(parents=True, exist_ok=True)
    documents: list[InvoiceDocument] = []
    archive_number = 0
    for raw_path in inputs:
        path = Path(raw_path)
        suffix = path.suffix.casefold()
        if suffix == ".pdf":
            documents.append(_validated_direct_pdf(path, limits))
        elif suffix == ".zip":
            archive_number += 1
            destination = root / f"archive-{archive_number:04d}"
            if destination.exists():
                raise UnsafeInputError(
                    f"Extraction folder already exists: {destination}. "
                    "Use a new batch work folder."
                )
            documents.extend(safe_extract_invoice_pdfs(path, destination, limits))
        else:
            raise UnsafeInputError(
                f"Only PDF and ZIP invoice uploads are supported: {path.name}"
            )
        if len(documents) > limits.max_pdf_count:
            raise UnsafeInputError(
                f"Batch has more than {limits.max_pdf_count:,} PDF invoices."
            )

    if not documents:
        raise NoInvoicesFoundError("No PDF invoice uploads were provided.")
    if not deduplicate_by_hash:
        return documents

    seen: set[str] = set()
    unique: list[InvoiceDocument] = []
    for document in documents:
        if document.sha256 not in seen:
            unique.append(document)
            seen.add(document.sha256)
    return unique


def enumerate_uploaded_pdfs(
    input_dir: str | os.PathLike[str],
    extraction_root: str | os.PathLike[str] | None = None,
    limits: UploadSafetyLimits | None = None,
    *,
    deduplicate_by_hash: bool = False,
) -> list[InvoiceDocument]:
    """Enumerate top-level PDF/ZIP uploads in a batch input directory.

    Excel and other companion uploads are intentionally ignored. If ZIPs are present
    and no extraction folder is supplied, a unique work folder is created beneath
    ``input_dir`` so an existing batch is never overwritten.
    """

    root = Path(input_dir)
    if not root.is_dir():
        raise UnsafeInputError(f"Upload folder does not exist: {root}")
    inputs = sorted(
        (
            path
            for path in root.iterdir()
            if path.is_file() and path.suffix.casefold() in {".pdf", ".zip"}
        ),
        key=lambda path: path.name.casefold(),
    )
    if not inputs:
        raise NoInvoicesFoundError("The upload folder has no PDF or ZIP invoices.")
    if extraction_root is None:
        extraction_root = Path(
            tempfile.mkdtemp(prefix=".gstlens-extracted-", dir=str(root))
        )
    return enumerate_invoice_documents(
        inputs,
        extraction_root,
        limits,
        deduplicate_by_hash=deduplicate_by_hash,
    )


def iter_pdf_files(folder: str | os.PathLike[str]) -> Iterator[Path]:
    """Yield PDFs beneath a trusted batch folder in deterministic path order."""

    root = Path(folder)
    if not root.is_dir():
        return
    candidates = (path for path in root.rglob("*") if path.is_file())
    for path in sorted(candidates, key=lambda item: item.as_posix().casefold()):
        if is_pdf_file(path):
            yield path
