"""Conservative invoice image cleanup that preserves faint handwriting."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .errors import OptionalDependencyError


@dataclass(frozen=True, slots=True)
class PreprocessConfig:
    enabled: bool = True
    deskew: bool = True
    enhance_contrast: bool = True
    denoise: bool = True
    max_skew_degrees: float = 8.0
    clahe_clip_limit: float = 2.0
    denoise_strength: int = 5
    require_opencv: bool = False


@dataclass(frozen=True, slots=True)
class PreprocessReport:
    opencv_used: bool
    deskew_angle: float = 0.0
    contrast_enhanced: bool = False
    denoised: bool = False


def _load_numpy() -> Any:
    try:
        import numpy as np
    except ImportError as exc:
        raise OptionalDependencyError(
            "numpy", "Run the GSTLens installer again or install numpy locally."
        ) from exc
    return np


def _try_load_cv2() -> Any | None:
    try:
        import cv2
    except ImportError:
        return None
    return cv2


def opencv_available() -> bool:
    return _try_load_cv2() is not None


def normalize_rgb_image(image: Any) -> Any:
    """Return a contiguous uint8 RGB array from PIL/NumPy-like input."""

    np = _load_numpy()
    array = np.asarray(image)
    if array.size == 0:
        raise ValueError("Cannot OCR an empty image.")
    if array.ndim not in {2, 3}:
        raise ValueError(f"Expected a 2D or 3D image array, got shape {array.shape!r}.")

    if array.dtype != np.uint8:
        array = array.astype(np.float32, copy=False)
        finite = np.isfinite(array)
        if not finite.all():
            array = np.where(finite, array, 255.0)
        if array.size and float(array.max()) <= 1.0:
            array = array * 255.0
        array = np.clip(array, 0, 255).astype(np.uint8)

    if array.ndim == 2:
        array = np.repeat(array[:, :, None], 3, axis=2)
    elif array.shape[2] == 1:
        array = np.repeat(array, 3, axis=2)
    elif array.shape[2] >= 4:
        rgb = array[:, :, :3].astype(np.float32)
        alpha = array[:, :, 3:4].astype(np.float32) / 255.0
        array = (rgb * alpha + 255.0 * (1.0 - alpha)).round().astype(np.uint8)
    elif array.shape[2] == 3:
        array = array[:, :, :3]
    else:
        raise ValueError(f"Unsupported image channel count: {array.shape[2]}.")
    return np.ascontiguousarray(array)


def _estimate_skew_degrees(gray: Any, cv2: Any, maximum: float) -> float:
    np = _load_numpy()
    height, width = gray.shape[:2]
    if min(height, width) < 80:
        return 0.0
    edges = cv2.Canny(gray, 60, 180, apertureSize=3)
    lines = cv2.HoughLinesP(
        edges,
        1,
        np.pi / 1800.0,
        threshold=max(40, width // 25),
        minLineLength=max(40, width // 7),
        maxLineGap=max(10, width // 100),
    )
    if lines is None:
        return 0.0

    candidates: list[float] = []
    for x1, y1, x2, y2 in lines[:, 0]:
        angle = float(np.degrees(np.arctan2(float(y2 - y1), float(x2 - x1))))
        # Invoice tables provide strong horizontal lines; ignore vertical structures.
        if abs(angle) <= maximum:
            candidates.append(angle)
    if len(candidates) < 2:
        return 0.0
    return float(np.median(np.asarray(candidates, dtype=np.float32)))


def preprocess_image_with_report(
    image: Any, config: PreprocessConfig | None = None
) -> tuple[Any, PreprocessReport]:
    """Enhance a page locally; fall back to normalized RGB if OpenCV is absent."""

    config = config or PreprocessConfig()
    rgb = normalize_rgb_image(image)
    if not config.enabled:
        return rgb, PreprocessReport(opencv_used=False)

    cv2 = _try_load_cv2()
    if cv2 is None:
        if config.require_opencv:
            raise OptionalDependencyError(
                "opencv-python-headless",
                "Run the GSTLens installer again to enable invoice preprocessing.",
            )
        return rgb, PreprocessReport(opencv_used=False)

    np = _load_numpy()
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    angle = 0.0
    if config.deskew:
        angle = _estimate_skew_degrees(gray, cv2, config.max_skew_degrees)
        if abs(angle) >= 0.08:
            height, width = gray.shape
            matrix = cv2.getRotationMatrix2D((width / 2.0, height / 2.0), angle, 1.0)
            gray = cv2.warpAffine(
                gray,
                matrix,
                (width, height),
                flags=cv2.INTER_CUBIC,
                borderMode=cv2.BORDER_CONSTANT,
                borderValue=255,
            )
        else:
            angle = 0.0

    enhanced = False
    if config.enhance_contrast:
        clahe = cv2.createCLAHE(
            clipLimit=max(0.1, config.clahe_clip_limit), tileGridSize=(8, 8)
        )
        gray = clahe.apply(gray)
        enhanced = True

    denoised = False
    if config.denoise and config.denoise_strength > 0:
        gray = cv2.fastNlMeansDenoising(
            gray,
            None,
            h=float(config.denoise_strength),
            templateWindowSize=7,
            searchWindowSize=21,
        )
        denoised = True

    output = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    output = np.ascontiguousarray(output, dtype=np.uint8)
    return output, PreprocessReport(
        opencv_used=True,
        deskew_angle=angle,
        contrast_enhanced=enhanced,
        denoised=denoised,
    )


def preprocess_image(image: Any, config: PreprocessConfig | None = None) -> Any:
    """Convenience wrapper returning only the processed RGB page image."""

    processed, _report = preprocess_image_with_report(image, config)
    return processed
