"""Lazy, offline-only adapter for PaddleOCR 3.x / PP-OCRv6."""

from __future__ import annotations

import json
import math
import os
import threading
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .errors import (
    OCRModelError,
    OCRPredictionError,
    OptionalDependencyError,
)
from .preprocess import normalize_rgb_image
from .types import OCRToken, PageOCRResult, Polygon


_DEFAULT_CPU_THREADS = max(1, min(8, os.cpu_count() or 4))


def _default_model_root() -> Path:
    configured = os.environ.get("GSTLENS_MODEL_DIR")
    if configured:
        return Path(configured).expanduser()
    # Keep this identical to gstlens_app.config without importing the app layer.
    if os.name == "nt":
        data_root = Path(
            os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")
        ) / "GSTLens"
    else:
        data_root = Path(
            os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")
        ) / "gstlens"
    return data_root.expanduser() / "models"


@dataclass(frozen=True, slots=True)
class PaddleOCRConfig:
    """Local PP-OCRv6 model and CPU inference settings."""

    model_root: Path = field(default_factory=_default_model_root)
    detection_model_name: str = "PP-OCRv6_medium_det"
    recognition_model_name: str = "PP-OCRv6_medium_rec"
    detection_model_dir: Path | None = None
    recognition_model_dir: Path | None = None
    device: str = "cpu"
    cpu_threads: int = _DEFAULT_CPU_THREADS
    enable_mkldnn: bool = True
    validate_model_artifacts: bool = True

    @property
    def resolved_detection_model_dir(self) -> Path:
        return Path(self.detection_model_dir or self.model_root / self.detection_model_name)

    @property
    def resolved_recognition_model_dir(self) -> Path:
        return Path(
            self.recognition_model_dir or self.model_root / self.recognition_model_name
        )

    @classmethod
    def from_env(cls) -> "PaddleOCRConfig":
        root = _default_model_root()
        detection = os.environ.get("GSTLENS_PADDLE_DET_MODEL")
        recognition = os.environ.get("GSTLENS_PADDLE_REC_MODEL")
        return cls(
            model_root=root,
            detection_model_dir=Path(detection).expanduser() if detection else None,
            recognition_model_dir=Path(recognition).expanduser()
            if recognition
            else None,
            device=os.environ.get(
                "GSTLENS_OCR_DEVICE", os.environ.get("GSTLENS_DEVICE", "cpu")
            ),
            cpu_threads=max(
                1, int(os.environ.get("GSTLENS_OCR_THREADS", _DEFAULT_CPU_THREADS))
            ),
        )


_MODEL_MARKERS = {
    "inference.json",
    "inference.pdmodel",
    "inference.pdiparams",
    "inference.yml",
    "model.yml",
    "config.yaml",
}


def _validate_model_directory(path: Path, label: str, check_artifacts: bool) -> None:
    if not path.is_dir():
        raise OCRModelError(
            f"The local {label} model is missing: {path}. Run the model setup "
            "once while online, then GSTLens can process invoices offline."
        )
    if not check_artifacts:
        return
    try:
        filenames = {candidate.name for candidate in path.rglob("*") if candidate.is_file()}
    except OSError as exc:
        raise OCRModelError(f"Cannot read the local {label} model at {path}.") from exc
    if not filenames.intersection(_MODEL_MARKERS) and not any(
        name.endswith((".pdmodel", ".pdiparams")) for name in filenames
    ):
        raise OCRModelError(
            f"The local {label} model folder is incomplete: {path}. "
            "Re-run the GSTLens model setup."
        )


def _set_offline_environment(model_root: Path) -> None:
    """Disable model source checks before importing PaddleOCR/PaddleX."""

    os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ.setdefault("PADDLEOCR_HOME", str(model_root.resolve()))


def _clamped_confidence(value: Any) -> float:
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(confidence):
        return 0.0
    return min(1.0, max(0.0, confidence))


def _polygon_from_value(value: Any) -> Polygon | None:
    if value is None:
        return None
    try:
        values = value.tolist() if hasattr(value, "tolist") else value
        if len(values) == 4 and all(
            isinstance(item, (int, float)) for item in values
        ):
            x1, y1, x2, y2 = (float(item) for item in values)
            return ((x1, y1), (x2, y1), (x2, y2), (x1, y2))
        points = tuple((float(point[0]), float(point[1])) for point in values)
        if len(points) >= 4 and all(
            math.isfinite(coordinate) for point in points for coordinate in point
        ):
            return points
    except (TypeError, ValueError, IndexError):
        return None
    return None


def _jsonish(value: Any) -> Any:
    if isinstance(value, (dict, list, tuple)):
        return value
    for attribute in ("json", "to_json"):
        if not hasattr(value, attribute):
            continue
        candidate = getattr(value, attribute)
        try:
            candidate = candidate() if callable(candidate) else candidate
        except Exception:
            continue
        if isinstance(candidate, str):
            try:
                return json.loads(candidate)
            except json.JSONDecodeError:
                continue
        if isinstance(candidate, (dict, list, tuple)):
            return candidate
    return value


def _find_modern_payload(value: Any) -> Mapping[str, Any] | None:
    value = _jsonish(value)
    queue: list[Any] = [value]
    visited: set[int] = set()
    while queue:
        current = queue.pop(0)
        identity = id(current)
        if identity in visited:
            continue
        visited.add(identity)
        if isinstance(current, Mapping):
            if "rec_texts" in current or "rec_scores" in current:
                return current
            for key in ("res", "result", "data"):
                if key in current:
                    queue.append(current[key])
        elif isinstance(current, (list, tuple)):
            queue.extend(current)
    return None


def _modern_tokens(payload: Mapping[str, Any], page_index: int) -> list[OCRToken]:
    texts = payload.get("rec_texts")
    scores = payload.get("rec_scores")
    polygons = payload.get("rec_polys")
    boxes = payload.get("rec_boxes")
    texts = [] if texts is None else texts
    scores = [] if scores is None else scores
    polygons = [] if polygons is None else polygons
    boxes = [] if boxes is None else boxes
    if hasattr(texts, "tolist"):
        texts = texts.tolist()
    if hasattr(scores, "tolist"):
        scores = scores.tolist()
    if hasattr(polygons, "tolist"):
        polygons = polygons.tolist()
    if hasattr(boxes, "tolist"):
        boxes = boxes.tolist()

    tokens: list[OCRToken] = []
    for index, raw_text in enumerate(texts):
        text = str(raw_text).replace("\x00", "").strip()
        if not text:
            continue
        confidence = _clamped_confidence(scores[index] if index < len(scores) else 0.0)
        raw_polygon = None
        if index < len(polygons):
            raw_polygon = polygons[index]
        elif index < len(boxes):
            raw_polygon = boxes[index]
        tokens.append(
            OCRToken(
                text=text,
                confidence=confidence,
                page_index=page_index,
                polygon=_polygon_from_value(raw_polygon),
                source="paddleocr",
            )
        )
    return tokens


def _legacy_tokens(value: Any, page_index: int) -> list[OCRToken]:
    value = _jsonish(value)
    entries: Any = value
    looks_like_entry = (
        isinstance(entries, (list, tuple))
        and len(entries) >= 2
        and isinstance(entries[1], (list, tuple))
        and bool(entries[1])
        and isinstance(entries[1][0], str)
    )
    if looks_like_entry:
        entries = [entries]
    # PaddleOCR 2.x returned one additional list level for a single image.
    elif (
        isinstance(entries, (list, tuple))
        and len(entries) == 1
        and isinstance(entries[0], (list, tuple))
    ):
        entries = entries[0]
    if not isinstance(entries, (list, tuple)):
        return []

    tokens: list[OCRToken] = []
    for entry in entries:
        if not isinstance(entry, (list, tuple)) or len(entry) < 2:
            continue
        box, recognition = entry[0], entry[1]
        if not isinstance(recognition, (list, tuple)) or not recognition:
            continue
        text = str(recognition[0]).replace("\x00", "").strip()
        if not text:
            continue
        score = recognition[1] if len(recognition) > 1 else 0.0
        tokens.append(
            OCRToken(
                text=text,
                confidence=_clamped_confidence(score),
                page_index=page_index,
                polygon=_polygon_from_value(box),
                source="paddleocr",
            )
        )
    return tokens


def parse_paddle_predictions(
    predictions: Any,
    *,
    page_index: int,
    width: int,
    height: int,
    native_text: str = "",
) -> PageOCRResult:
    """Normalize PaddleOCR 3.x Result objects (and legacy output) into tokens."""

    if isinstance(predictions, (str, bytes, Mapping)) or hasattr(predictions, "json"):
        items = [predictions]
    else:
        try:
            items = list(predictions)
        except TypeError:
            items = [predictions]

    tokens: list[OCRToken] = []
    for item in items:
        payload = _find_modern_payload(item)
        if payload is not None:
            tokens.extend(_modern_tokens(payload, page_index))
        else:
            tokens.extend(_legacy_tokens(item, page_index))
    mean_confidence = (
        sum(token.confidence for token in tokens) / len(tokens) if tokens else 0.0
    )
    return PageOCRResult(
        page_index=page_index,
        width=int(width),
        height=int(height),
        tokens=tuple(tokens),
        text="\n".join(token.text for token in tokens),
        mean_confidence=mean_confidence,
        source="paddleocr",
        native_text=native_text,
    )


class PaddleOCREngine:
    """Thread-safe, lazy PP-OCRv6 engine that only loads local model folders."""

    def __init__(
        self,
        config: PaddleOCRConfig | None = None,
        *,
        engine_factory: Callable[..., Any] | None = None,
    ) -> None:
        self.config = config or PaddleOCRConfig.from_env()
        self._engine_factory = engine_factory
        self._engine: Any | None = None
        self._load_lock = threading.Lock()
        self._prediction_lock = threading.Lock()

    @property
    def loaded(self) -> bool:
        return self._engine is not None

    def _constructor_kwargs(self) -> dict[str, Any]:
        return {
            "text_detection_model_dir": str(
                self.config.resolved_detection_model_dir.resolve()
            ),
            "text_recognition_model_dir": str(
                self.config.resolved_recognition_model_dir.resolve()
            ),
            "use_doc_orientation_classify": False,
            "use_doc_unwarping": False,
            "use_textline_orientation": False,
            "device": self.config.device,
            "enable_mkldnn": self.config.enable_mkldnn,
            "cpu_threads": self.config.cpu_threads,
        }

    def load(self) -> Any:
        if self._engine is not None:
            return self._engine
        with self._load_lock:
            if self._engine is not None:
                return self._engine
            detection_dir = self.config.resolved_detection_model_dir
            recognition_dir = self.config.resolved_recognition_model_dir
            _validate_model_directory(
                detection_dir, "text detection", self.config.validate_model_artifacts
            )
            _validate_model_directory(
                recognition_dir,
                "text recognition",
                self.config.validate_model_artifacts,
            )
            _set_offline_environment(self.config.model_root)

            factory = self._engine_factory
            if factory is None:
                try:
                    from paddleocr import PaddleOCR
                except ModuleNotFoundError as exc:
                    missing = exc.name or "paddleocr"
                    raise OptionalDependencyError(
                        missing,
                        "Run the GSTLens Windows installer to install the local "
                        "PaddleOCR runtime.",
                    ) from exc
                factory = PaddleOCR
            try:
                self._engine = factory(**self._constructor_kwargs())
            except Exception as exc:
                raise OCRModelError(
                    "The local PP-OCRv6 engine could not start. Verify the installed "
                    "PaddleOCR version, model folders, and selected CPU/GPU device."
                ) from exc
        return self._engine

    def recognize_page(
        self, image: Any, *, page_index: int = 0, native_text: str = ""
    ) -> PageOCRResult:
        rgb = normalize_rgb_image(image)
        engine = self.load()
        try:
            with self._prediction_lock:
                predictions = engine.predict(input=rgb)
                return parse_paddle_predictions(
                    predictions,
                    page_index=page_index,
                    width=rgb.shape[1],
                    height=rgb.shape[0],
                    native_text=native_text,
                )
        except (OCRModelError, OptionalDependencyError):
            raise
        except Exception as exc:
            raise OCRPredictionError(
                f"Local OCR failed on page {page_index + 1}. The original invoice "
                "has not been changed."
            ) from exc

    def ocr_pdf(
        self,
        path: str | os.PathLike[str],
        *,
        progress: Callable[[Any], None] | None = None,
        cancelled: Callable[[], bool] | None = None,
        **runtime_options: Any,
    ) -> Any:
        """OCR a PDF locally; imported lazily to avoid a module cycle."""

        from .runtime import InvoiceOCRRuntime, OCRRuntimeConfig

        runtime_config = runtime_options.pop("config", None)
        if runtime_config is None:
            runtime_config = OCRRuntimeConfig(**runtime_options)
        elif runtime_options:
            raise TypeError("Pass either config=OCRRuntimeConfig(...) or keyword options.")
        return InvoiceOCRRuntime(self, runtime_config).ocr_pdf(
            path, progress=progress, cancelled=cancelled
        )

    def close(self) -> None:
        with self._load_lock:
            engine, self._engine = self._engine, None
            if engine is not None and hasattr(engine, "close"):
                engine.close()
