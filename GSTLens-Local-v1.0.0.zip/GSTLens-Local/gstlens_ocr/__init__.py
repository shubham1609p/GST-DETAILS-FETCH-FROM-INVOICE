"""Public API for GSTLens' no-cloud OCR runtime."""

from .errors import (
    NoInvoicesFoundError,
    OCRModelError,
    OCRPredictionError,
    OCRRuntimeError,
    OptionalDependencyError,
    PDFReadError,
    ProcessingCancelled,
    UnsafeInputError,
)
from .files import (
    InvoiceDocument,
    UploadSafetyLimits,
    enumerate_invoice_documents,
    enumerate_uploaded_pdfs,
    is_pdf_file,
    safe_extract_invoice_pdfs,
    sha256_file,
)
from .paddle import PaddleOCRConfig, PaddleOCREngine, parse_paddle_predictions
from .pdf import PDFDocumentReader, PDFSafetyLimits, extract_native_text
from .preprocess import PreprocessConfig, preprocess_image
from .runtime import (
    BatchOCRItem,
    InvoiceOCRRuntime,
    OCRProgress,
    OCRRuntimeConfig,
)
from .types import DocumentOCRResult, OCRToken, PageOCRResult, RenderedPage

__all__ = [
    "BatchOCRItem",
    "DocumentOCRResult",
    "InvoiceDocument",
    "InvoiceOCRRuntime",
    "NoInvoicesFoundError",
    "OCRModelError",
    "OCRPredictionError",
    "OCRProgress",
    "OCRRuntimeConfig",
    "OCRRuntimeError",
    "OCRToken",
    "OptionalDependencyError",
    "PDFDocumentReader",
    "PDFReadError",
    "PDFSafetyLimits",
    "PaddleOCRConfig",
    "PaddleOCREngine",
    "PageOCRResult",
    "PreprocessConfig",
    "ProcessingCancelled",
    "RenderedPage",
    "UnsafeInputError",
    "UploadSafetyLimits",
    "enumerate_invoice_documents",
    "enumerate_uploaded_pdfs",
    "extract_native_text",
    "is_pdf_file",
    "parse_paddle_predictions",
    "preprocess_image",
    "safe_extract_invoice_pdfs",
    "sha256_file",
]
