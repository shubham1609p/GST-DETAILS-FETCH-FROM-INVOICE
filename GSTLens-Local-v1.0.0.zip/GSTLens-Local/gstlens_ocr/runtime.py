"""High-level local PDF OCR and resumable-friendly batch primitives."""

from __future__ import annotations

import os
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .errors import ProcessingCancelled
from .files import InvoiceDocument, sha256_file
from .pdf import PDFDocumentReader, PDFSafetyLimits, has_meaningful_native_text
from .preprocess import PreprocessConfig, preprocess_image
from .types import DocumentOCRResult, PageOCRResult


@dataclass(frozen=True, slots=True)
class OCRRuntimeConfig:
    render_dpi: int = 220
    prefer_native_text: bool = True
    force_image_ocr: bool = False
    minimum_native_alphanumeric: int = 40
    preprocess: PreprocessConfig = field(default_factory=PreprocessConfig)
    pdf_limits: PDFSafetyLimits = field(default_factory=PDFSafetyLimits)


@dataclass(frozen=True, slots=True)
class OCRProgress:
    path: Path
    page_index: int
    page_count: int
    source: str


@dataclass(frozen=True, slots=True)
class BatchOCRItem:
    document: InvoiceDocument
    result: DocumentOCRResult | None
    error: str | None

    @property
    def succeeded(self) -> bool:
        return self.result is not None and self.error is None


class InvoiceOCRRuntime:
    """Use embedded text when reliable and local PP-OCRv6 for scanned pages."""

    def __init__(self, engine: Any, config: OCRRuntimeConfig | None = None) -> None:
        self.engine = engine
        self.config = config or OCRRuntimeConfig()

    def ocr_pdf(
        self,
        path: str | os.PathLike[str],
        *,
        progress: Callable[[OCRProgress], None] | None = None,
        cancelled: Callable[[], bool] | None = None,
    ) -> DocumentOCRResult:
        pdf_path = Path(path)
        pages: list[PageOCRResult] = []
        with PDFDocumentReader(pdf_path, limits=self.config.pdf_limits) as document:
            page_count = document.page_count
            for page_index in range(page_count):
                if cancelled is not None and cancelled():
                    raise ProcessingCancelled(
                        f"OCR cancelled before page {page_index + 1} of {pdf_path.name}."
                    )
                native_text = document.native_text(page_index)
                use_native = (
                    self.config.prefer_native_text
                    and not self.config.force_image_ocr
                    and has_meaningful_native_text(
                        native_text, self.config.minimum_native_alphanumeric
                    )
                )
                if use_native:
                    result = document.native_page_result(
                        page_index, dpi=self.config.render_dpi
                    )
                else:
                    rendered = document.render_page(
                        page_index, dpi=self.config.render_dpi
                    )
                    image = preprocess_image(rendered.image, self.config.preprocess)
                    result = self.engine.recognize_page(
                        image, page_index=page_index, native_text=native_text
                    )
                pages.append(result)
                if progress is not None:
                    progress(
                        OCRProgress(
                            path=pdf_path,
                            page_index=page_index,
                            page_count=page_count,
                            source=result.source,
                        )
                    )
        return DocumentOCRResult(
            path=pdf_path,
            sha256=sha256_file(pdf_path),
            pages=tuple(pages),
        )

    def ocr_documents(
        self,
        documents: Iterable[InvoiceDocument],
        *,
        continue_on_error: bool = True,
        progress: Callable[[OCRProgress], None] | None = None,
        cancelled: Callable[[], bool] | None = None,
    ) -> tuple[BatchOCRItem, ...]:
        """Process each PDF independently so callers can persist/resume per item."""

        items: list[BatchOCRItem] = []
        for document in documents:
            if cancelled is not None and cancelled():
                raise ProcessingCancelled("OCR batch cancelled between invoice files.")
            try:
                result = self.ocr_pdf(
                    document.path, progress=progress, cancelled=cancelled
                )
            except ProcessingCancelled:
                raise
            except Exception as exc:
                if not continue_on_error:
                    raise
                items.append(
                    BatchOCRItem(document=document, result=None, error=str(exc))
                )
            else:
                items.append(BatchOCRItem(document=document, result=result, error=None))
        return tuple(items)
