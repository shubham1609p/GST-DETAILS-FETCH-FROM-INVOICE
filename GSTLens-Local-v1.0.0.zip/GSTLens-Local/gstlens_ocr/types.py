"""Small, serializable value objects shared by the OCR modules."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal


Point = tuple[float, float]
Polygon = tuple[Point, ...]
OCRSource = Literal["paddleocr", "native_pdf"]


@dataclass(frozen=True, slots=True)
class OCRToken:
    """One recognized text token and its page-space polygon in pixels."""

    text: str
    confidence: float
    page_index: int
    polygon: Polygon | None = None
    source: OCRSource = "paddleocr"

    @property
    def bbox(self) -> tuple[float, float, float, float] | None:
        if not self.polygon:
            return None
        xs = [point[0] for point in self.polygon]
        ys = [point[1] for point in self.polygon]
        return min(xs), min(ys), max(xs), max(ys)

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "confidence": self.confidence,
            "page_index": self.page_index,
            "polygon": [list(point) for point in self.polygon]
            if self.polygon
            else None,
            "bbox": list(self.bbox) if self.bbox else None,
            "source": self.source,
        }


@dataclass(frozen=True, slots=True)
class PageOCRResult:
    """Recognized content for one PDF page."""

    page_index: int
    width: int
    height: int
    tokens: tuple[OCRToken, ...]
    text: str
    mean_confidence: float
    source: OCRSource
    native_text: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "page_index": self.page_index,
            "width": self.width,
            "height": self.height,
            "tokens": [token.to_dict() for token in self.tokens],
            "text": self.text,
            "mean_confidence": self.mean_confidence,
            "source": self.source,
            "native_text": self.native_text,
        }


@dataclass(frozen=True, slots=True)
class DocumentOCRResult:
    """OCR result for a complete invoice PDF."""

    path: Path
    sha256: str
    pages: tuple[PageOCRResult, ...]

    @property
    def text(self) -> str:
        return "\n\f\n".join(page.text for page in self.pages)

    @property
    def tokens(self) -> tuple[OCRToken, ...]:
        return tuple(token for page in self.pages for token in page.tokens)

    @property
    def evidence(self) -> tuple[dict[str, Any], ...]:
        """Serializable page/token evidence suitable for a review screen."""

        return tuple(
            {
                "page_index": page.page_index,
                "source": page.source,
                "native_text": page.native_text,
                "tokens": [token.to_dict() for token in page.tokens],
            }
            for page in self.pages
        )

    @property
    def mean_confidence(self) -> float:
        tokens = self.tokens
        if not tokens:
            return 0.0
        return sum(token.confidence for token in tokens) / len(tokens)

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": str(self.path),
            "sha256": self.sha256,
            "pages": [page.to_dict() for page in self.pages],
            "text": self.text,
            "mean_confidence": self.mean_confidence,
        }


@dataclass(frozen=True, slots=True)
class RenderedPage:
    """A rendered PDF page represented as a uint8 RGB NumPy array."""

    page_index: int
    dpi: int
    image: Any = field(repr=False)

    @property
    def width(self) -> int:
        return int(self.image.shape[1])

    @property
    def height(self) -> int:
        return int(self.image.shape[0])
