from __future__ import annotations

import json
import threading
import traceback
from dataclasses import replace
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from gstlens_core import (
    InvoiceMatchStatus,
    InvoiceMatcher,
    InvoiceReference,
    WorkbookMapping,
    extract_document_fields,
    normalize_invoice_number,
    read_invoice_rows,
)
from gstlens_ocr import (
    InvoiceOCRRuntime,
    OCRRuntimeConfig,
    PaddleOCRConfig,
    PaddleOCREngine,
    ProcessingCancelled,
    UploadSafetyLimits,
    enumerate_uploaded_pdfs,
)

from .analysis_bridge import resolve_document_fields, to_core_pages
from .config import AppConfig
from .database import Database, utc_now
from .exporter import export_audit_csv, export_workbook_rows


REVIEW_VALUE = "Requires Review"
_VALID_CODE_LENGTHS = {4, 6, 8}


def _error_text(exc: BaseException) -> str:
    text = str(exc).strip() or exc.__class__.__name__
    return text[:2000]


def _valid_review_codes(value: str) -> str:
    codes = [part.strip() for part in value.split(",") if part.strip()]
    if not codes or any(not code.isdigit() or len(code) not in _VALID_CODE_LENGTHS for code in codes):
        raise ValueError("Enter only 4-, 6- or 8-digit HSN/SAC codes separated by commas")
    return ", ".join(dict.fromkeys(codes))


class BatchProcessor:
    """Persistent, single-document-at-a-time OCR orchestration."""

    def __init__(self, database: Database, config: AppConfig) -> None:
        self.database = database
        self.config = config
        self._threads: dict[str, threading.Thread] = {}
        self._thread_lock = threading.Lock()
        self._export_locks: dict[str, threading.Lock] = {}

    def _export_lock(self, batch_id: str) -> threading.Lock:
        with self._thread_lock:
            return self._export_locks.setdefault(batch_id, threading.Lock())

    def register_documents(self, batch_id: str, upload_dir: Path, extraction_dir: Path) -> int:
        limits = UploadSafetyLimits(
            max_archive_entries=self.config.max_pdf_count * 5,
            max_pdf_count=self.config.max_pdf_count,
            max_member_bytes=self.config.max_single_pdf_bytes,
            max_total_uncompressed_bytes=self.config.max_archive_unpacked_bytes,
            max_direct_pdf_bytes=self.config.max_single_pdf_bytes,
        )
        documents = enumerate_uploaded_pdfs(
            upload_dir,
            extraction_root=extraction_dir,
            limits=limits,
            deduplicate_by_hash=False,
        )
        duplicate_count = 0
        inserted = 0
        with self.database.transaction() as connection:
            for document in documents:
                cursor = connection.execute(
                    """
                    INSERT OR IGNORE INTO documents(
                        batch_id,file_name,path,sha256,status,created_at
                    ) VALUES(?,?,?,?,?,?)
                    """,
                    (
                        batch_id,
                        document.display_name,
                        str(document.path.resolve()),
                        document.sha256,
                        "queued",
                        utc_now(),
                    ),
                )
                if cursor.rowcount:
                    inserted += 1
                else:
                    duplicate_count += 1
            connection.execute(
                "UPDATE batches SET total_docs=?, duplicate_count=? WHERE id=?",
                (inserted, duplicate_count, batch_id),
            )
        return inserted

    def action(self, batch_id: str, action: str) -> None:
        batch = self.database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
        if batch is None:
            raise KeyError(batch_id)
        if action in {"start", "resume"}:
            self.start(batch_id)
            return
        if action == "pause":
            self.database.execute(
                "UPDATE batches SET status='paused' WHERE id=? AND status='processing'",
                (batch_id,),
            )
            self.database.add_audit("batch.paused", batch_id=batch_id)
            return
        if action == "cancel":
            self.database.execute(
                "UPDATE batches SET status='cancelled',completed_at=? WHERE id=?",
                (utc_now(), batch_id),
            )
            self.database.add_audit("batch.cancelled", batch_id=batch_id)
            return
        if action == "retry":
            with self.database.transaction() as connection:
                connection.execute(
                    "UPDATE documents SET status='queued',error_message=NULL WHERE batch_id=? AND status='error'",
                    (batch_id,),
                )
                connection.execute(
                    "UPDATE batches SET status='paused',error_count=0,error_message=NULL,completed_at=NULL WHERE id=?",
                    (batch_id,),
                )
            self.start(batch_id)
            return
        raise ValueError(f"Unknown batch action {action!r}")

    def start(self, batch_id: str) -> None:
        batch = self.database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
        if batch is None:
            raise KeyError(batch_id)
        if not all(batch.get(key) for key in ("sheet_name", "header_row", "invoice_col", "hsn_col")):
            raise ValueError("Confirm the workbook mapping before starting")
        with self._thread_lock:
            running = self._threads.get(batch_id)
            if running is not None and running.is_alive():
                return
            self.database.execute(
                """
                UPDATE batches
                SET status='processing',started_at=COALESCE(started_at,?),completed_at=NULL,error_message=NULL
                WHERE id=?
                """,
                (utc_now(), batch_id),
            )
            thread = threading.Thread(
                target=self._thread_entry,
                args=(batch_id,),
                name=f"gstlens-{batch_id[:8]}",
                daemon=True,
            )
            self._threads[batch_id] = thread
            thread.start()

    def _thread_entry(self, batch_id: str) -> None:
        try:
            self._process(batch_id)
        except Exception as exc:  # Last-resort containment; per-PDF errors are handled below.
            traceback.print_exc()
            self.database.execute(
                "UPDATE batches SET status='failed',error_message=?,completed_at=? WHERE id=?",
                (_error_text(exc), utc_now(), batch_id),
            )
            self.database.add_audit(
                "batch.failed", batch_id=batch_id, detail={"error": _error_text(exc)}
            )
        finally:
            with self._thread_lock:
                self._threads.pop(batch_id, None)

    def _engines(self) -> tuple[InvoiceOCRRuntime, InvoiceOCRRuntime]:
        common = dict(
            model_root=self.config.model_dir,
            detection_model_dir=self.config.model_dir / "PP-OCRv6_medium_det",
            device=self.config.device,
        )
        primary = PaddleOCREngine(
            PaddleOCRConfig(
                **common,
                recognition_model_dir=self.config.model_dir / "PP-OCRv6_medium_rec",
            )
        )
        handwriting = PaddleOCREngine(
            PaddleOCRConfig(
                **common,
                recognition_model_name="en_PP-OCRv5_mobile_rec",
                recognition_model_dir=self.config.model_dir / "en_PP-OCRv5_mobile_rec",
            )
        )
        runtime_config = OCRRuntimeConfig(render_dpi=self.config.render_dpi)
        return InvoiceOCRRuntime(primary, runtime_config), InvoiceOCRRuntime(handwriting, runtime_config)

    def _process(self, batch_id: str) -> None:
        batch = self.database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
        if batch is None:
            raise KeyError(batch_id)
        mapping = WorkbookMapping(
            batch["sheet_name"], int(batch["header_row"]), int(batch["invoice_col"]), int(batch["hsn_col"])
        )
        workbook_rows = read_invoice_rows(Path(batch["workbook_path"]), mapping)
        matcher = InvoiceMatcher(
            InvoiceReference(row.row_number, row.invoice_number) for row in workbook_rows
        )
        primary_runtime, handwriting_runtime = self._engines()
        def cancelled() -> bool:
            current = self.database.row("SELECT status FROM batches WHERE id=?", (batch_id,))
            return current is None or current["status"] in {"paused", "cancelled"}

        documents = self.database.rows(
            "SELECT * FROM documents WHERE batch_id=? AND status IN ('queued','processing') ORDER BY id",
            (batch_id,),
        )
        for document in documents:
            state = self.database.row("SELECT status FROM batches WHERE id=?", (batch_id,))
            if state is None or state["status"] in {"paused", "cancelled"}:
                return
            self.database.execute(
                "UPDATE documents SET status='processing',error_message=NULL WHERE id=?",
                (document["id"],),
            )
            try:
                primary_result = primary_runtime.ocr_pdf(Path(document["path"]), cancelled=cancelled)
                primary_fields = extract_document_fields(
                    to_core_pages(primary_result),
                    matcher,
                    invoice_low_confidence_threshold=self.config.auto_accept_confidence,
                    hsn_low_confidence_threshold=self.config.auto_accept_confidence,
                )
                needs_handwriting = (
                    primary_fields.invoice.status is not InvoiceMatchStatus.MATCHED
                    or primary_fields.invoice.requires_review
                    or primary_fields.hsn_sac.requires_review
                    or not primary_fields.hsn_sac.codes
                )
                handwriting_fields = None
                fallback_error = None
                if needs_handwriting:
                    try:
                        handwriting_result = handwriting_runtime.ocr_pdf(
                            Path(document["path"]), cancelled=cancelled
                        )
                        handwriting_fields = extract_document_fields(
                            to_core_pages(handwriting_result),
                            matcher,
                            invoice_low_confidence_threshold=self.config.auto_accept_confidence,
                            hsn_low_confidence_threshold=self.config.auto_accept_confidence,
                        )
                    except ProcessingCancelled:
                        raise
                    except Exception as exc:
                        fallback_error = _error_text(exc)
                resolved = resolve_document_fields(primary_fields, handwriting_fields)
                if fallback_error and needs_handwriting:
                    resolved = replace(
                        resolved,
                        requires_review=True,
                        reasons=tuple(
                            dict.fromkeys((*resolved.reasons, "Handwriting verification pass failed"))
                        ),
                    )
                    resolved.evidence["handwriting_error"] = fallback_error
                resolved.evidence["pages"] = [
                    {
                        "page": page.page_index + 1,
                        "width": page.width,
                        "height": page.height,
                        "source": page.source,
                    }
                    for page in primary_result.pages
                ]
                resolved.evidence["resolved"] = {
                    "reference_ids": list(resolved.reference_ids),
                    "observed_invoice_number": resolved.observed_invoice_number,
                    "codes": list(resolved.codes),
                    "match_state": resolved.match_state,
                    "confidence": resolved.confidence,
                    "requires_review": resolved.requires_review,
                    "reasons": list(resolved.reasons),
                }
                document_status = (
                    "orphan"
                    if not resolved.reference_ids
                    else "review"
                    if resolved.requires_review or len(resolved.reference_ids) > 1
                    else "done"
                )
                self.database.execute(
                    """
                    UPDATE documents
                    SET status=?,page_count=?,invoice_number=?,invoice_key=?,hsn_codes=?,confidence=?,
                        match_state=?,reason=?,evidence_json=?,error_message=NULL,processed_at=?
                    WHERE id=?
                    """,
                    (
                        document_status,
                        len(primary_result.pages),
                        resolved.observed_invoice_number,
                        normalize_invoice_number(resolved.observed_invoice_number or ""),
                        ", ".join(resolved.codes),
                        resolved.confidence,
                        resolved.match_state,
                        "; ".join(resolved.reasons),
                        json.dumps(resolved.evidence, ensure_ascii=False, separators=(",", ":")),
                        utc_now(),
                        document["id"],
                    ),
                )
            except ProcessingCancelled:
                self.database.execute(
                    "UPDATE documents SET status='queued',error_message=NULL WHERE id=?",
                    (document["id"],),
                )
                return
            except Exception as exc:
                self.database.execute(
                    "UPDATE documents SET status='error',error_message=?,processed_at=? WHERE id=?",
                    (_error_text(exc), utc_now(), document["id"]),
                )
            self._update_progress(batch_id)

        state = self.database.row("SELECT status FROM batches WHERE id=?", (batch_id,))
        if state and state["status"] == "processing":
            self.reconcile_and_export(batch_id)

    def _update_progress(self, batch_id: str) -> None:
        counts = self.database.row(
            """
            SELECT COUNT(*) AS processed,
                   SUM(CASE WHEN status='error' THEN 1 ELSE 0 END) AS errors,
                   SUM(CASE WHEN status='orphan' THEN 1 ELSE 0 END) AS orphans
            FROM documents
            WHERE batch_id=? AND status NOT IN ('queued','processing')
            """,
            (batch_id,),
        ) or {}
        self.database.execute(
            "UPDATE batches SET processed_docs=?,error_count=?,orphan_count=? WHERE id=?",
            (
                int(counts.get("processed") or 0),
                int(counts.get("errors") or 0),
                int(counts.get("orphans") or 0),
                batch_id,
            ),
        )

    def _previous_values(
        self, workbook_path: Path, mapping: WorkbookMapping, row_numbers: list[int]
    ) -> dict[int, object]:
        workbook = load_workbook(
            workbook_path,
            read_only=True,
            data_only=False,
            keep_vba=workbook_path.suffix.lower() in {".xlsm", ".xltm"},
            keep_links=True,
        )
        try:
            sheet = workbook[mapping.sheet_name]
            return {
                row: sheet.cell(row=row, column=mapping.hsn_column).value
                for row in row_numbers
            }
        finally:
            workbook.close()

    def reconcile_and_export(self, batch_id: str) -> None:
        batch = self.database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
        if batch is None:
            raise KeyError(batch_id)
        mapping = WorkbookMapping(
            batch["sheet_name"], int(batch["header_row"]), int(batch["invoice_col"]), int(batch["hsn_col"])
        )
        workbook_path = Path(batch["workbook_path"])
        workbook_rows = read_invoice_rows(workbook_path, mapping)
        previous_values = self._previous_values(
            workbook_path, mapping, [row.row_number for row in workbook_rows]
        )
        documents = self.database.rows(
            "SELECT * FROM documents WHERE batch_id=? ORDER BY id", (batch_id,)
        )
        by_reference: dict[int, list[dict[str, Any]]] = {}
        failed_documents = [item for item in documents if item["status"] == "error"]
        orphan_count = 0
        for document in documents:
            try:
                evidence = json.loads(document.get("evidence_json") or "{}")
                resolved = evidence.get("resolved") or {}
            except (TypeError, json.JSONDecodeError):
                evidence, resolved = {}, {}
            references = [int(value) for value in resolved.get("reference_ids", [])]
            document["_evidence"] = evidence
            document["_resolved"] = resolved
            if not references and document["status"] != "error":
                orphan_count += 1
            for reference in references:
                by_reference.setdefault(reference, []).append(document)

        existing = {
            int(item["excel_row"]): item
            for item in self.database.rows(
                "SELECT * FROM results WHERE batch_id=? AND review_state IN ('resolved','edited','approved')",
                (batch_id,),
            )
        }
        generated: list[dict[str, Any]] = []
        for row in workbook_rows:
            old = existing.get(row.row_number)
            if old is not None:
                generated.append(old)
                continue
            matched_documents = by_reference.get(row.row_number, [])
            output_value: str
            status: str
            review_state = "none"
            document_id: int | None = None
            confidence: float | None = None
            evidence: dict[str, Any] = {}
            if not matched_documents:
                if failed_documents:
                    status = "review"
                    output_value = REVIEW_VALUE
                    review_state = "pending"
                    evidence = {
                        "reasons": [
                            "One or more uploaded PDFs failed OCR; Invoice Missing cannot be finalized safely"
                        ],
                        "failed_documents": [item["file_name"] for item in failed_documents],
                        "proposed_codes": [],
                    }
                else:
                    status = "missing"
                    output_value = batch["missing_phrase"]
            elif len(matched_documents) > 1:
                status = "review"
                output_value = REVIEW_VALUE
                review_state = "pending"
                document_id = int(matched_documents[0]["id"])
                confidence = min(float(item.get("confidence") or 0) for item in matched_documents)
                evidence = {
                    "reasons": ["More than one non-identical PDF matches this Excel invoice"],
                    "document_ids": [int(item["id"]) for item in matched_documents],
                    "pdf_files": [item["file_name"] for item in matched_documents],
                    "proposed_codes": sorted(
                        {
                            code
                            for item in matched_documents
                            for code in (item.get("hsn_codes") or "").split(", ")
                            if code
                        }
                    ),
                }
            else:
                document = matched_documents[0]
                resolved = document["_resolved"]
                document_id = int(document["id"])
                confidence = float(resolved.get("confidence") or document.get("confidence") or 0)
                codes = tuple(str(code) for code in resolved.get("codes", []) if str(code))
                reasons = list(resolved.get("reasons", []))
                requires_review = bool(resolved.get("requires_review")) or document["status"] == "review"
                if requires_review:
                    status = "review"
                    output_value = REVIEW_VALUE
                    review_state = "pending"
                elif codes:
                    status = "matched"
                    output_value = ", ".join(dict.fromkeys(codes))
                else:
                    status = "no_hsn"
                    output_value = batch["found_no_hsn_phrase"]
                evidence = {
                    "reasons": reasons,
                    "proposed_codes": list(codes),
                    "document_id": document_id,
                    "pdf_file": document["file_name"],
                    "observed_invoice_number": resolved.get("observed_invoice_number"),
                    "candidate_evidence": document["_evidence"],
                }

            generated.append(
                {
                    "batch_id": batch_id,
                    "excel_row": row.row_number,
                    "invoice_number": row.invoice_number,
                    "invoice_key": row.normalized_invoice_number,
                    "previous_value": previous_values.get(row.row_number),
                    "output_value": output_value,
                    "status": status,
                    "document_id": document_id,
                    "confidence": confidence,
                    "evidence_json": json.dumps(evidence, ensure_ascii=False, separators=(",", ":")),
                    "review_state": review_state,
                    "review_note": None,
                }
            )

        with self.database.transaction() as connection:
            for result in generated:
                connection.execute(
                    """
                    INSERT INTO results(
                        batch_id,excel_row,invoice_number,invoice_key,previous_value,output_value,
                        status,document_id,confidence,evidence_json,review_state,review_note,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(batch_id,excel_row) DO UPDATE SET
                        invoice_number=excluded.invoice_number,
                        invoice_key=excluded.invoice_key,
                        previous_value=excluded.previous_value,
                        output_value=CASE WHEN results.review_state IN ('resolved','edited','approved')
                                          THEN results.output_value ELSE excluded.output_value END,
                        status=CASE WHEN results.review_state IN ('resolved','edited','approved')
                                    THEN results.status ELSE excluded.status END,
                        document_id=excluded.document_id,
                        confidence=excluded.confidence,
                        evidence_json=excluded.evidence_json,
                        review_state=CASE WHEN results.review_state IN ('resolved','edited','approved')
                                          THEN results.review_state ELSE excluded.review_state END,
                        review_note=CASE WHEN results.review_state IN ('resolved','edited','approved')
                                        THEN results.review_note ELSE excluded.review_note END,
                        updated_at=excluded.updated_at
                    """,
                    (
                        result["batch_id"],
                        result["excel_row"],
                        result["invoice_number"],
                        result["invoice_key"],
                        result["previous_value"],
                        result["output_value"],
                        result["status"],
                        result["document_id"],
                        result["confidence"],
                        result["evidence_json"],
                        result["review_state"],
                        result["review_note"],
                        utc_now(),
                    ),
                )
        self._refresh_counts_and_exports(batch_id, orphan_count=orphan_count)

    def _result_rows_for_export(self, batch_id: str) -> list[dict[str, Any]]:
        rows = self.database.rows(
            """
            SELECT r.*,d.file_name AS pdf_file,d.invoice_number AS observed_invoice_number
            FROM results r LEFT JOIN documents d ON d.id=r.document_id
            WHERE r.batch_id=? ORDER BY r.excel_row
            """,
            (batch_id,),
        )
        return rows

    def _refresh_counts_and_exports(self, batch_id: str, *, orphan_count: int | None = None) -> None:
        with self._export_lock(batch_id):
            self._refresh_counts_and_exports_unlocked(batch_id, orphan_count=orphan_count)

    def _refresh_counts_and_exports_unlocked(
        self, batch_id: str, *, orphan_count: int | None = None
    ) -> None:
        batch = self.database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
        if batch is None:
            raise KeyError(batch_id)
        counts = self.database.row(
            """
            SELECT COUNT(*) AS total_rows,
                   SUM(CASE WHEN status='matched' THEN 1 ELSE 0 END) AS matched,
                   SUM(CASE WHEN status='missing' THEN 1 ELSE 0 END) AS missing,
                   SUM(CASE WHEN status='no_hsn' THEN 1 ELSE 0 END) AS no_hsn,
                   SUM(CASE WHEN status='review' THEN 1 ELSE 0 END) AS review
            FROM results WHERE batch_id=?
            """,
            (batch_id,),
        ) or {}
        doc_counts = self.database.row(
            """
            SELECT SUM(CASE WHEN status='error' THEN 1 ELSE 0 END) AS errors,
                   SUM(CASE WHEN status NOT IN ('queued','processing') THEN 1 ELSE 0 END) AS processed,
                   SUM(CASE WHEN status='orphan' THEN 1 ELSE 0 END) AS orphans
            FROM documents WHERE batch_id=?
            """,
            (batch_id,),
        ) or {}
        review_count = int(counts.get("review") or 0)
        error_count = int(doc_counts.get("errors") or 0)
        final_status = "needs_review" if review_count or error_count else "completed"
        batch_dir = self.config.batches_dir / batch_id
        source = Path(batch["workbook_path"])
        output = batch_dir / "exports" / f"{source.stem} - HSN Updated{source.suffix}"
        audit = batch_dir / "exports" / f"{source.stem} - HSN Audit.csv"
        mapping = WorkbookMapping(
            batch["sheet_name"], int(batch["header_row"]), int(batch["invoice_col"]), int(batch["hsn_col"])
        )
        export_rows = self._result_rows_for_export(batch_id)
        export_workbook_rows(source, output, mapping, export_rows)
        export_audit_csv(audit, export_rows)
        self.database.execute(
            """
            UPDATE batches SET status=?,output_path=?,audit_path=?,total_rows=?,matched_count=?,
                missing_count=?,no_hsn_count=?,review_count=?,orphan_count=?,error_count=?,
                processed_docs=?,completed_at=?,error_message=NULL
            WHERE id=?
            """,
            (
                final_status,
                str(output),
                str(audit),
                int(counts.get("total_rows") or 0),
                int(counts.get("matched") or 0),
                int(counts.get("missing") or 0),
                int(counts.get("no_hsn") or 0),
                review_count,
                int(orphan_count if orphan_count is not None else (doc_counts.get("orphans") or 0)),
                error_count,
                int(doc_counts.get("processed") or 0),
                utc_now(),
                batch_id,
            ),
        )
        self.database.add_audit(
            "batch.exported",
            batch_id=batch_id,
            detail={"status": final_status, "review_count": review_count, "error_count": error_count},
        )

    def apply_review(
        self,
        result_id: int,
        *,
        reviewer_id: int,
        action: str,
        value: str | None,
        note: str | None,
    ) -> dict[str, Any]:
        result = self.database.row("SELECT * FROM results WHERE id=?", (result_id,))
        if result is None:
            raise KeyError(result_id)
        batch = self.database.row("SELECT * FROM batches WHERE id=?", (result["batch_id"],))
        if batch is None:
            raise KeyError(result["batch_id"])
        evidence = json.loads(result.get("evidence_json") or "{}")
        if action == "accept":
            proposed = value or ", ".join(evidence.get("proposed_codes") or [])
            output = _valid_review_codes(proposed)
            new_status, review_state = "matched", "approved"
        elif action == "edit":
            output = _valid_review_codes(value or "")
            new_status, review_state = "matched", "edited"
        elif action == "no_hsn":
            output = batch["found_no_hsn_phrase"]
            new_status, review_state = "no_hsn", "resolved"
        elif action == "missing":
            output = batch["missing_phrase"]
            new_status, review_state = "missing", "resolved"
        elif action == "wrong_match":
            output = REVIEW_VALUE
            new_status, review_state = "review", "pending"
            note = (note or "") + " Marked as a wrong PDF match; select Missing or correct the batch evidence."
        else:
            raise ValueError(f"Unknown review action {action!r}")

        with self.database.transaction() as connection:
            connection.execute(
                """
                INSERT INTO review_decisions(
                    result_id,reviewer_id,old_value,new_value,action,note,created_at
                ) VALUES(?,?,?,?,?,?,?)
                """,
                (result_id, reviewer_id, result["output_value"], output, action, note, utc_now()),
            )
            connection.execute(
                """
                UPDATE results SET output_value=?,status=?,review_state=?,review_note=?,updated_at=?
                WHERE id=?
                """,
                (output, new_status, review_state, note, utc_now(), result_id),
            )
        self._refresh_counts_and_exports(result["batch_id"])
        updated = self.database.row("SELECT * FROM results WHERE id=?", (result_id,))
        assert updated is not None
        return updated
