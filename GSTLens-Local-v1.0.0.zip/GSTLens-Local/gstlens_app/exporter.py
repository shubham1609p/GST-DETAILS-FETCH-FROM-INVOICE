from __future__ import annotations

import csv
import os
import tempfile
from pathlib import Path
from typing import Any, Iterable

from openpyxl import load_workbook

from gstlens_core import WorkbookMapping


_MACRO_SUFFIXES = {".xlsm", ".xltm"}
_FORMULA_PREFIXES = ("=", "+", "-", "@")


def _keep_vba(path: Path) -> bool:
    return path.suffix.lower() in _MACRO_SUFFIXES


def _safe_excel_value(value: object) -> str:
    text = "" if value is None else str(value)
    if text.startswith(_FORMULA_PREFIXES):
        raise ValueError("Refusing to write a formula-like value from OCR/review data")
    return text


def _csv_text(value: object) -> str:
    text = "" if value is None else str(value)
    return "'" + text if text.startswith(_FORMULA_PREFIXES) else text


def export_workbook_rows(
    source: Path,
    output: Path,
    mapping: WorkbookMapping,
    results: Iterable[dict[str, Any]],
) -> Path:
    """Patch confirmed row numbers into a new workbook and verify the saved copy."""
    source = source.resolve()
    output = output.resolve()
    if source == output:
        raise ValueError("The original workbook cannot be overwritten")
    if _keep_vba(source) != _keep_vba(output):
        raise ValueError("Macro-enabled workbook output must retain its macro extension")
    materialized = tuple(results)
    workbook = load_workbook(source, keep_vba=_keep_vba(source), keep_links=True)
    try:
        if mapping.sheet_name not in workbook.sheetnames:
            raise KeyError(f"Worksheet {mapping.sheet_name!r} no longer exists")
        sheet = workbook[mapping.sheet_name]
        for result in materialized:
            row = int(result["excel_row"])
            if row <= mapping.header_row or row > sheet.max_row:
                raise ValueError(f"Invalid output row {row}")
            sheet.cell(row=row, column=mapping.hsn_column).value = _safe_excel_value(
                result.get("output_value")
            )

        output.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=".gstlens-export-", suffix=output.suffix, dir=output.parent
        )
        os.close(descriptor)
        temporary = Path(temporary_name)
        try:
            workbook.save(temporary)
            os.replace(temporary, output)
        finally:
            temporary.unlink(missing_ok=True)
    finally:
        workbook.close()

    verification = load_workbook(
        output, read_only=True, data_only=False, keep_vba=_keep_vba(output), keep_links=True
    )
    try:
        if mapping.sheet_name not in verification.sheetnames:
            raise RuntimeError("Export verification failed: worksheet is missing")
        sheet = verification[mapping.sheet_name]
        for result in materialized:
            actual = sheet.cell(
                row=int(result["excel_row"]), column=mapping.hsn_column
            ).value
            expected = _safe_excel_value(result.get("output_value"))
            if str(actual if actual is not None else "") != expected:
                raise RuntimeError(
                    f"Export verification failed at row {result['excel_row']}"
                )
    finally:
        verification.close()
    return output


def export_audit_csv(path: Path, results: Iterable[dict[str, Any]]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = (
        "excel_row",
        "invoice_number",
        "previous_value",
        "output_value",
        "status",
        "pdf_file",
        "observed_invoice_number",
        "confidence",
        "review_state",
        "review_note",
    )
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=".gstlens-audit-", suffix=".csv", dir=path.parent
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for item in results:
                writer.writerow({key: _csv_text(item.get(key)) for key in fields})
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return path

