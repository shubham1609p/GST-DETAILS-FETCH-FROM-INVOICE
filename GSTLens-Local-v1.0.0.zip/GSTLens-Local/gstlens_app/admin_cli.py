from __future__ import annotations

import argparse
import getpass
import sys

from .config import AppConfig
from .database import Database, utc_now
from .security import hash_password, verify_password


def _new_password(label: str) -> str:
    while True:
        first = getpass.getpass(label)
        second = getpass.getpass("Confirm: ")
        if first != second:
            print("Passwords do not match.")
            continue
        try:
            hash_password(first)
        except ValueError as exc:
            print(exc)
            continue
        return first


def reset_access(database: Database) -> int:
    email = input("Administrator email: ").strip().lower()
    current = getpass.getpass("Current administrator password: ")
    admin = database.user_by_email(email)
    if admin is None or admin["role"] != "admin" or not verify_password(admin["password_hash"] or "", current):
        print("Administrator verification failed.")
        return 1

    print("Leave neither password blank. Password text is not displayed or logged.")
    admin_password = _new_password("New administrator password: ")
    shared_password = _new_password("New shared operator password: ")
    with database.transaction() as connection:
        connection.execute(
            "UPDATE users SET password_hash=? WHERE id=?", (hash_password(admin_password), admin["id"])
        )
        connection.execute(
            "INSERT INTO settings(key,value,updated_at) VALUES('shared_password_hash',?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
            (hash_password(shared_password), utc_now()),
        )
        connection.execute("DELETE FROM sessions")
    database.add_audit("access.reset", user_id=int(admin["id"]))
    print("Access passwords changed. All browser sessions were signed out.")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="GSTLens Local administrator tools")
    parser.add_argument("command", choices=("reset-access",))
    args = parser.parse_args(argv)
    config = AppConfig.load()
    config.ensure_directories()
    database = Database(config.database_path, config.secret_key())
    database.initialize()
    if database.setup_required():
        print("Run first-time setup before using administrator tools.")
        return 1
    if args.command == "reset-access":
        return reset_access(database)
    return 2


if __name__ == "__main__":
    sys.exit(main())

