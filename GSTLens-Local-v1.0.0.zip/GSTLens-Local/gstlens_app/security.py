from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
from dataclasses import dataclass


try:
    from argon2 import PasswordHasher
    from argon2.exceptions import InvalidHashError, VerifyMismatchError
except ImportError:  # pragma: no cover - installer includes argon2-cffi
    PasswordHasher = None  # type: ignore[assignment]
    InvalidHashError = VerifyMismatchError = ValueError  # type: ignore[assignment]


_PBKDF2_ROUNDS = 600_000


def _pbkdf2_hash(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _PBKDF2_ROUNDS)
    return "pbkdf2_sha256${}${}${}".format(
        _PBKDF2_ROUNDS,
        base64.urlsafe_b64encode(salt).decode("ascii"),
        base64.urlsafe_b64encode(digest).decode("ascii"),
    )


def hash_password(password: str) -> str:
    if len(password) < 7:
        raise ValueError("Password must contain at least 7 characters")
    if PasswordHasher is None:
        return _pbkdf2_hash(password)
    return PasswordHasher(time_cost=3, memory_cost=65_536, parallelism=4).hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    if stored_hash.startswith("pbkdf2_sha256$"):
        try:
            _, rounds, salt_text, digest_text = stored_hash.split("$", 3)
            salt = base64.urlsafe_b64decode(salt_text.encode("ascii"))
            expected = base64.urlsafe_b64decode(digest_text.encode("ascii"))
            actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(rounds))
            return hmac.compare_digest(actual, expected)
        except (ValueError, TypeError):
            return False
    if PasswordHasher is None:
        return False
    try:
        return PasswordHasher().verify(stored_hash, password)
    except (VerifyMismatchError, InvalidHashError, ValueError):
        return False


def new_session_token() -> str:
    return secrets.token_urlsafe(48)


def session_digest(token: str, installation_secret: bytes) -> str:
    return hmac.new(installation_secret, token.encode("utf-8"), hashlib.sha256).hexdigest()


@dataclass(frozen=True, slots=True)
class AuthenticatedUser:
    id: int
    email: str
    display_name: str
    role: str

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"
