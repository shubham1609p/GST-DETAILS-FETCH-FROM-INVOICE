from __future__ import annotations

import getpass
import re
import sys

from .config import AppConfig
from .database import Database
from .security import hash_password


EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def _required(prompt: str) -> str:
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("This value is required.")


def _password(prompt: str) -> str:
    while True:
        first = getpass.getpass(prompt)
        second = getpass.getpass("Confirm: ")
        if first != second:
            print("Passwords do not match. Try again.")
            continue
        try:
            hash_password(first)
        except ValueError as exc:
            print(exc)
            continue
        return first


def main() -> int:
    config = AppConfig.load()
    config.ensure_directories()
    database = Database(config.database_path, config.secret_key())
    database.initialize()

    if not database.setup_required():
        print("GSTLens Local is already configured.")
        return 0

    print("\nGSTLens Local first-time setup")
    print("Credentials are stored as salted hashes on this computer.\n")
    name = _required("Administrator name: ")
    while True:
        email = _required("Administrator email: ").lower()
        if EMAIL_PATTERN.match(email):
            break
        print("Enter a valid email address.")
    admin_password = _password("Administrator password: ")
    print("\nOperators will sign in with their own name and email plus one shared access password.")
    shared_password = _password("Shared operator password: ")

    database.create_initial_setup(
        email=email,
        display_name=name,
        admin_password_hash=hash_password(admin_password),
        shared_password_hash=hash_password(shared_password),
    )
    print("\nSetup complete. You can now start GSTLens Local.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

