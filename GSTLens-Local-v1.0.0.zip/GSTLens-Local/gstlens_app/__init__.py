"""GSTLens Local application package."""

__version__ = "1.0.0"

