from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Hashable

from gstlens_core import (
    BoundingBox,
    DocumentFields,
    InvoiceMatchStatus,
    OCRPage,
    OCRToken,
)
from gstlens_ocr import DocumentOCRResult


def to_core_pages(result: DocumentOCRResult) -> tuple[OCRPage, ...]:
    """Adapt OCR-runtime polygons to the deterministic core's box types."""
    pages: list[OCRPage] = []
    for source_page in result.pages:
        tokens: list[OCRToken] = []
        for source_token in source_page.tokens:
            box = source_token.bbox
            if box is None:
                continue
            tokens.append(
                OCRToken(
                    source_token.text,
                    float(source_token.confidence),
                    BoundingBox(*box),
                )
            )
        pages.append(
            OCRPage(
                source_page.page_index + 1,
                float(source_page.width),
                float(source_page.height),
                tuple(tokens),
            )
        )
    return tuple(pages)


@dataclass(frozen=True, slots=True)
class ResolvedDocument:
    reference_ids: tuple[Hashable, ...]
    observed_invoice_number: str | None
    codes: tuple[str, ...]
    match_state: str
    confidence: float
    requires_review: bool
    reasons: tuple[str, ...]
    evidence: dict[str, Any]

    @property
    def reference_id(self) -> Hashable | None:
        return self.reference_ids[0] if len(self.reference_ids) == 1 else None


def _field_evidence(fields: DocumentFields[Any], pass_name: str) -> dict[str, Any]:
    return {
        "pass": pass_name,
        "invoice": {
            "status": fields.invoice.status.value,
            "observed": fields.invoice.observed_invoice_number,
            "confidence": round(fields.invoice.confidence, 6),
            "requires_review": fields.invoice.requires_review,
            "reasons": list(fields.invoice.review_reasons),
            "reference_ids": list(fields.invoice.reference_ids),
            "candidates": [
                {
                    "value": item.observed_value,
                    "confidence": round(item.confidence, 6),
                    "page": item.page_number,
                    "box": [item.box.x0, item.box.y0, item.box.x1, item.box.y1],
                    "context": item.context,
                    "match_status": item.match.status.value,
                    "reference_ids": list(item.match.reference_ids),
                }
                for item in fields.invoice.candidates
            ],
        },
        "hsn_sac": {
            "codes": list(fields.hsn_sac.codes),
            "label_found": fields.hsn_sac.label_found,
            "requires_review": fields.hsn_sac.requires_review,
            "reasons": list(fields.hsn_sac.review_reasons),
            "candidates": [
                {
                    "code": item.code,
                    "confidence": round(item.confidence, 6),
                    "page": item.page_number,
                    "box": [item.box.x0, item.box.y0, item.box.x1, item.box.y1],
                    "context": item.context,
                    "source_text": item.source_text,
                }
                for item in fields.hsn_sac.candidates
            ],
        },
    }


def resolve_document_fields(
    primary: DocumentFields[Any],
    fallback: DocumentFields[Any] | None = None,
) -> ResolvedDocument:
    """Resolve primary and handwriting passes without trusting fallback-only text.

    The handwriting pass can confirm a primary reading. A fallback-only or
    disagreeing reading remains a proposed value for human review.
    """

    evidence: dict[str, Any] = {"passes": [_field_evidence(primary, "primary-ppocrv6")]}
    if fallback is not None:
        evidence["passes"].append(_field_evidence(fallback, "handwriting-ppocrv5"))

    reasons: list[str] = []
    primary_refs = tuple(primary.invoice.reference_ids)
    fallback_refs = tuple(fallback.invoice.reference_ids) if fallback else ()
    reference_ids: tuple[Hashable, ...]
    observed = primary.invoice.observed_invoice_number
    invoice_confidence = primary.invoice.confidence
    invoice_review = primary.invoice.requires_review

    if primary.invoice.status is InvoiceMatchStatus.MATCHED and len(primary_refs) == 1:
        reference_ids = primary_refs
        reasons.extend(primary.invoice.review_reasons)
        if fallback is not None and fallback.invoice.status is InvoiceMatchStatus.MATCHED:
            if fallback_refs != primary_refs:
                invoice_review = True
                reasons.append("Printed and handwriting OCR passes disagree on the invoice number")
            else:
                invoice_confidence = max(invoice_confidence, fallback.invoice.confidence)
    elif fallback is not None and fallback.invoice.status is InvoiceMatchStatus.MATCHED and len(fallback_refs) == 1:
        reference_ids = fallback_refs
        observed = fallback.invoice.observed_invoice_number
        invoice_confidence = fallback.invoice.confidence
        invoice_review = True
        reasons.append("Invoice number was found only by the handwriting pass")
    else:
        reference_ids = tuple(dict.fromkeys((*primary_refs, *fallback_refs)))
        invoice_review = bool(reference_ids) or primary.invoice.status is InvoiceMatchStatus.AMBIGUOUS
        if invoice_review:
            reasons.append("Invoice number is ambiguous")

    primary_codes = tuple(primary.hsn_sac.codes)
    fallback_codes = tuple(fallback.hsn_sac.codes) if fallback else ()
    codes = primary_codes
    hsn_review = primary.hsn_sac.requires_review
    reasons.extend(primary.hsn_sac.review_reasons)

    if fallback is not None:
        if primary_codes and fallback_codes:
            if primary_codes == fallback_codes:
                # Independent agreement clears a confidence-only warning, but not a conflict warning.
                non_conflict_reasons = [
                    reason
                    for reason in primary.hsn_sac.review_reasons
                    if "low OCR confidence" not in reason
                ]
                hsn_review = bool(non_conflict_reasons or fallback.hsn_sac.requires_review)
                reasons = [reason for reason in reasons if "low OCR confidence" not in reason]
                reasons.extend(non_conflict_reasons)
            else:
                hsn_review = True
                reasons.append("Printed and handwriting OCR passes disagree on HSN/SAC")
        elif fallback_codes and not primary_codes:
            codes = fallback_codes
            hsn_review = True
            reasons.append("HSN/SAC was found only by the handwriting pass")

    match_state = "not_found"
    if len(reference_ids) > 1:
        match_state = "ambiguous"
    elif len(reference_ids) == 1:
        match_state = "matched"

    candidate_confidences = [
        item.confidence
        for item in primary.hsn_sac.candidates
        if item.code in codes
    ]
    if fallback is not None and codes == fallback_codes:
        candidate_confidences.extend(
            item.confidence for item in fallback.hsn_sac.candidates if item.code in codes
        )
    code_confidence = min(candidate_confidences) if candidate_confidences else invoice_confidence
    confidence = min(invoice_confidence, code_confidence) if reference_ids else invoice_confidence
    requires_review = invoice_review or hsn_review or len(reference_ids) > 1
    return ResolvedDocument(
        reference_ids=reference_ids,
        observed_invoice_number=observed,
        codes=codes,
        match_state=match_state,
        confidence=float(confidence),
        requires_review=requires_review,
        reasons=tuple(dict.fromkeys(reason for reason in reasons if reason)),
        evidence=evidence,
    )

