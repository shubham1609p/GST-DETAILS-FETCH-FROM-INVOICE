from __future__ import annotations

import csv
import io
import json
import math
import re
import uuid
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Query, Request, status
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw
from starlette.datastructures import UploadFile

from gstlens_core import WorkbookMapping, detect_workbook_mappings, read_invoice_rows
from gstlens_ocr import PDFDocumentReader

from .api_models import BatchActionPayload, MappingPayload, ReviewPayload
from .auth import AuthService
from .config import AppConfig
from .database import Database, utc_now
from .file_io import ensure_within, safe_filename, save_upload, unique_path
from .processor import BatchProcessor
from .reporting import batch_insights, dashboard, list_batches, public_batch
from .security import AuthenticatedUser


def _http_error(exc: Exception) -> HTTPException:
    if isinstance(exc, KeyError):
        return HTTPException(status_code=404, detail="Item not found")
    if isinstance(exc, (ValueError, RuntimeError)):
        return HTTPException(status_code=400, detail=str(exc))
    return HTTPException(status_code=500, detail="The local operation failed")


def _mapping_dict(mapping: WorkbookMapping) -> dict[str, Any]:
    return {
        "sheet_name": mapping.sheet_name,
        "sheet": mapping.sheet_name,
        "header_row": mapping.header_row,
        "invoice_col": mapping.invoice_column,
        "hsn_col": mapping.hsn_column,
        "invoice_column": get_column_letter(mapping.invoice_column),
        "hsn_column": get_column_letter(mapping.hsn_column),
        "confidence": 0.97,
    }


def _workbook_preview(path: Path, sheet_name: str, header_row: int) -> dict[str, Any]:
    keep_vba = path.suffix.lower() == ".xlsm"
    workbook = load_workbook(path, read_only=True, data_only=False, keep_vba=keep_vba, keep_links=True)
    try:
        if sheet_name not in workbook.sheetnames:
            raise ValueError(f"Worksheet {sheet_name!r} was not found")
        sheet = workbook[sheet_name]
        # Always expose at least A:G so a customer can create/select the required
        # destination even when the uploaded sheet's HSN/SAC column is currently blank.
        max_column = min(max(7, sheet.max_column), 80)
        columns = []
        for column in range(1, max_column + 1):
            value = sheet.cell(row=header_row, column=column).value
            letter = get_column_letter(column)
            columns.append({"key": letter, "letter": letter, "label": str(value or "(blank)")})
        preview: list[list[str]] = []
        for row_number in range(header_row, min(sheet.max_row, header_row + 7) + 1):
            preview.append(
                [str(sheet.cell(row=row_number, column=column).value or "") for column in range(1, max_column + 1)]
            )
        return {"sheets": list(workbook.sheetnames), "columns": columns, "preview": preview}
    finally:
        workbook.close()


def _owns_batch(database: Database, batch_id: str, user: AuthenticatedUser) -> dict[str, Any]:
    row = database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
    if row is None:
        raise HTTPException(status_code=404, detail="Batch not found")
    if not user.is_admin and int(row["owner_id"]) != user.id:
        raise HTTPException(status_code=403, detail="This batch belongs to another user")
    return row


def _result_status(value: str) -> str:
    return {"review": "needs_review", "missing": "invoice_missing", "no_hsn": "hsn_missing"}.get(value, value)


def _safe_csv_cell(value: object) -> object:
    if isinstance(value, str) and value.startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _public_result(row: dict[str, Any]) -> dict[str, Any]:
    try:
        evidence = json.loads(row.get("evidence_json") or "{}")
    except (TypeError, json.JSONDecodeError):
        evidence = {}
    proposed = evidence.get("proposed_codes") or []
    output = row.get("output_value") or ""
    codes = proposed if proposed else (
        [part.strip() for part in output.split(",") if part.strip()]
        if row.get("status") == "matched"
        else []
    )
    reasons = evidence.get("reasons") or []
    return {
        **{key: value for key, value in row.items() if key not in {"evidence_json"}},
        "status": _result_status(row.get("status") or ""),
        "hsn_codes": codes,
        "pdf_filename": row.get("pdf_file"),
        "pdf_invoice_number": row.get("observed_invoice_number"),
        "reason": "; ".join(str(item) for item in reasons),
        "review_reason": "; ".join(str(item) for item in reasons),
        "evidence_url": f"/api/results/{row['id']}/evidence",
        "pdf_url": f"/api/results/{row['id']}/pdf",
    }


def create_app(config: AppConfig | None = None) -> FastAPI:
    config = config or AppConfig.load()
    config.ensure_directories()
    database = Database(config.database_path, config.secret_key())
    database.initialize()
    auth = AuthService(database, config)
    processor = BatchProcessor(database, config)

    app = FastAPI(
        title="GSTLens Local",
        version="1.0.0",
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
    )
    app.state.config = config
    app.state.database = database
    app.state.processor = processor
    app.include_router(auth.router())

    @app.middleware("http")
    async def local_security_headers(request: Request, call_next: Any) -> Response:
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store" if request.url.path.startswith("/api/") else "no-cache"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'"
        )
        return response

    @app.get("/api/health")
    async def health() -> dict[str, Any]:
        required_models = (
            "PP-OCRv6_medium_det",
            "PP-OCRv6_medium_rec",
            "en_PP-OCRv5_mobile_rec",
        )
        missing = [name for name in required_models if not (config.model_dir / name).is_dir()]
        return {
            "status": "degraded" if missing else "ok",
            "ocr_ready": not missing,
            "engine_label": "Local printed + handwriting OCR" if not missing else "OCR models need setup",
            "missing_models": missing,
            "offline_processing": True,
        }

    @app.get("/api/dashboard")
    async def dashboard_route(
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        payload = dashboard(database, user)
        totals = payload.get("totals", {})
        payload["summary"] = {
            **totals,
            "invoices_processed": totals.get("total_rows", 0),
            "review_count": totals.get("review", 0),
            "completed_batches": totals.get("batches", 0),
        }
        payload["tip"] = {
            "title": "Review evidence, not guesses",
            "text": "Uncertain handwriting is held for a quick visual check before the Excel output is final.",
        }
        return payload

    @app.get("/api/batches")
    async def batches_route(
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        return {"items": list_batches(database, user)}

    @app.post("/api/batches", status_code=201)
    async def create_batch_route(
        request: Request,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        form = await request.form(max_files=config.max_pdf_count + 1, max_fields=100)
        workbook_upload = form.get("workbook")
        invoice_uploads = [value for key, value in form.multi_items() if key == "invoices"]
        if not isinstance(workbook_upload, UploadFile):
            raise HTTPException(status_code=400, detail="Upload one Excel workbook")
        if not invoice_uploads or any(not isinstance(item, UploadFile) for item in invoice_uploads):
            raise HTTPException(status_code=400, detail="Upload a ZIP or one or more invoice PDFs")
        if len(invoice_uploads) > config.max_pdf_count:
            raise HTTPException(status_code=400, detail="Too many direct invoice uploads")

        workbook_name = safe_filename(workbook_upload.filename or "workbook.xlsx", "workbook.xlsx")
        if Path(workbook_name).suffix.lower() not in {".xlsx", ".xlsm"}:
            raise HTTPException(status_code=400, detail="Workbook must be .xlsx or .xlsm")
        batch_id = uuid.uuid4().hex
        batch_dir = config.batches_dir / batch_id
        upload_dir = batch_dir / "uploads"
        extract_dir = batch_dir / "extracted"
        upload_dir.mkdir(parents=True, exist_ok=False)
        workbook_path = upload_dir / workbook_name
        label = str(form.get("label") or Path(workbook_name).stem).strip()[:160]
        missing_phrase = str(form.get("missing_label") or "Invoice Missing").strip()[:120]
        no_hsn_phrase = str(
            form.get("hsn_missing_label") or "Invoice Found but HSN not mentioned"
        ).strip()[:120]
        if not label or not missing_phrase or not no_hsn_phrase:
            raise HTTPException(status_code=400, detail="Batch label and status phrases are required")
        if any(value.startswith(("=", "+", "-", "@")) for value in (missing_phrase, no_hsn_phrase)):
            raise HTTPException(status_code=400, detail="Status phrases cannot be Excel formulas")

        database.execute(
            """
            INSERT INTO batches(
                id,label,status,owner_id,workbook_original_name,workbook_path,
                missing_phrase,found_no_hsn_phrase,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?)
            """,
            (
                batch_id,
                label,
                "uploading",
                user.id,
                workbook_name,
                str(workbook_path),
                missing_phrase,
                no_hsn_phrase,
                utc_now(),
            ),
        )
        try:
            await save_upload(workbook_upload, workbook_path, config.max_workbook_bytes)
            for index, upload in enumerate(invoice_uploads, 1):
                name = safe_filename(upload.filename or f"invoice-{index}.pdf", f"invoice-{index}.pdf")
                suffix = Path(name).suffix.lower()
                if suffix not in {".pdf", ".zip"}:
                    raise ValueError(f"Only PDF and ZIP invoice uploads are allowed: {name}")
                limit = config.max_archive_bytes if suffix == ".zip" else config.max_single_pdf_bytes
                await save_upload(upload, unique_path(upload_dir, name), limit)
            mappings = detect_workbook_mappings(workbook_path)
            if mappings:
                preferred = next((item for item in mappings if item.hsn_column == 7), mappings[0])
            else:
                workbook = load_workbook(workbook_path, read_only=True, keep_vba=workbook_path.suffix.lower() == ".xlsm")
                try:
                    sheet = workbook.worksheets[0]
                    preferred = WorkbookMapping(sheet.title, 1, 1, 7)
                finally:
                    workbook.close()
            processor.register_documents(batch_id, upload_dir, extract_dir)
            preview = _workbook_preview(workbook_path, preferred.sheet_name, preferred.header_row)
            database.execute(
                """
                UPDATE batches SET status='awaiting_mapping',sheet_name=?,header_row=?,invoice_col=?,hsn_col=?
                WHERE id=?
                """,
                (
                    preferred.sheet_name,
                    preferred.header_row,
                    preferred.invoice_column,
                    preferred.hsn_column,
                    batch_id,
                ),
            )
            database.add_audit(
                "batch.created",
                user_id=user.id,
                batch_id=batch_id,
                detail={"workbook": workbook_name, "documents": len(invoice_uploads)},
            )
        except Exception as exc:
            database.execute(
                "UPDATE batches SET status='failed',error_message=?,completed_at=? WHERE id=?",
                (str(exc)[:2000], utc_now(), batch_id),
            )
            raise _http_error(exc) from exc

        row = database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
        assert row is not None
        public = public_batch(row)
        public["mapping"] = {**_mapping_dict(preferred), **preview}
        public["workbook"] = {"sheets": preview["sheets"], "preview": preview["preview"]}
        return {"batch": public}

    @app.get("/api/batches/{batch_id}/mapping-preview")
    async def mapping_preview_route(
        batch_id: str,
        sheet: str,
        header_row: int = Query(ge=1, le=500),
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        batch = _owns_batch(database, batch_id, user)
        workbook_path = Path(batch["workbook_path"])
        preview = _workbook_preview(workbook_path, sheet, header_row)
        detected = next(
            (
                item
                for item in detect_workbook_mappings(workbook_path)
                if item.sheet_name == sheet and item.header_row == header_row
            ),
            None,
        )
        if detected is not None:
            preview.update(_mapping_dict(detected))
        return preview

    @app.patch("/api/batches/{batch_id}/mapping")
    async def save_mapping_route(
        batch_id: str,
        payload: MappingPayload,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        batch = _owns_batch(database, batch_id, user)
        mapping = WorkbookMapping(payload.sheet_name, payload.header_row, payload.invoice_col, payload.hsn_col)
        try:
            rows = read_invoice_rows(Path(batch["workbook_path"]), mapping)
        except Exception as exc:
            raise _http_error(exc) from exc
        if not rows:
            raise HTTPException(status_code=400, detail="No invoice numbers were found below that header")
        database.execute(
            """
            UPDATE batches SET sheet_name=?,header_row=?,invoice_col=?,hsn_col=?,missing_phrase=?,
                found_no_hsn_phrase=?,total_rows=?,status='ready',error_message=NULL WHERE id=?
            """,
            (
                payload.sheet_name,
                payload.header_row,
                payload.invoice_col,
                payload.hsn_col,
                payload.missing_phrase,
                payload.found_no_hsn_phrase,
                len(rows),
                batch_id,
            ),
        )
        database.add_audit(
            "batch.mapping_confirmed",
            user_id=user.id,
            batch_id=batch_id,
            detail=payload.model_dump(),
        )
        return {"ok": True, "invoice_rows": len(rows)}

    @app.post("/api/batches/{batch_id}/action")
    async def batch_action_route(
        batch_id: str,
        payload: BatchActionPayload,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        _owns_batch(database, batch_id, user)
        try:
            processor.action(batch_id, payload.action)
        except Exception as exc:
            raise _http_error(exc) from exc
        database.add_audit(
            f"batch.{payload.action}", user_id=user.id, batch_id=batch_id
        )
        return {"ok": True, "action": payload.action}

    @app.get("/api/batches/{batch_id}")
    async def batch_detail_route(
        batch_id: str,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        batch = _owns_batch(database, batch_id, user)
        current = database.row(
            "SELECT file_name,page_count,status FROM documents WHERE batch_id=? AND status='processing' ORDER BY id LIMIT 1",
            (batch_id,),
        )
        pages = database.row(
            "SELECT COALESCE(SUM(page_count),0) AS pages FROM documents WHERE batch_id=?",
            (batch_id,),
        ) or {}
        activities = database.rows(
            """
            SELECT file_name AS title,
                   CASE status WHEN 'done' THEN 'matched' WHEN 'review' THEN 'review' ELSE status END AS kind,
                   COALESCE(reason,error_message,status) AS detail,
                   processed_at AS created_at
            FROM documents WHERE batch_id=? AND status NOT IN ('queued','processing')
            ORDER BY id DESC LIMIT 12
            """,
            (batch_id,),
        )
        item = public_batch(batch)
        processed = int(batch.get("processed_docs") or 0)
        total = int(batch.get("total_docs") or 0)
        percent = processed * 100 / total if total else 0
        item["processed_count"] = processed
        item["progress"] = {
            "completed": processed,
            "processed": processed,
            "total": total,
            "percent": percent,
            "current_file": current.get("file_name") if current else None,
            "pages_read": int(pages.get("pages") or 0),
            "matched": item.get("matched_count", 0),
            "needs_review": item.get("review_count", 0),
            "missing": item.get("missing_count", 0),
            "activity": activities,
            "stage_label": "Review uncertain evidence" if batch["status"] == "needs_review" else "Local OCR and exact matching",
        }
        return {"batch": item}

    @app.get("/api/batches/{batch_id}/results")
    async def batch_results_route(
        batch_id: str,
        page: int = Query(1, ge=1),
        page_size: int = Query(25, ge=1, le=200),
        q: str = Query("", max_length=120),
        result_status: str = Query("all", alias="status", max_length=40),
        confidence: str = Query("all", max_length=20),
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        _owns_batch(database, batch_id, user)
        clauses = ["r.batch_id=?"]
        parameters: list[Any] = [batch_id]
        if q.strip():
            clauses.append("(r.invoice_number LIKE ? OR d.file_name LIKE ? OR r.output_value LIKE ?)")
            term = f"%{q.strip()}%"
            parameters.extend((term, term, term))
        status_map = {"needs_review": "review", "invoice_missing": "missing", "hsn_missing": "no_hsn"}
        if result_status != "all":
            clauses.append("r.status=?")
            parameters.append(status_map.get(result_status, result_status))
        if confidence == "low":
            clauses.append("COALESCE(r.confidence,0)<0.70")
        elif confidence == "medium":
            clauses.append("COALESCE(r.confidence,0)>=0.70 AND COALESCE(r.confidence,0)<0.90")
        elif confidence == "high":
            clauses.append("COALESCE(r.confidence,0)>=0.90")
        where = " AND ".join(clauses)
        total_row = database.row(
            f"SELECT COUNT(*) AS count FROM results r LEFT JOIN documents d ON d.id=r.document_id WHERE {where}",
            tuple(parameters),
        ) or {}
        total = int(total_row.get("count") or 0)
        offset = (page - 1) * page_size
        rows = database.rows(
            f"""
            SELECT r.*,d.file_name AS pdf_file,d.invoice_number AS observed_invoice_number
            FROM results r LEFT JOIN documents d ON d.id=r.document_id
            WHERE {where} ORDER BY r.excel_row LIMIT ? OFFSET ?
            """,
            tuple((*parameters, page_size, offset)),
        )
        summary_row = database.row(
            """
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN status='review' THEN 1 ELSE 0 END) AS needs_review,
                   SUM(CASE WHEN status='missing' THEN 1 ELSE 0 END) AS invoice_missing,
                   SUM(CASE WHEN review_state IN ('approved','edited','resolved') THEN 1 ELSE 0 END) AS approved
            FROM results WHERE batch_id=?
            """,
            (batch_id,),
        ) or {}
        return {
            "items": [_public_result(row) for row in rows],
            "summary": summary_row,
            "page": page,
            "pages": max(1, math.ceil(total / page_size)),
            "total": total,
        }

    @app.post("/api/results/{result_id}/review")
    async def review_result_route(
        result_id: int,
        payload: ReviewPayload,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        result = database.row("SELECT * FROM results WHERE id=?", (result_id,))
        if result is None:
            raise HTTPException(status_code=404, detail="Result not found")
        _owns_batch(database, result["batch_id"], user)
        try:
            updated = processor.apply_review(
                result_id,
                reviewer_id=user.id,
                action=payload.action,
                value=payload.value,
                note=payload.note,
            )
        except Exception as exc:
            raise _http_error(exc) from exc
        database.add_audit(
            "result.reviewed",
            user_id=user.id,
            batch_id=result["batch_id"],
            detail={"result_id": result_id, "action": payload.action},
        )
        document = database.row("SELECT file_name,invoice_number FROM documents WHERE id=?", (updated.get("document_id"),)) if updated.get("document_id") else None
        updated["pdf_file"] = document.get("file_name") if document else None
        updated["observed_invoice_number"] = document.get("invoice_number") if document else None
        return _public_result(updated)

    def result_and_document(result_id: int, user: AuthenticatedUser) -> tuple[dict[str, Any], dict[str, Any]]:
        result = database.row("SELECT * FROM results WHERE id=?", (result_id,))
        if result is None or not result.get("document_id"):
            raise HTTPException(status_code=404, detail="No invoice evidence is attached to this row")
        _owns_batch(database, result["batch_id"], user)
        document = database.row("SELECT * FROM documents WHERE id=?", (result["document_id"],))
        if document is None:
            raise HTTPException(status_code=404, detail="Invoice evidence file was not found")
        return result, document

    @app.get("/api/results/{result_id}/pdf")
    async def result_pdf_route(
        result_id: int,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> FileResponse:
        _result, document = result_and_document(result_id, user)
        path = ensure_within(Path(document["path"]), config.batches_dir)
        if not path.is_file():
            raise HTTPException(status_code=404, detail="Invoice PDF is no longer available")
        return FileResponse(path, media_type="application/pdf", filename=document["file_name"])

    @app.get("/api/results/{result_id}/evidence")
    async def result_evidence_route(
        result_id: int,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> FileResponse:
        result, document = result_and_document(result_id, user)
        cache_dir = config.evidence_dir / result["batch_id"]
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = cache_dir / f"result-{result_id}.png"
        if not cache_path.exists():
            try:
                result_evidence = json.loads(result.get("evidence_json") or "{}")
                candidate_evidence = result_evidence.get("candidate_evidence") or {}
                passes = candidate_evidence.get("passes") or []
                boxes: list[tuple[str, int, list[float]]] = []
                for pass_item in passes[:1]:
                    for candidate in pass_item.get("invoice", {}).get("candidates", []):
                        boxes.append(("invoice", int(candidate.get("page") or 1), candidate.get("box") or []))
                    for candidate in pass_item.get("hsn_sac", {}).get("candidates", []):
                        boxes.append(("hsn", int(candidate.get("page") or 1), candidate.get("box") or []))
                page_number = next((page for kind, page, _box in boxes if kind == "hsn"), boxes[0][1] if boxes else 1)
                with PDFDocumentReader(Path(document["path"])) as pdf:
                    rendered = pdf.render_page(max(0, min(pdf.page_count - 1, page_number - 1)), dpi=160)
                image = Image.fromarray(rendered.image)
                draw = ImageDraw.Draw(image)
                page_meta = next(
                    (item for item in candidate_evidence.get("pages", []) if int(item.get("page") or 0) == page_number),
                    None,
                )
                source_width = float(page_meta.get("width") or image.width) if page_meta else image.width
                source_height = float(page_meta.get("height") or image.height) if page_meta else image.height
                sx, sy = image.width / source_width, image.height / source_height
                for kind, candidate_page, box in boxes:
                    if candidate_page != page_number or len(box) != 4:
                        continue
                    scaled = [box[0] * sx, box[1] * sy, box[2] * sx, box[3] * sy]
                    color = "#e87b39" if kind == "hsn" else "#118b84"
                    draw.rectangle(scaled, outline=color, width=max(3, image.width // 500))
                image.save(cache_path, format="PNG", optimize=True)
            except Exception as exc:
                raise HTTPException(status_code=500, detail=f"Could not render evidence: {exc}") from exc
        return FileResponse(cache_path, media_type="image/png")

    @app.get("/api/batches/{batch_id}/insights")
    async def insights_route(
        batch_id: str,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> dict[str, Any]:
        batch = _owns_batch(database, batch_id, user)
        payload = batch_insights(database, batch_id)
        total = int(batch.get("total_rows") or 0)
        matched = int(batch.get("matched_count") or 0)
        payload["summary"] = {
            "total": total,
            "resolved": matched,
            "matched": matched,
            "needs_review": int(batch.get("review_count") or 0),
            "missing": int(batch.get("missing_count") or 0) + int(batch.get("no_hsn_count") or 0),
            "review_rate": int(batch.get("review_count") or 0) / total if total else 0,
            "unique_codes": len(payload.get("top_codes", [])),
            "suppliers": 0,
        }
        payload["suggestions"] = [
            {
                "title": card["title"],
                "text": card["detail"],
                "icon": "alert" if card["severity"] == "danger" else "review" if card["severity"] == "warning" else "spark",
            }
            for card in payload.get("cards", [])
            if card.get("detail")
        ]
        return payload

    @app.get("/api/batches/{batch_id}/download/{kind}")
    async def download_route(
        batch_id: str,
        kind: str,
        user: AuthenticatedUser = Depends(auth.current_user),
    ) -> FileResponse:
        batch = _owns_batch(database, batch_id, user)
        if kind == "output.xlsx":
            stored = batch.get("output_path")
            media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        elif kind == "audit.csv":
            stored = batch.get("audit_path")
            media_type = "text/csv"
        else:
            raise HTTPException(status_code=404, detail="Download type not found")
        if not stored:
            raise HTTPException(status_code=409, detail="The requested export is not ready")
        path = ensure_within(Path(stored), config.batches_dir)
        if not path.is_file():
            raise HTTPException(status_code=404, detail="Export file is no longer available")
        return FileResponse(path, media_type=media_type, filename=path.name)

    @app.get("/api/admin/logins")
    async def admin_logins_route(
        days: str = Query("30", max_length=10),
        q: str = Query("", max_length=120),
        user: AuthenticatedUser = Depends(auth.require_admin),
    ) -> dict[str, Any]:
        clauses = ["1=1"]
        parameters: list[Any] = []
        if days != "all":
            try:
                day_count = max(1, min(3650, int(days)))
            except ValueError as exc:
                raise HTTPException(status_code=400, detail="Invalid login history period") from exc
            cutoff = (datetime.now(UTC) - timedelta(days=day_count)).isoformat(timespec="seconds")
            clauses.append("le.created_at>=?")
            parameters.append(cutoff)
        if q.strip():
            clauses.append("(le.email LIKE ? OR le.display_name LIKE ?)")
            term = f"%{q.strip()}%"
            parameters.extend((term, term))
        where = " AND ".join(clauses)
        items = database.rows(
            f"""
            SELECT le.id,le.email,COALESCE(le.display_name,u.display_name) AS name,
                   COALESCE(u.role,'unknown') AS role,le.success,le.reason,le.created_at
            FROM login_events le LEFT JOIN users u ON u.id=le.user_id
            WHERE {where} ORDER BY le.created_at DESC LIMIT 1000
            """,
            tuple(parameters),
        )
        summary = {
            "sign_ins": len(items),
            "unique_users": len({item["email"].lower() for item in items if item.get("email")}),
            "last_login": items[0]["created_at"] if items else None,
            "failed_attempts": sum(not bool(item["success"]) for item in items),
        }
        return {"items": items, "summary": summary}

    @app.get("/api/admin/logins/export")
    @app.get("/api/admin/logins/export.csv")
    async def admin_logins_export_route(
        user: AuthenticatedUser = Depends(auth.require_admin),
    ) -> Response:
        items = database.rows(
            """
            SELECT le.email,COALESCE(le.display_name,u.display_name) AS name,
                   COALESCE(u.role,'unknown') AS role,le.success,le.reason,le.created_at
            FROM login_events le LEFT JOIN users u ON u.id=le.user_id
            ORDER BY le.created_at DESC
            """
        )
        output = io.StringIO()
        writer = csv.DictWriter(
            output, fieldnames=("email", "name", "role", "success", "reason", "created_at")
        )
        writer.writeheader()
        writer.writerows(
            {key: _safe_csv_cell(value) for key, value in item.items()} for item in items
        )
        return Response(
            content="\ufeff" + output.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=GSTLens-login-history.csv"},
        )

    @app.get("/")
    async def index() -> FileResponse:
        return FileResponse(config.web_dir / "index.html", media_type="text/html")

    app.mount("/static", StaticFiles(directory=config.web_dir), name="static")
    return app
