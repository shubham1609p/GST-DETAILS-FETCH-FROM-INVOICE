from __future__ import annotations

import importlib
import platform
import sys

from .config import AppConfig
from .database import Database
from .model_manager import verify_models


REQUIRED_MODULES = (
    "fastapi",
    "uvicorn",
    "multipart",
    "openpyxl",
    "argon2",
    "pypdfium2",
    "PIL",
    "numpy",
    "cv2",
    "paddle",
    "paddleocr",
)


def main() -> int:
    print(f"Python: {platform.python_version()} ({platform.architecture()[0]})")
    failures: list[str] = []
    for module in REQUIRED_MODULES:
        try:
            imported = importlib.import_module(module)
            version = getattr(imported, "__version__", "installed")
            print(f"[OK] {module}: {version}")
        except Exception as exc:
            failures.append(module)
            print(f"[FAIL] {module}: {exc}")

    config = AppConfig.load()
    config.ensure_directories()
    try:
        database = Database(config.database_path, config.secret_key())
        database.initialize()
        print(f"[OK] Local database: {config.database_path}")
    except Exception as exc:
        failures.append("database")
        print(f"[FAIL] Local database: {exc}")

    if not verify_models(config):
        failures.append("models")

    if failures:
        print("\nChecks failed: " + ", ".join(failures))
        return 1
    print("\nGSTLens Local is ready.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

