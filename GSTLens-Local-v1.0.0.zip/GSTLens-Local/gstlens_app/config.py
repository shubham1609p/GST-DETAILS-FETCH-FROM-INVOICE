from __future__ import annotations

import os
import secrets
from dataclasses import dataclass
from pathlib import Path


def _default_data_dir() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return root / "GSTLens"
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "gstlens"


def _int_env(name: str, default: int) -> int:
    value = os.environ.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc


@dataclass(frozen=True, slots=True)
class AppConfig:
    data_dir: Path
    database_path: Path
    batches_dir: Path
    model_dir: Path
    evidence_dir: Path
    web_dir: Path
    host: str = "127.0.0.1"
    port: int = 8765
    session_hours: int = 12
    max_workbook_bytes: int = 100 * 1024 * 1024
    max_single_pdf_bytes: int = 250 * 1024 * 1024
    max_archive_bytes: int = 5 * 1024 * 1024 * 1024
    max_archive_unpacked_bytes: int = 20 * 1024 * 1024 * 1024
    max_pdf_count: int = 5000
    render_dpi: int = 300
    auto_accept_confidence: float = 0.88
    device: str = "cpu"

    @classmethod
    def load(cls) -> "AppConfig":
        project_root = Path(__file__).resolve().parent.parent
        data_dir = Path(os.environ.get("GSTLENS_DATA_DIR", _default_data_dir())).expanduser().resolve()
        return cls(
            data_dir=data_dir,
            database_path=data_dir / "gstlens.sqlite3",
            batches_dir=data_dir / "batches",
            model_dir=Path(os.environ.get("GSTLENS_MODEL_DIR", data_dir / "models")).expanduser().resolve(),
            evidence_dir=data_dir / "evidence",
            web_dir=project_root / "web",
            host=os.environ.get("GSTLENS_HOST", "127.0.0.1"),
            port=_int_env("GSTLENS_PORT", 8765),
            session_hours=_int_env("GSTLENS_SESSION_HOURS", 12),
            render_dpi=_int_env("GSTLENS_RENDER_DPI", 300),
            auto_accept_confidence=float(os.environ.get("GSTLENS_AUTO_ACCEPT_CONFIDENCE", "0.88")),
            device=os.environ.get("GSTLENS_DEVICE", "cpu"),
        )

    def ensure_directories(self) -> None:
        for path in (self.data_dir, self.batches_dir, self.model_dir, self.evidence_dir):
            path.mkdir(parents=True, exist_ok=True)

    def secret_key(self) -> bytes:
        """Return an installation-local secret, creating it with restrictive permissions."""
        path = self.data_dir / "secret.key"
        if not path.exists():
            path.write_bytes(secrets.token_bytes(32))
            try:
                path.chmod(0o600)
            except OSError:
                pass
        key = path.read_bytes()
        if len(key) < 32:
            raise RuntimeError("GSTLens secret.key is invalid")
        return key

