from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Iterator

from .security import AuthenticatedUser, session_digest


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


class Database:
    """Small SQLite repository. Each call uses its own thread-safe connection."""

    def __init__(self, path: Path, installation_secret: bytes) -> None:
        self.path = path
        self.installation_secret = installation_secret
        self._schema_lock = threading.Lock()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        connection = self.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise
        finally:
            connection.close()

    def initialize(self) -> None:
        with self._schema_lock, self.connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    display_name TEXT NOT NULL,
                    password_hash TEXT,
                    role TEXT NOT NULL CHECK(role IN ('admin','operator','reviewer')),
                    active INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    last_login_at TEXT
                );

                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    token_hash TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS login_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                    email TEXT NOT NULL,
                    display_name TEXT,
                    success INTEGER NOT NULL,
                    reason TEXT,
                    ip_address TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS batches (
                    id TEXT PRIMARY KEY,
                    label TEXT NOT NULL,
                    status TEXT NOT NULL,
                    owner_id INTEGER NOT NULL REFERENCES users(id),
                    workbook_original_name TEXT NOT NULL,
                    workbook_path TEXT NOT NULL,
                    output_path TEXT,
                    audit_path TEXT,
                    sheet_name TEXT,
                    header_row INTEGER,
                    invoice_col INTEGER,
                    hsn_col INTEGER,
                    missing_phrase TEXT NOT NULL DEFAULT 'Invoice Missing',
                    found_no_hsn_phrase TEXT NOT NULL DEFAULT 'Invoice Found but HSN not mentioned',
                    total_rows INTEGER NOT NULL DEFAULT 0,
                    total_docs INTEGER NOT NULL DEFAULT 0,
                    processed_docs INTEGER NOT NULL DEFAULT 0,
                    matched_count INTEGER NOT NULL DEFAULT 0,
                    missing_count INTEGER NOT NULL DEFAULT 0,
                    no_hsn_count INTEGER NOT NULL DEFAULT 0,
                    review_count INTEGER NOT NULL DEFAULT 0,
                    orphan_count INTEGER NOT NULL DEFAULT 0,
                    duplicate_count INTEGER NOT NULL DEFAULT 0,
                    error_count INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    completed_at TEXT,
                    error_message TEXT
                );

                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    batch_id TEXT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
                    file_name TEXT NOT NULL,
                    path TEXT NOT NULL,
                    sha256 TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'queued',
                    page_count INTEGER,
                    invoice_number TEXT,
                    invoice_key TEXT,
                    hsn_codes TEXT,
                    confidence REAL,
                    match_state TEXT,
                    reason TEXT,
                    evidence_json TEXT,
                    error_message TEXT,
                    created_at TEXT NOT NULL,
                    processed_at TEXT,
                    UNIQUE(batch_id, sha256)
                );

                CREATE TABLE IF NOT EXISTS results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    batch_id TEXT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
                    excel_row INTEGER NOT NULL,
                    invoice_number TEXT NOT NULL,
                    invoice_key TEXT NOT NULL,
                    previous_value TEXT,
                    output_value TEXT,
                    status TEXT NOT NULL,
                    document_id INTEGER REFERENCES documents(id) ON DELETE SET NULL,
                    confidence REAL,
                    evidence_json TEXT,
                    review_state TEXT NOT NULL DEFAULT 'none',
                    review_note TEXT,
                    updated_at TEXT NOT NULL,
                    UNIQUE(batch_id, excel_row)
                );

                CREATE TABLE IF NOT EXISTS review_decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    result_id INTEGER NOT NULL REFERENCES results(id) ON DELETE CASCADE,
                    reviewer_id INTEGER NOT NULL REFERENCES users(id),
                    old_value TEXT,
                    new_value TEXT,
                    action TEXT NOT NULL,
                    note TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS audit_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                    batch_id TEXT REFERENCES batches(id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL,
                    detail_json TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_documents_batch ON documents(batch_id, status);
                CREATE INDEX IF NOT EXISTS idx_results_batch ON results(batch_id, status);
                CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
                CREATE INDEX IF NOT EXISTS idx_logins_created ON login_events(created_at DESC);
                """
            )
            columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(batches)").fetchall()
            }
            if "duplicate_count" not in columns:
                connection.execute(
                    "ALTER TABLE batches ADD COLUMN duplicate_count INTEGER NOT NULL DEFAULT 0"
                )
            # A process interrupted during OCR remains resumable instead of appearing active forever.
            connection.execute(
                "UPDATE batches SET status='paused', error_message=COALESCE(error_message, 'Processing was interrupted; resume when ready') WHERE status='processing'"
            )
            connection.execute("DELETE FROM sessions WHERE expires_at <= ?", (utc_now(),))

    def setting(self, key: str) -> str | None:
        with self.connect() as connection:
            row = connection.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return None if row is None else str(row["value"])

    def set_setting(self, key: str, value: str) -> None:
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                (key, value, utc_now()),
            )

    def setup_required(self) -> bool:
        with self.connect() as connection:
            row = connection.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone()
        return row is None

    def create_initial_setup(
        self,
        *,
        email: str,
        display_name: str,
        admin_password_hash: str,
        shared_password_hash: str,
    ) -> int:
        now = utc_now()
        with self.transaction() as connection:
            if connection.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone():
                raise ValueError("GSTLens setup is already complete")
            cursor = connection.execute(
                "INSERT INTO users(email,display_name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                (email.strip().lower(), display_name.strip(), admin_password_hash, "admin", now),
            )
            connection.execute(
                "INSERT INTO settings(key,value,updated_at) VALUES('shared_password_hash',?,?)",
                (shared_password_hash, now),
            )
            connection.execute(
                "INSERT INTO audit_events(user_id,event_type,detail_json,created_at) VALUES(?,?,?,?)",
                (cursor.lastrowid, "installation.setup", json.dumps({"email": email.strip().lower()}), now),
            )
            return int(cursor.lastrowid)

    def user_by_email(self, email: str) -> sqlite3.Row | None:
        with self.connect() as connection:
            return connection.execute(
                "SELECT * FROM users WHERE email=? COLLATE NOCASE", (email.strip(),)
            ).fetchone()

    def create_operator_if_missing(self, email: str, display_name: str) -> sqlite3.Row:
        now = utc_now()
        with self.transaction() as connection:
            row = connection.execute(
                "SELECT * FROM users WHERE email=? COLLATE NOCASE", (email.strip(),)
            ).fetchone()
            if row is None:
                connection.execute(
                    "INSERT INTO users(email,display_name,role,created_at) VALUES(?,?,?,?)",
                    (email.strip().lower(), display_name.strip(), "operator", now),
                )
            elif row["role"] != "admin" and display_name.strip() and row["display_name"] != display_name.strip():
                connection.execute(
                    "UPDATE users SET display_name=? WHERE id=?", (display_name.strip(), row["id"])
                )
            return connection.execute(
                "SELECT * FROM users WHERE email=? COLLATE NOCASE", (email.strip(),)
            ).fetchone()

    def record_login(
        self,
        *,
        email: str,
        display_name: str | None,
        success: bool,
        reason: str | None,
        ip_address: str | None,
        user_id: int | None = None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO login_events(user_id,email,display_name,success,reason,ip_address,created_at) VALUES(?,?,?,?,?,?,?)",
                (user_id, email.strip().lower(), display_name, int(success), reason, ip_address, utc_now()),
            )

    def touch_login(self, user_id: int) -> None:
        with self.connect() as connection:
            connection.execute("UPDATE users SET last_login_at=? WHERE id=?", (utc_now(), user_id))

    def create_session(self, user_id: int, raw_token: str, hours: int) -> None:
        now = datetime.now(UTC)
        expires = now + timedelta(hours=hours)
        digest = session_digest(raw_token, self.installation_secret)
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO sessions(user_id,token_hash,created_at,expires_at) VALUES(?,?,?,?)",
                (user_id, digest, now.isoformat(timespec="seconds"), expires.isoformat(timespec="seconds")),
            )

    def user_for_session(self, raw_token: str | None) -> AuthenticatedUser | None:
        if not raw_token:
            return None
        digest = session_digest(raw_token, self.installation_secret)
        with self.connect() as connection:
            row = connection.execute(
                """
                SELECT u.id,u.email,u.display_name,u.role
                FROM sessions s JOIN users u ON u.id=s.user_id
                WHERE s.token_hash=? AND s.expires_at>? AND u.active=1
                """,
                (digest, utc_now()),
            ).fetchone()
        if row is None:
            return None
        return AuthenticatedUser(int(row["id"]), row["email"], row["display_name"], row["role"])

    def delete_session(self, raw_token: str | None) -> None:
        if not raw_token:
            return
        digest = session_digest(raw_token, self.installation_secret)
        with self.connect() as connection:
            connection.execute("DELETE FROM sessions WHERE token_hash=?", (digest,))

    def add_audit(
        self,
        event_type: str,
        *,
        user_id: int | None = None,
        batch_id: str | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO audit_events(user_id,batch_id,event_type,detail_json,created_at) VALUES(?,?,?,?,?)",
                (user_id, batch_id, event_type, json.dumps(detail or {}, ensure_ascii=False), utc_now()),
            )

    def rows(self, sql: str, parameters: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        with self.connect() as connection:
            return [dict(row) for row in connection.execute(sql, parameters).fetchall()]

    def row(self, sql: str, parameters: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        with self.connect() as connection:
            item = connection.execute(sql, parameters).fetchone()
        return None if item is None else dict(item)

    def execute(self, sql: str, parameters: tuple[Any, ...] = ()) -> int:
        with self.connect() as connection:
            cursor = connection.execute(sql, parameters)
            return int(cursor.lastrowid or 0)
