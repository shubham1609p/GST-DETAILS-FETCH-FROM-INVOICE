from __future__ import annotations

import re
from pathlib import Path
from typing import Any


_SAFE_NAME = re.compile(r"[^A-Za-z0-9._() #&+-]+")


def safe_filename(name: str, fallback: str) -> str:
    leaf = Path((name or "").replace("\\", "/")).name.strip().strip(".")
    leaf = _SAFE_NAME.sub("_", leaf)
    return leaf[:180] or fallback


def unique_path(directory: Path, filename: str) -> Path:
    candidate = directory / filename
    counter = 2
    while candidate.exists():
        candidate = directory / f"{Path(filename).stem} ({counter}){Path(filename).suffix}"
        counter += 1
    return candidate


async def save_upload(upload: Any, destination: Path, limit_bytes: int) -> int:
    """Stream a Starlette UploadFile without retaining the entire file in memory."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    try:
        with destination.open("xb") as output:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit_bytes:
                    raise ValueError(f"{destination.name} exceeds the configured upload limit")
                output.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()
    return total


def ensure_within(path: Path, root: Path) -> Path:
    resolved = path.resolve()
    root_resolved = root.resolve()
    if resolved != root_resolved and root_resolved not in resolved.parents:
        raise ValueError("Unsafe file path")
    return resolved

