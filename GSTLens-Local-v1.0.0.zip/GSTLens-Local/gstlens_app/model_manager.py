from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

from .config import AppConfig


MODEL_BASE = "https://paddle-model-ecology.bj.bcebos.com/paddlex/official_inference_model/paddle3.0.0"
MODELS = {
    "PP-OCRv6_medium_det": f"{MODEL_BASE}/PP-OCRv6_medium_det_infer.tar",
    "PP-OCRv6_medium_rec": f"{MODEL_BASE}/PP-OCRv6_medium_rec_infer.tar",
    "en_PP-OCRv5_mobile_rec": f"{MODEL_BASE}/en_PP-OCRv5_mobile_rec_infer.tar",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe_extract(archive: tarfile.TarFile, destination: Path) -> None:
    root = destination.resolve()
    for member in archive.getmembers():
        target = (destination / member.name).resolve()
        if root != target and root not in target.parents:
            raise RuntimeError(f"Unsafe model archive entry: {member.name}")
        if member.issym() or member.islnk():
            raise RuntimeError(f"Links are not allowed in model archives: {member.name}")
        if not (member.isfile() or member.isdir()):
            raise RuntimeError(f"Unsupported model archive entry: {member.name}")
    # Paths, links, and special files were validated above. Avoid the newer
    # `filter=` parameter so early Python 3.11 releases remain supported.
    archive.extractall(destination)


def download_models(config: AppConfig, *, force: bool = False) -> dict[str, dict[str, str]]:
    config.model_dir.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, dict[str, str]] = {}
    for model_name, url in MODELS.items():
        destination = config.model_dir / model_name
        if destination.exists() and any(destination.iterdir()) and not force:
            manifest[model_name] = {"path": str(destination), "state": "already present"}
            continue

        print(f"Downloading {model_name}...")
        with tempfile.TemporaryDirectory(prefix="gstlens-model-") as temp_name:
            temp_dir = Path(temp_name)
            archive_path = temp_dir / f"{model_name}.tar"
            request = urllib.request.Request(url, headers={"User-Agent": "GSTLens-Local/1.0"})
            with urllib.request.urlopen(request, timeout=120) as response, archive_path.open("wb") as output:
                shutil.copyfileobj(response, output)
            digest = _sha256(archive_path)
            extract_dir = temp_dir / "extract"
            extract_dir.mkdir()
            with tarfile.open(archive_path, mode="r:*") as archive:
                _safe_extract(archive, extract_dir)
            candidates = [path for path in extract_dir.iterdir() if path.is_dir()]
            source = candidates[0] if len(candidates) == 1 else extract_dir
            if destination.exists():
                shutil.rmtree(destination)
            shutil.copytree(source, destination)
            manifest[model_name] = {"path": str(destination), "archive_sha256": digest, "source": url}

    manifest_path = config.model_dir / "model-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest


def verify_models(config: AppConfig) -> bool:
    missing = [name for name in MODELS if not (config.model_dir / name).is_dir()]
    if missing:
        print("Missing local OCR models: " + ", ".join(missing))
        return False
    print(f"Local OCR models are ready in {config.model_dir}")
    return True


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Download or verify GSTLens local OCR models")
    parser.add_argument("action", choices=("download", "verify"), nargs="?", default="verify")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args(argv)
    config = AppConfig.load()
    config.ensure_directories()
    if args.action == "download":
        download_models(config, force=args.force)
        return 0 if verify_models(config) else 1
    return 0 if verify_models(config) else 1


if __name__ == "__main__":
    sys.exit(main())
