from __future__ import annotations

from typing import Any

from .database import Database
from .security import AuthenticatedUser


PUBLIC_BATCH_FIELDS = (
    "id",
    "label",
    "status",
    "workbook_original_name",
    "sheet_name",
    "header_row",
    "invoice_col",
    "hsn_col",
    "total_rows",
    "total_docs",
    "processed_docs",
    "matched_count",
    "missing_count",
    "no_hsn_count",
    "review_count",
    "orphan_count",
    "duplicate_count",
    "error_count",
    "created_at",
    "started_at",
    "completed_at",
    "error_message",
)


def public_batch(row: dict[str, Any]) -> dict[str, Any]:
    item = {field: row.get(field) for field in PUBLIC_BATCH_FIELDS}
    if item.get("status") == "failed":
        item["status"] = "error"
    total = int(item.get("total_rows") or 0)
    matched = int(item.get("matched_count") or 0)
    item["completion_percent"] = round((matched / total) * 100, 1) if total else 0.0
    item["output_ready"] = bool(row.get("output_path"))
    item["audit_ready"] = bool(row.get("audit_path"))
    item["processed_count"] = int(row.get("processed_docs") or 0)
    return item


def list_batches(database: Database, user: AuthenticatedUser, limit: int = 100) -> list[dict[str, Any]]:
    if user.is_admin:
        rows = database.rows("SELECT * FROM batches ORDER BY created_at DESC LIMIT ?", (limit,))
    else:
        rows = database.rows(
            "SELECT * FROM batches WHERE owner_id=? ORDER BY created_at DESC LIMIT ?", (user.id, limit)
        )
    return [public_batch(row) for row in rows]


def dashboard(database: Database, user: AuthenticatedUser) -> dict[str, Any]:
    where = "" if user.is_admin else " WHERE owner_id=?"
    params: tuple[Any, ...] = () if user.is_admin else (user.id,)
    totals = database.row(
        """
        SELECT COUNT(*) AS batches,
               COALESCE(SUM(total_rows),0) AS total_rows,
               COALESCE(SUM(total_docs),0) AS total_docs,
               COALESCE(SUM(matched_count),0) AS matched,
               COALESCE(SUM(missing_count),0) AS missing,
               COALESCE(SUM(no_hsn_count),0) AS no_hsn,
               COALESCE(SUM(review_count),0) AS review,
               COALESCE(SUM(orphan_count),0) AS orphan,
               COALESCE(SUM(duplicate_count),0) AS duplicates,
               COALESCE(SUM(error_count),0) AS errors
        FROM batches
        """
        + where,
        params,
    ) or {}
    total_rows = int(totals.get("total_rows") or 0)
    matched = int(totals.get("matched") or 0)
    return {
        "totals": totals,
        "completion_percent": round(matched * 100 / total_rows, 1) if total_rows else 0.0,
        "recent_batches": list_batches(database, user, 8),
    }


def batch_insights(database: Database, batch_id: str) -> dict[str, Any]:
    batch = database.row("SELECT * FROM batches WHERE id=?", (batch_id,))
    if batch is None:
        return {"cards": [], "top_codes": [], "exceptions": []}

    top_codes = database.rows(
        """
        SELECT output_value AS code_set, COUNT(*) AS invoice_count
        FROM results
        WHERE batch_id=? AND status='matched' AND output_value IS NOT NULL
        GROUP BY output_value
        ORDER BY invoice_count DESC, output_value
        LIMIT 10
        """,
        (batch_id,),
    )
    total = int(batch.get("total_rows") or 0)
    cards: list[dict[str, str]] = []
    missing = int(batch.get("missing_count") or 0)
    no_hsn = int(batch.get("no_hsn_count") or 0)
    review = int(batch.get("review_count") or 0)
    orphan = int(batch.get("orphan_count") or 0)
    duplicates = int(batch.get("duplicate_count") or 0)
    if total:
        cards.append(
            {
                "title": "HSN completion",
                "value": f"{(int(batch.get('matched_count') or 0) * 100 / total):.1f}%",
                "detail": "Invoices with accepted HSN/SAC values",
                "severity": "positive",
            }
        )
    if missing:
        cards.append(
            {
                "title": "Missing invoice evidence",
                "value": str(missing),
                "detail": "Excel invoices with no matched PDF; obtain these files before filing.",
                "severity": "warning",
            }
        )
    if no_hsn:
        cards.append(
            {
                "title": "Supplier documents without HSN/SAC",
                "value": str(no_hsn),
                "detail": "Matched invoices where an HSN/SAC label or code was not present.",
                "severity": "warning",
            }
        )
    if review:
        cards.append(
            {
                "title": "Human verification required",
                "value": str(review),
                "detail": "Low-confidence handwriting, duplicate numbers or conflicting evidence.",
                "severity": "danger",
            }
        )
    if orphan:
        cards.append(
            {
                "title": "Orphan PDFs",
                "value": str(orphan),
                "detail": "Uploaded PDFs whose invoice number is not in the selected Excel list.",
                "severity": "neutral",
            }
        )
    if duplicates:
        cards.append(
            {
                "title": "Duplicate PDF copies ignored",
                "value": str(duplicates),
                "detail": "Byte-identical uploads were hashed and processed only once.",
                "severity": "neutral",
            }
        )
    return {"cards": cards, "top_codes": top_codes, "disclaimer": "Operational observations only; not tax advice."}
