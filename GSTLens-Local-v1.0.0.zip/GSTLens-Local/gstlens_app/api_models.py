from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, EmailStr, Field, field_validator


class SetupPayload(BaseModel):
    display_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    admin_password: str = Field(min_length=7, max_length=256)
    shared_password: str = Field(min_length=7, max_length=256)


class LoginPayload(BaseModel):
    display_name: str = Field(default="", max_length=120)
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)


class MappingPayload(BaseModel):
    sheet_name: str = Field(min_length=1, max_length=255)
    header_row: int = Field(ge=1, le=500)
    invoice_col: int = Field(ge=1, le=16_384)
    hsn_col: int = Field(ge=1, le=16_384)
    missing_phrase: str = Field(default="Invoice Missing", min_length=1, max_length=120)
    found_no_hsn_phrase: str = Field(
        default="Invoice Found but HSN not mentioned", min_length=1, max_length=120
    )

    @field_validator("sheet_name", "missing_phrase", "found_no_hsn_phrase")
    @classmethod
    def no_formula_prefix(cls, value: str) -> str:
        value = value.strip()
        if value.startswith(("=", "+", "-", "@")):
            raise ValueError("This value cannot start with an Excel formula character")
        return value


class BatchActionPayload(BaseModel):
    action: Literal["start", "pause", "resume", "cancel", "retry"]


class ReviewPayload(BaseModel):
    action: Literal["accept", "edit", "no_hsn", "wrong_match", "missing"]
    value: str | None = Field(default=None, max_length=500)
    note: str | None = Field(default=None, max_length=1000)

    @field_validator("value")
    @classmethod
    def safe_cell_value(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        if value.startswith(("=", "+", "-", "@")):
            raise ValueError("Review values cannot start with an Excel formula character")
        return value

