from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status

from .api_models import LoginPayload, SetupPayload
from .config import AppConfig
from .database import Database
from .security import AuthenticatedUser, hash_password, new_session_token, verify_password


SESSION_COOKIE = "gstlens_session"


class AuthService:
    def __init__(self, database: Database, config: AppConfig) -> None:
        self.database = database
        self.config = config

    async def current_user(self, request: Request) -> AuthenticatedUser:
        user = self.database.user_for_session(request.cookies.get(SESSION_COOKIE))
        if user is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Sign in required")
        return user

    def router(self) -> APIRouter:
        router = APIRouter(prefix="/api")

        @router.get("/setup/status")
        async def setup_status() -> dict[str, bool]:
            return {"setup_required": self.database.setup_required()}

        @router.post("/setup", status_code=201)
        async def setup(payload: SetupPayload, request: Request) -> dict[str, bool]:
            client = request.client.host if request.client else ""
            if client not in {"127.0.0.1", "::1", "localhost", "testclient"}:
                raise HTTPException(status_code=403, detail="First-time setup is local-only")
            try:
                self.database.create_initial_setup(
                    email=str(payload.email),
                    display_name=payload.display_name,
                    admin_password_hash=hash_password(payload.admin_password),
                    shared_password_hash=hash_password(payload.shared_password),
                )
            except ValueError as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
            return {"ok": True}

        @router.post("/auth/login")
        async def login(payload: LoginPayload, request: Request, response: Response) -> dict[str, object]:
            if self.database.setup_required():
                raise HTTPException(status_code=409, detail="Complete first-time setup")
            email = str(payload.email).strip().lower()
            row = self.database.user_by_email(email)
            success = False
            reason: str | None = None
            if row is not None and not bool(row["active"]):
                reason = "account disabled"
            elif row is not None and row["role"] == "admin":
                success = verify_password(row["password_hash"] or "", payload.password)
                reason = None if success else "invalid credentials"
            else:
                shared_hash = self.database.setting("shared_password_hash") or ""
                success = bool(payload.display_name.strip()) and verify_password(shared_hash, payload.password)
                reason = None if success else "invalid credentials or missing name"
                if success:
                    row = self.database.create_operator_if_missing(email, payload.display_name)

            client_ip = request.client.host if request.client else None
            self.database.record_login(
                email=email,
                display_name=payload.display_name or (row["display_name"] if row else None),
                success=success,
                reason=reason,
                ip_address=client_ip,
                user_id=int(row["id"]) if success and row is not None else None,
            )
            if not success or row is None:
                raise HTTPException(status_code=401, detail="Email, name or password is not correct")

            token = new_session_token()
            self.database.create_session(int(row["id"]), token, self.config.session_hours)
            self.database.touch_login(int(row["id"]))
            response.set_cookie(
                SESSION_COOKIE,
                token,
                max_age=self.config.session_hours * 3600,
                httponly=True,
                secure=False,
                samesite="strict",
                path="/",
            )
            return {
                "user": {
                    "id": int(row["id"]),
                    "email": row["email"],
                    "display_name": row["display_name"],
                    "role": row["role"],
                }
            }

        @router.post("/auth/logout")
        async def logout(request: Request, response: Response) -> dict[str, bool]:
            self.database.delete_session(request.cookies.get(SESSION_COOKIE))
            response.delete_cookie(SESSION_COOKIE, path="/")
            return {"ok": True}

        @router.get("/auth/me")
        async def me(user: AuthenticatedUser = Depends(self.current_user)) -> dict[str, object]:
            return {"user": asdict(user)}

        return router

    async def require_admin(self, request: Request) -> AuthenticatedUser:
        user = await self.current_user(request)
        if not user.is_admin:
            raise HTTPException(status_code=403, detail="Administrator access required")
        return user
