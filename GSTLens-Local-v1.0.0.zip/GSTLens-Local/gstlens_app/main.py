from __future__ import annotations

import sys
import socket
import threading
import webbrowser

import uvicorn

from .config import AppConfig
from .database import Database
from .server import create_app


def main() -> int:
    config = AppConfig.load()
    config.ensure_directories()
    database = Database(config.database_path, config.secret_key())
    database.initialize()
    if database.setup_required():
        print("GSTLens Local needs first-time login setup.")
        print("Run: python -m gstlens_app.setup_cli")
        return 2
    app = create_app(config)
    url = f"http://{config.host}:{config.port}"
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.settimeout(0.3)
        if probe.connect_ex((config.host, config.port)) == 0:
            print(f"GSTLens Local is already running at {url}")
            webbrowser.open(url)
            return 0
    print(f"GSTLens Local is running at {url}")
    print("Keep this window open while invoices are processing. Press Ctrl+C to stop.")
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    uvicorn.run(app, host=config.host, port=config.port, log_level="info", access_log=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
