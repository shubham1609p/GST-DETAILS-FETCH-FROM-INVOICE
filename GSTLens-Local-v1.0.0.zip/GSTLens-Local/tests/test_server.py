from __future__ import annotations

import io
import tempfile
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from openpyxl import Workbook

from gstlens_app.config import AppConfig
from gstlens_app.server import create_app


class LocalServerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        web = Path(__file__).resolve().parents[1] / "web"
        config = AppConfig(
            data_dir=root,
            database_path=root / "db.sqlite3",
            batches_dir=root / "batches",
            model_dir=root / "models",
            evidence_dir=root / "evidence",
            web_dir=web,
        )
        self.client = TestClient(create_app(config))

    def tearDown(self) -> None:
        self.client.close()
        self.temp.cleanup()

    @staticmethod
    def _workbook_bytes() -> bytes:
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "B2B"
        sheet.cell(1, 3).value = "Invoice No"
        sheet.cell(1, 7).value = "HSN/SAC"
        sheet.cell(2, 3).value = "INV-001"
        output = io.BytesIO()
        workbook.save(output)
        return output.getvalue()

    def test_setup_login_upload_mapping_and_admin_log(self) -> None:
        setup = self.client.post(
            "/api/setup",
            json={
                "display_name": "Test Administrator",
                "email": "admin@example.com",
                "admin_password": "admin-test-password",
                "shared_password": "operator-test-password",
            },
        )
        self.assertEqual(setup.status_code, 201)
        login = self.client.post(
            "/api/auth/login",
            json={"display_name": "", "email": "admin@example.com", "password": "admin-test-password"},
        )
        self.assertEqual(login.status_code, 200)
        response = self.client.post(
            "/api/batches",
            data={"label": "Synthetic month"},
            files=[
                (
                    "workbook",
                    (
                        "month.xlsx",
                        self._workbook_bytes(),
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    ),
                ),
                ("invoices", ("invoice.pdf", b"%PDF-1.4\n% test fixture\n", "application/pdf")),
            ],
        )
        self.assertEqual(response.status_code, 201, response.text)
        batch = response.json()["batch"]
        self.assertEqual(batch["mapping"]["invoice_column"], "C")
        self.assertEqual(batch["mapping"]["hsn_column"], "G")
        mapping = self.client.patch(
            f"/api/batches/{batch['id']}/mapping",
            json={
                "sheet_name": "B2B",
                "header_row": 1,
                "invoice_col": 3,
                "hsn_col": 7,
                "missing_phrase": "Invoice Missing",
                "found_no_hsn_phrase": "Invoice Found but HSN not mentioned",
            },
        )
        self.assertEqual(mapping.status_code, 200)
        self.assertEqual(mapping.json()["invoice_rows"], 1)
        logs = self.client.get("/api/admin/logins")
        self.assertEqual(logs.status_code, 200)
        self.assertEqual(logs.json()["summary"]["sign_ins"], 1)


if __name__ == "__main__":
    unittest.main()
