from __future__ import annotations

import os
import stat
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from gstlens_ocr import (
    NoInvoicesFoundError,
    OCRModelError,
    OCRRuntimeConfig,
    PaddleOCRConfig,
    PaddleOCREngine,
    PreprocessConfig,
    UnsafeInputError,
    UploadSafetyLimits,
    enumerate_uploaded_pdfs,
    parse_paddle_predictions,
    safe_extract_invoice_pdfs,
    sha256_file,
)
from gstlens_ocr.preprocess import normalize_rgb_image, preprocess_image_with_report


PDF_BYTES = b"%PDF-1.4\n1 0 obj <<>> endobj\n%%EOF\n"


class UploadSafetyTests(unittest.TestCase):
    def test_hash_is_streamed_and_stable(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "invoice.pdf"
            path.write_bytes(PDF_BYTES)
            self.assertEqual(sha256_file(path), sha256_file(path))
            self.assertEqual(len(sha256_file(path)), 64)

    def test_extracts_nested_pdfs_and_ignores_companion_files(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            archive = root / "invoices.zip"
            with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
                output.writestr("supplier/Invoice 1.PDF", PDF_BYTES)
                output.writestr("notes.txt", "not an invoice")
            documents = safe_extract_invoice_pdfs(archive, root / "work")
            self.assertEqual(len(documents), 1)
            self.assertEqual(documents[0].archive_member, "supplier/Invoice 1.PDF")
            self.assertTrue(documents[0].path.is_file())

    def test_rejects_zip_path_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            archive = root / "bad.zip"
            with zipfile.ZipFile(archive, "w") as output:
                output.writestr("../escape.pdf", PDF_BYTES)
            with self.assertRaises(UnsafeInputError):
                safe_extract_invoice_pdfs(archive, root / "work")
            self.assertFalse((root / "escape.pdf").exists())

    def test_rejects_zip_symlink(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            archive = root / "bad.zip"
            link = zipfile.ZipInfo("invoice.pdf")
            link.create_system = 3
            link.external_attr = (stat.S_IFLNK | 0o777) << 16
            with zipfile.ZipFile(archive, "w") as output:
                output.writestr(link, "elsewhere.pdf")
            with self.assertRaises(UnsafeInputError):
                safe_extract_invoice_pdfs(archive, root / "work")

    def test_rejects_suspicious_compression_ratio(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            archive = root / "bomb.zip"
            with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
                output.writestr("invoice.pdf", PDF_BYTES + b"0" * 20_000)
            limits = UploadSafetyLimits(max_compression_ratio=2.0)
            with self.assertRaises(UnsafeInputError):
                safe_extract_invoice_pdfs(archive, root / "work", limits)

    def test_upload_folder_ignores_excel_and_enumerates_pdf(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "data.xlsx").write_bytes(b"spreadsheet")
            (root / "invoice.pdf").write_bytes(PDF_BYTES)
            documents = enumerate_uploaded_pdfs(root, root / "extract")
            self.assertEqual([item.display_name for item in documents], ["invoice.pdf"])

    def test_upload_folder_without_invoices_is_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "data.xlsx").write_bytes(b"spreadsheet")
            with self.assertRaises(NoInvoicesFoundError):
                enumerate_uploaded_pdfs(root)


class PaddleResultTests(unittest.TestCase):
    def test_parses_v3_result_and_boxes(self) -> None:
        result = parse_paddle_predictions(
            [
                {
                    "res": {
                        "rec_texts": ["HSN/SAC", "998314"],
                        "rec_scores": [0.98, 0.93],
                        "rec_boxes": [[10, 20, 80, 40], [90, 20, 160, 40]],
                    }
                }
            ],
            page_index=2,
            width=1000,
            height=1400,
        )
        self.assertEqual([token.text for token in result.tokens], ["HSN/SAC", "998314"])
        self.assertEqual(result.tokens[1].bbox, (90.0, 20.0, 160.0, 40.0))
        self.assertAlmostEqual(result.mean_confidence, 0.955)

    def test_parses_result_json_property(self) -> None:
        class FakeResult:
            json = '{"res":{"rec_texts":["8471"],"rec_scores":[0.88],"rec_polys":[[[1,2],[3,2],[3,4],[1,4]]]}}'

        result = parse_paddle_predictions(
            [FakeResult()], page_index=0, width=20, height=10
        )
        self.assertEqual(result.tokens[0].text, "8471")
        self.assertEqual(result.tokens[0].polygon[0], (1.0, 2.0))

    def test_parses_legacy_single_image_output(self) -> None:
        box = [[1, 2], [4, 2], [4, 5], [1, 5]]
        result = parse_paddle_predictions(
            [[[box, ("Invoice No", 0.91)], [box, ("A-12", 0.89)]]],
            page_index=0,
            width=100,
            height=100,
        )
        self.assertEqual([token.text for token in result.tokens], ["Invoice No", "A-12"])


class PaddleEngineTests(unittest.TestCase):
    def _model_config(self, root: Path) -> PaddleOCRConfig:
        for name in ("PP-OCRv6_medium_det", "PP-OCRv6_medium_rec"):
            model = root / name
            model.mkdir()
            (model / "inference.json").write_text("{}", encoding="utf-8")
        return PaddleOCRConfig(model_root=root, cpu_threads=2)

    def test_engine_is_lazy_and_uses_only_local_model_dirs(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            config = self._model_config(root)
            constructor_calls: list[dict[str, object]] = []

            class FakePaddle:
                def predict(self, *, input):
                    return [
                        {
                            "rec_texts": ["HSN", "9983"],
                            "rec_scores": [0.9, 0.8],
                            "rec_boxes": [[0, 0, 10, 10], [11, 0, 21, 10]],
                        }
                    ]

            def factory(**kwargs):
                constructor_calls.append(kwargs)
                return FakePaddle()

            engine = PaddleOCREngine(config, engine_factory=factory)
            self.assertFalse(engine.loaded)

            import numpy as np

            result = engine.recognize_page(np.full((30, 40, 3), 255, dtype=np.uint8))
            self.assertTrue(engine.loaded)
            self.assertEqual(len(constructor_calls), 1)
            self.assertEqual([token.text for token in result.tokens], ["HSN", "9983"])
            self.assertIn("PP-OCRv6_medium_det", constructor_calls[0]["text_detection_model_dir"])
            self.assertEqual(os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"], "True")

    def test_missing_model_is_reported_before_factory_runs(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            factory = mock.Mock()
            engine = PaddleOCREngine(
                PaddleOCRConfig(model_root=Path(folder)), engine_factory=factory
            )
            with self.assertRaises(OCRModelError):
                engine.load()
            factory.assert_not_called()


class PreprocessTests(unittest.TestCase):
    def test_rgba_is_composited_on_white(self) -> None:
        import numpy as np

        image = np.array([[[0, 0, 0, 0], [10, 20, 30, 255]]], dtype=np.uint8)
        output = normalize_rgb_image(image)
        self.assertEqual(output[0, 0].tolist(), [255, 255, 255])
        self.assertEqual(output[0, 1].tolist(), [10, 20, 30])

    def test_missing_opencv_has_safe_noop_fallback(self) -> None:
        import numpy as np

        image = np.full((10, 20, 3), 200, dtype=np.uint8)
        with mock.patch("gstlens_ocr.preprocess._try_load_cv2", return_value=None):
            output, report = preprocess_image_with_report(image)
        self.assertFalse(report.opencv_used)
        self.assertTrue(np.array_equal(image, output))

    def test_opencv_can_be_required(self) -> None:
        import numpy as np

        image = np.full((10, 20, 3), 200, dtype=np.uint8)
        with mock.patch("gstlens_ocr.preprocess._try_load_cv2", return_value=None):
            with self.assertRaises(Exception) as raised:
                preprocess_image_with_report(
                    image, PreprocessConfig(require_opencv=True)
                )
        self.assertIn("opencv-python-headless", str(raised.exception))


class PDFRuntimeTests(unittest.TestCase):
    def test_scanned_pdf_uses_injected_local_engine_without_models(self) -> None:
        try:
            from PIL import Image
            import pypdfium2  # noqa: F401
        except ImportError:
            self.skipTest("Pillow/pypdfium2 not installed")

        import numpy as np

        class FakeEngine:
            def recognize_page(self, image, *, page_index=0, native_text=""):
                return parse_paddle_predictions(
                    [
                        {
                            "rec_texts": ["Invoice No", "A-12", "HSN", "9983"],
                            "rec_scores": [0.9, 0.95, 0.92, 0.93],
                            "rec_boxes": [
                                [1, 1, 10, 10],
                                [11, 1, 20, 10],
                                [1, 20, 10, 30],
                                [11, 20, 20, 30],
                            ],
                        }
                    ],
                    page_index=page_index,
                    width=image.shape[1],
                    height=image.shape[0],
                    native_text=native_text,
                )

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "scan.pdf"
            Image.fromarray(np.full((160, 240, 3), 255, dtype=np.uint8)).save(
                path, "PDF"
            )
            from gstlens_ocr import InvoiceOCRRuntime

            runtime = InvoiceOCRRuntime(
                FakeEngine(),
                OCRRuntimeConfig(
                    render_dpi=100,
                    preprocess=PreprocessConfig(enabled=False),
                ),
            )
            result = runtime.ocr_pdf(path)
            self.assertEqual(result.pages[0].source, "paddleocr")
            self.assertEqual(result.tokens[-1].text, "9983")
            self.assertEqual(result.sha256, sha256_file(path))
            self.assertTrue(result.evidence[0]["tokens"])


if __name__ == "__main__":
    unittest.main()
