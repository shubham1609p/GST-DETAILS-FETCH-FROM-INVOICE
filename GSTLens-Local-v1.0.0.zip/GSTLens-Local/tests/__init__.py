"""GSTLens core tests."""

