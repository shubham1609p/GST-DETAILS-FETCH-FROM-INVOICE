from __future__ import annotations

import unittest

from gstlens_core import (
    BoundingBox,
    InvoiceMatcher,
    InvoiceMatchStatus,
    InvoiceReference,
    OCRPage,
    OCRToken,
    normalize_invoice_number,
)


def token(text: str, confidence: float, x0: float, y0: float, x1: float, y1: float) -> OCRToken:
    return OCRToken(text, confidence, BoundingBox(x0, y0, x1, y1))


class InvoiceNormalizationTests(unittest.TestCase):
    def test_harmless_unicode_and_spacing_are_normalized(self) -> None:
        self.assertEqual(normalize_invoice_number("  ab – 001 / 25  "), "AB-001/25")
        self.assertEqual(normalize_invoice_number(4.0), "4")

    def test_punctuation_and_leading_zeroes_are_not_removed(self) -> None:
        self.assertNotEqual(normalize_invoice_number("AB-123"), normalize_invoice_number("AB/123"))
        self.assertNotEqual(normalize_invoice_number("0004"), normalize_invoice_number("4"))


class InvoiceMatcherTests(unittest.TestCase):
    def test_exact_and_unique_whitespace_matches(self) -> None:
        matcher = InvoiceMatcher(
            [
                InvoiceReference(9, "T/14062/25-26"),
                InvoiceReference(10, "ACME 100"),
            ]
        )
        self.assertEqual(matcher.match("t / 14062 / 25 – 26").reference_id, 9)
        self.assertEqual(matcher.match("ACME100").reference_id, 10)

    def test_similar_punctuation_is_not_fuzzy_matched(self) -> None:
        matcher = InvoiceMatcher(
            [
                InvoiceReference(1, "AB-123"),
                InvoiceReference(2, "AB/123"),
            ]
        )
        self.assertIs(matcher.match("AB123").status, InvoiceMatchStatus.NOT_FOUND)

    def test_duplicate_invoice_number_is_ambiguous(self) -> None:
        matcher = InvoiceMatcher(
            [InvoiceReference(1, "INV-7"), InvoiceReference(2, "INV-7")]
        )
        result = matcher.match("inv-7")
        self.assertIs(result.status, InvoiceMatchStatus.AMBIGUOUS)
        self.assertEqual(result.reference_ids, (1, 2))

    def test_blank_query_is_invalid(self) -> None:
        matcher = InvoiceMatcher([InvoiceReference(1, "INV-7")])
        self.assertIs(matcher.match("  ").status, InvoiceMatchStatus.INVALID)

    def test_match_pages_requires_explicit_invoice_label(self) -> None:
        matcher = InvoiceMatcher([InvoiceReference(9, "T/14062/25-26")])
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("GSTIN", 0.99, 20, 20, 90, 45),
                token("24AACCS7981D1ZA", 0.98, 110, 20, 330, 45),
                token("Invoice", 0.97, 20, 100, 110, 125),
                token("No.", 0.96, 115, 100, 155, 125),
                token("T/14062/25-26", 0.94, 180, 100, 360, 125),
                token("19/07/2025", 0.99, 500, 100, 620, 125),
            ),
        )
        result = matcher.match_pages((page,))
        self.assertIs(result.status, InvoiceMatchStatus.MATCHED)
        self.assertEqual(result.reference_id, 9)
        self.assertEqual(result.observed_invoice_number, "T/14062/25-26")
        self.assertFalse(result.requires_review)

        no_label_page = OCRPage(
            1,
            1000,
            1400,
            (token("T/14062/25-26", 0.99, 180, 100, 360, 125),),
        )
        self.assertIs(
            matcher.match_pages((no_label_page,)).status,
            InvoiceMatchStatus.NOT_FOUND,
        )

    def test_tax_invoice_title_is_not_treated_as_a_number_label(self) -> None:
        matcher = InvoiceMatcher([InvoiceReference(9, "1234")])
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("TAX", 0.99, 400, 20, 450, 50),
                token("INVOICE", 0.99, 460, 20, 570, 50),
                token("1234", 0.99, 430, 70, 500, 100),
            ),
        )
        self.assertIs(
            matcher.match_pages((page,)).status,
            InvoiceMatchStatus.NOT_FOUND,
        )

    def test_bill_number_dash_delimiter_is_removed(self) -> None:
        matcher = InvoiceMatcher([InvoiceReference(9, "4")])
        page = OCRPage(
            1,
            1000,
            1400,
            (token("Bill No - 4", 0.99, 20, 40, 180, 70),),
        )
        self.assertEqual(matcher.match_pages((page,)).reference_id, 9)

    def test_embedded_label_and_low_confidence_require_review(self) -> None:
        matcher = InvoiceMatcher([InvoiceReference("row-1", "B-004")])
        page = OCRPage(
            1,
            800,
            1000,
            (token("Bill No: B-004", 0.52, 20, 40, 220, 70),),
        )
        result = matcher.match_pages((page,))
        self.assertEqual(result.reference_id, "row-1")
        self.assertTrue(result.requires_review)
        self.assertIn("low OCR confidence", result.review_reasons[0])

    def test_ocr_match_to_duplicate_rows_requires_review(self) -> None:
        matcher = InvoiceMatcher(
            [InvoiceReference(1, "B-004"), InvoiceReference(2, "B-004")]
        )
        page = OCRPage(
            1,
            800,
            1000,
            (token("Bill No: B-004", 0.99, 20, 40, 220, 70),),
        )
        result = matcher.match_pages((page,))
        self.assertIs(result.status, InvoiceMatchStatus.AMBIGUOUS)
        self.assertTrue(result.requires_review)

    def test_token_spacing_collision_is_ambiguous(self) -> None:
        matcher = InvoiceMatcher(
            [
                InvoiceReference(1, "AB 123"),
                InvoiceReference(2, "AB123"),
            ]
        )
        page = OCRPage(
            1,
            800,
            1000,
            (
                token("Invoice", 0.99, 20, 40, 100, 70),
                token("No.", 0.99, 105, 40, 140, 70),
                token("AB", 0.99, 160, 40, 195, 70),
                token("123", 0.99, 200, 40, 250, 70),
            ),
        )
        result = matcher.match_pages((page,))
        self.assertIs(result.status, InvoiceMatchStatus.AMBIGUOUS)
        self.assertEqual(result.reference_ids, (1, 2))

    def test_split_tokens_use_an_exact_compact_candidate_when_unique(self) -> None:
        matcher = InvoiceMatcher([InvoiceReference(1, "AB123")])
        page = OCRPage(
            1,
            800,
            1000,
            (
                token("Invoice", 0.99, 20, 40, 100, 70),
                token("No.", 0.99, 105, 40, 140, 70),
                token("AB", 0.99, 160, 40, 195, 70),
                token("123", 0.99, 200, 40, 250, 70),
            ),
        )
        result = matcher.match_pages((page,))
        self.assertEqual(result.reference_id, 1)
        self.assertFalse(result.requires_review)


if __name__ == "__main__":
    unittest.main()
