from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill

from gstlens_core import (
    WorkbookCellUpdate,
    WorkbookMapping,
    WorkbookUpdateStatus,
    detect_workbook_mappings,
    read_invoice_rows,
    update_workbook_by_invoice,
)


class WorkbookTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        directory = Path(self.temporary_directory.name)
        self.source = directory / "source.xlsx"
        self.output = directory / "updated.xlsx"

        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "B2B"
        sheet["A1"] = "Goods and Services Tax - GSTR-2B"
        sheet["C6"] = "Invoice number"
        sheet["G6"] = "HSN/SAC"
        sheet["C9"] = "INV-001"
        sheet["G9"] = "old-value"
        sheet["G9"].fill = PatternFill(fill_type="solid", fgColor="FFFF00")
        sheet["C10"] = "INV/002"
        sheet["C11"] = "DUP-7"
        sheet["C12"] = "DUP-7"
        sheet["C13"] = 4
        sheet["C13"].number_format = "0000"
        audit = workbook.create_sheet("Audit")
        audit["A1"] = "unchanged"
        workbook.save(self.source)

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_mapping_and_invoice_rows_are_discovered(self) -> None:
        mappings = detect_workbook_mappings(self.source)
        self.assertEqual(
            mappings,
            (WorkbookMapping("B2B", 6, 3, 7),),
        )
        rows = read_invoice_rows(self.source, mappings[0])
        self.assertEqual(rows[0].invoice_number, "INV-001")
        self.assertEqual(rows[-1].invoice_number, "0004")

    def test_update_overwrites_value_and_preserves_formatting_and_other_sheets(self) -> None:
        mapping = WorkbookMapping("B2B", 6, 3, 7)
        report = update_workbook_by_invoice(
            self.source,
            self.output,
            mapping,
            (
                WorkbookCellUpdate("inv-001", "730890, 998311"),
                WorkbookCellUpdate("INV-404", "Invoice Missing"),
                WorkbookCellUpdate("0004", "998311"),
            ),
        )
        self.assertEqual(report.updated_count, 2)
        self.assertEqual(
            [outcome.status for outcome in report.outcomes],
            [
                WorkbookUpdateStatus.UPDATED,
                WorkbookUpdateStatus.NOT_FOUND,
                WorkbookUpdateStatus.UPDATED,
            ],
        )

        original = load_workbook(self.source)
        updated = load_workbook(self.output)
        try:
            self.assertEqual(original["B2B"]["G9"].value, "old-value")
            self.assertEqual(updated["B2B"]["G9"].value, "730890, 998311")
            self.assertEqual(updated["B2B"]["G13"].value, "998311")
            self.assertEqual(
                updated["B2B"]["G9"].fill.fgColor.rgb,
                original["B2B"]["G9"].fill.fgColor.rgb,
            )
            self.assertEqual(updated["Audit"]["A1"].value, "unchanged")
        finally:
            original.close()
            updated.close()

    def test_duplicate_invoice_rows_are_not_written(self) -> None:
        report = update_workbook_by_invoice(
            self.source,
            self.output,
            WorkbookMapping("B2B", 6, 3, 7),
            (WorkbookCellUpdate("DUP-7", "730890"),),
        )
        self.assertIs(report.outcomes[0].status, WorkbookUpdateStatus.AMBIGUOUS)
        updated = load_workbook(self.output)
        try:
            self.assertIsNone(updated["B2B"]["G11"].value)
            self.assertIsNone(updated["B2B"]["G12"].value)
        finally:
            updated.close()

    def test_conflicting_updates_to_same_row_are_not_written(self) -> None:
        report = update_workbook_by_invoice(
            self.source,
            self.output,
            WorkbookMapping("B2B", 6, 3, 7),
            (
                WorkbookCellUpdate("INV/002", "730890"),
                WorkbookCellUpdate("INV/002", "998311"),
            ),
        )
        self.assertTrue(
            all(
                item.status is WorkbookUpdateStatus.CONFLICTING_UPDATE
                for item in report.outcomes
            )
        )
        updated = load_workbook(self.output)
        try:
            self.assertIsNone(updated["B2B"]["G10"].value)
        finally:
            updated.close()

    def test_input_file_cannot_be_overwritten_in_place(self) -> None:
        with self.assertRaisesRegex(ValueError, "never overwritten"):
            update_workbook_by_invoice(
                self.source,
                self.source,
                WorkbookMapping("B2B", 6, 3, 7),
                (),
            )


if __name__ == "__main__":
    unittest.main()

