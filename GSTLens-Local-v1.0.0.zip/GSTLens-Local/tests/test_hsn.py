from __future__ import annotations

import unittest

from gstlens_core import BoundingBox, OCRPage, OCRToken, extract_hsn_sac


def token(text: str, confidence: float, x0: float, y0: float, x1: float, y1: float) -> OCRToken:
    return OCRToken(text, confidence, BoundingBox(x0, y0, x1, y1))


class HsnExtractionTests(unittest.TestCase):
    def test_arbitrary_numbers_without_hsn_context_are_never_codes(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("Invoice No", 0.98, 20, 50, 130, 75),
                token("49604", 0.80, 150, 50, 220, 75),
                token("49708", 0.71, 600, 1000, 670, 1030),
                token("12345678", 0.99, 700, 1100, 810, 1130),
            ),
        )
        extraction = extract_hsn_sac((page,))
        self.assertEqual(extraction.codes, ())
        self.assertFalse(extraction.label_found)

    def test_inline_label_extracts_comma_separated_codes(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("HSN/SAC", 0.99, 50, 100, 150, 130),
                token(":", 0.99, 155, 100, 160, 130),
                token("998311, 995411", 0.97, 170, 100, 350, 130),
            ),
        )
        extraction = extract_hsn_sac((page,))
        self.assertEqual(extraction.codes, ("998311", "995411"))
        self.assertEqual(extraction.joined_codes, "998311, 995411")
        self.assertFalse(extraction.requires_review)

    def test_code_embedded_in_label_token_is_supported(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (token("HSN/SAC: 998311", 0.96, 50, 100, 280, 130),),
        )
        self.assertEqual(extract_hsn_sac((page,)).codes, ("998311",))

    def test_table_column_extracts_all_unique_codes_and_stops_at_total(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("Description", 0.99, 40, 100, 280, 130),
                token("HSN/SAC", 0.98, 390, 100, 500, 130),
                token("Qty", 0.99, 590, 100, 650, 130),
                token("Amount", 0.99, 750, 100, 860, 130),
                token("Steel item", 0.96, 40, 160, 250, 190),
                token("730890", 0.94, 410, 160, 490, 190),
                token("12", 0.99, 605, 160, 630, 190),
                token("12345678", 0.99, 750, 160, 850, 190),
                token("Service", 0.96, 40, 220, 250, 250),
                token("998311", 0.93, 410, 220, 490, 250),
                token("1", 0.99, 605, 220, 630, 250),
                token("5000", 0.99, 780, 220, 840, 250),
                token("TOTAL", 0.99, 40, 290, 150, 320),
                token("999999", 0.99, 410, 290, 490, 320),
            ),
        )
        extraction = extract_hsn_sac((page,))
        self.assertEqual(extraction.codes, ("730890", "998311"))
        self.assertNotIn("12345678", extraction.codes)
        self.assertNotIn("999999", extraction.codes)

    def test_wrong_length_and_amount_format_are_rejected_even_near_label(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("HSN", 0.99, 50, 100, 120, 130),
                token("12345", 0.99, 140, 100, 210, 130),
                token("1,234.00", 0.99, 220, 100, 330, 130),
            ),
        )
        extraction = extract_hsn_sac((page,))
        self.assertEqual(extraction.codes, ())
        self.assertTrue(extraction.label_found)

    def test_blank_hsn_field_does_not_capture_a_later_invoice_number(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("HSN/SAC", 0.99, 50, 100, 150, 130),
                token("Invoice", 0.99, 190, 100, 280, 130),
                token("No.", 0.99, 285, 100, 330, 130),
                token("1234", 0.99, 350, 100, 410, 130),
            ),
        )
        self.assertEqual(extract_hsn_sac((page,)).codes, ())

    def test_stacked_blank_hsn_field_does_not_capture_labelled_number(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("HSN/SAC", 0.99, 50, 100, 150, 130),
                token("Invoice", 0.99, 45, 150, 120, 180),
                token("No.", 0.99, 125, 150, 160, 180),
                token("1234", 0.99, 165, 150, 220, 180),
            ),
        )
        self.assertEqual(extract_hsn_sac((page,)).codes, ())

    def test_low_confidence_context_candidate_requires_review(self) -> None:
        page = OCRPage(
            1,
            1000,
            1400,
            (
                token("HSN", 0.99, 50, 100, 120, 130),
                token("730890", 0.51, 140, 100, 230, 130),
            ),
        )
        extraction = extract_hsn_sac((page,))
        self.assertEqual(extraction.codes, ("730890",))
        self.assertTrue(extraction.requires_review)
        self.assertIn("low OCR confidence", extraction.review_reasons[0])


if __name__ == "__main__":
    unittest.main()
