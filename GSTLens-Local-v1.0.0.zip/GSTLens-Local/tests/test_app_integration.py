from __future__ import annotations

import json
import shutil
import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook, load_workbook

from gstlens_app.config import AppConfig
from gstlens_app.database import Database, utc_now
from gstlens_app.processor import BatchProcessor
from gstlens_core import WorkbookMapping, read_invoice_rows
from gstlens_ocr import DocumentOCRResult, OCRToken as RuntimeToken, PageOCRResult


class ReconciliationIntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.config = AppConfig(
            data_dir=root,
            database_path=root / "db.sqlite3",
            batches_dir=root / "batches",
            model_dir=root / "models",
            evidence_dir=root / "evidence",
            web_dir=root / "web",
        )
        self.config.ensure_directories()
        self.database = Database(self.config.database_path, b"s" * 32)
        self.database.initialize()
        self.database.execute(
            "INSERT INTO users(email,display_name,role,created_at) VALUES(?,?,?,?)",
            ("test@example.com", "Test User", "admin", utc_now()),
        )
        self.processor = BatchProcessor(self.database, self.config)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def _batch(
        self,
        batch_id: str,
        workbook: Path,
        mapping: WorkbookMapping,
        *,
        total_docs: int = 1,
    ) -> None:
        self.database.execute(
            """
            INSERT INTO batches(
                id,label,status,owner_id,workbook_original_name,workbook_path,
                sheet_name,header_row,invoice_col,hsn_col,total_docs,created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                batch_id,
                "Test",
                "processing",
                1,
                workbook.name,
                str(workbook),
                mapping.sheet_name,
                mapping.header_row,
                mapping.invoice_column,
                mapping.hsn_column,
                total_docs,
                utc_now(),
            ),
        )

    def _document(self, batch_id: str, references: list[int], codes: list[str]) -> None:
        evidence = {
            "resolved": {
                "reference_ids": references,
                "observed_invoice_number": "4",
                "codes": codes,
                "match_state": "matched" if references else "not_found",
                "confidence": 0.99,
                "requires_review": False,
                "reasons": [],
            }
        }
        self.database.execute(
            """
            INSERT INTO documents(
                batch_id,file_name,path,sha256,status,invoice_number,hsn_codes,
                confidence,match_state,evidence_json,created_at,processed_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                batch_id,
                "invoice.pdf",
                str(self.config.data_dir / "invoice.pdf"),
                "a" * 64,
                "done" if references else "orphan",
                "4",
                ", ".join(codes),
                0.99,
                "matched" if references else "not_found",
                json.dumps(evidence),
                utc_now(),
                utc_now(),
            ),
        )

    def test_supplied_sample_is_orphan_and_all_workbook_rows_are_missing(self) -> None:
        sample = Path(__file__).resolve().parents[2] / "upload" / "July 2025 Data.xlsx"
        if not sample.exists():
            self.skipTest("The privately supplied sample workbook is not distributed with the app")
        batch_dir = self.config.batches_dir / "sample"
        batch_dir.mkdir(parents=True)
        workbook = batch_dir / sample.name
        shutil.copy2(sample, workbook)
        mapping = WorkbookMapping("B2B", 6, 3, 7)
        rows = read_invoice_rows(workbook, mapping)
        before = load_workbook(workbook, read_only=True)
        try:
            original_g9 = before["B2B"]["G9"].value
            original_sheets = tuple(before.sheetnames)
        finally:
            before.close()

        self._batch("sample", workbook, mapping)
        self._document("sample", [], [])
        self.processor.reconcile_and_export("sample")

        batch = self.database.row("SELECT * FROM batches WHERE id='sample'")
        assert batch is not None
        self.assertEqual(batch["missing_count"], len(rows))
        self.assertEqual(batch["orphan_count"], 1)
        self.assertEqual(batch["review_count"], 0)
        self.assertEqual(batch["status"], "completed")
        output = load_workbook(Path(batch["output_path"]), read_only=True)
        try:
            self.assertEqual(tuple(output.sheetnames), original_sheets)
            self.assertTrue(
                all(output["B2B"].cell(row=row.row_number, column=7).value == "Invoice Missing" for row in rows)
            )
        finally:
            output.close()
        unchanged = load_workbook(workbook, read_only=True)
        try:
            self.assertEqual(unchanged["B2B"]["G9"].value, original_g9)
        finally:
            unchanged.close()

    def test_no_hsn_and_multiple_codes_overwrite_existing_values(self) -> None:
        batch_dir = self.config.batches_dir / "synthetic"
        batch_dir.mkdir(parents=True)
        workbook = batch_dir / "input.xlsx"
        book = Workbook()
        sheet = book.active
        sheet.title = "B2B"
        sheet.cell(1, 3).value = "Invoice No"
        sheet.cell(1, 7).value = "HSN/SAC"
        sheet.cell(2, 3).value = "4"
        sheet.cell(2, 7).value = "OLD"
        sheet.cell(3, 3).value = "5"
        sheet.cell(3, 7).value = "OLD-2"
        book.save(workbook)
        mapping = WorkbookMapping("B2B", 1, 3, 7)

        self._batch("synthetic", workbook, mapping)
        self._document("synthetic", [2], ["39219010", "73259910", "998899"])
        self.processor.reconcile_and_export("synthetic")
        batch = self.database.row("SELECT * FROM batches WHERE id='synthetic'")
        assert batch is not None
        output = load_workbook(Path(batch["output_path"]), read_only=True)
        try:
            self.assertEqual(output["B2B"].cell(2, 7).value, "39219010, 73259910, 998899")
            self.assertEqual(output["B2B"].cell(3, 7).value, "Invoice Missing")
        finally:
            output.close()

        # Reconcile the same matched invoice with no codes in a new batch.
        second_workbook = batch_dir / "no-hsn.xlsx"
        shutil.copy2(workbook, second_workbook)
        self._batch("no-hsn", second_workbook, mapping)
        self._document("no-hsn", [2], [])
        self.processor.reconcile_and_export("no-hsn")
        no_hsn_batch = self.database.row("SELECT * FROM batches WHERE id='no-hsn'")
        assert no_hsn_batch is not None
        no_hsn_output = load_workbook(Path(no_hsn_batch["output_path"]), read_only=True)
        try:
            self.assertEqual(
                no_hsn_output["B2B"].cell(2, 7).value,
                "Invoice Found but HSN not mentioned",
            )
        finally:
            no_hsn_output.close()

    def test_full_worker_path_matches_invoice_and_writes_contextual_hsn(self) -> None:
        batch_dir = self.config.batches_dir / "worker"
        batch_dir.mkdir(parents=True)
        workbook = batch_dir / "input.xlsx"
        book = Workbook()
        sheet = book.active
        sheet.title = "B2B"
        sheet.cell(1, 3).value = "Invoice No"
        sheet.cell(1, 7).value = "HSN/SAC"
        sheet.cell(2, 3).value = "INV-001"
        book.save(workbook)
        mapping = WorkbookMapping("B2B", 1, 3, 7)
        self._batch("worker", workbook, mapping)
        pdf = batch_dir / "invoice.pdf"
        pdf.write_bytes(b"%PDF-1.4\n% fake worker fixture\n")
        self.database.execute(
            "INSERT INTO documents(batch_id,file_name,path,sha256,status,created_at) VALUES(?,?,?,?,?,?)",
            ("worker", pdf.name, str(pdf), "b" * 64, "queued", utc_now()),
        )

        def token(text: str, confidence: float, x0: float, y0: float, x1: float, y1: float) -> RuntimeToken:
            return RuntimeToken(
                text=text,
                confidence=confidence,
                page_index=0,
                polygon=((x0, y0), (x1, y0), (x1, y1), (x0, y1)),
            )

        page = PageOCRResult(
            page_index=0,
            width=1000,
            height=1000,
            tokens=(
                token("Invoice", 0.99, 50, 50, 130, 80),
                token("No.", 0.99, 140, 50, 180, 80),
                token("INV-001", 0.99, 200, 50, 290, 80),
                token("Description", 0.99, 50, 200, 240, 230),
                token("HSN/SAC", 0.99, 400, 200, 500, 230),
                token("Amount", 0.99, 700, 200, 800, 230),
                token("Printed item", 0.99, 50, 260, 240, 290),
                token("39219010", 0.99, 410, 260, 500, 290),
                token("100.00", 0.99, 700, 260, 800, 290),
            ),
            text="Invoice No. INV-001\nDescription HSN/SAC Amount\nPrinted item 39219010 100.00",
            mean_confidence=0.99,
            source="paddleocr",
        )
        result = DocumentOCRResult(path=pdf, sha256="b" * 64, pages=(page,))

        class FakeRuntime:
            def ocr_pdf(self, _path: Path, **_options: object) -> DocumentOCRResult:
                return result

        fake = FakeRuntime()
        self.processor._engines = lambda: (fake, fake)  # type: ignore[method-assign]
        self.processor._process("worker")
        batch = self.database.row("SELECT * FROM batches WHERE id='worker'")
        assert batch is not None
        self.assertEqual(batch["status"], "completed")
        self.assertEqual(batch["matched_count"], 1)
        output = load_workbook(Path(batch["output_path"]), read_only=True)
        try:
            self.assertEqual(output["B2B"].cell(2, 7).value, "39219010")
        finally:
            output.close()


if __name__ == "__main__":
    unittest.main()
