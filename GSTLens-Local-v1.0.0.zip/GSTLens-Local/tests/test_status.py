from __future__ import annotations

import unittest

from gstlens_core import (
    HSN_MISSING,
    INVOICE_MISSING,
    REVIEW_REQUIRED,
    HsnExtraction,
    ReconciliationStatus,
    decide_reconciliation,
)


class ReconciliationDecisionTests(unittest.TestCase):
    def test_exact_required_status_values(self) -> None:
        missing = decide_reconciliation(invoice_found=False)
        self.assertEqual(missing.cell_value, "Invoice Missing")
        self.assertEqual(missing.cell_value, INVOICE_MISSING)

        no_hsn = decide_reconciliation(invoice_found=True)
        self.assertEqual(no_hsn.cell_value, "Invoice Found but HSN not mentioned")
        self.assertEqual(no_hsn.cell_value, HSN_MISSING)

    def test_multiple_codes_are_comma_separated(self) -> None:
        extraction = HsnExtraction(
            ("730890", "998311"), (), True, False, ()
        )
        decision = decide_reconciliation(invoice_found=True, extraction=extraction)
        self.assertIs(decision.status, ReconciliationStatus.MATCHED)
        self.assertEqual(decision.cell_value, "730890, 998311")

    def test_review_result_is_not_silently_written(self) -> None:
        extraction = HsnExtraction(
            ("730890",), (), True, True, ("low confidence",)
        )
        decision = decide_reconciliation(invoice_found=True, extraction=extraction)
        self.assertEqual(decision.cell_value, REVIEW_REQUIRED)
        self.assertEqual(decision.proposed_codes, ("730890",))
        self.assertFalse(decision.can_write_automatically)

    def test_ambiguous_invoice_requires_review(self) -> None:
        decision = decide_reconciliation(
            invoice_found=True,
            invoice_match_ambiguous=True,
        )
        self.assertIs(decision.status, ReconciliationStatus.REVIEW_REQUIRED)


if __name__ == "__main__":
    unittest.main()

